package com.smartplay.apiservices.models.response;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigInteger;
import java.util.Arrays;

import org.junit.jupiter.api.Test;

class VoucherTest {

    @Test
    void testVoucherNoArgsConstructor() {
        Voucher voucher = new Voucher();
        assertNotNull(voucher);
        assertNull(voucher.getSku());
        assertNull(voucher.getName());
        assertNull(voucher.getDescription());
        assertNull(voucher.getImage());
        assertNull(voucher.getCurrencyID());
        assertNotNull(voucher.getTags());
        assertTrue(voucher.getTags().isEmpty());
        assertNotNull(voucher.getDenominations());
        assertTrue(voucher.getDenominations().isEmpty());
    }

    @Test
    void testVoucherAllArgsConstructor() {
        Voucher voucher = new Voucher("sku123", "Voucher Name", "Description", "image.png", "USD",
            "Sample Terms and conditions", "tncUrl",Arrays.asList("tag1", "tag2"), Arrays.asList(BigInteger.valueOf(10), BigInteger.valueOf(20), BigInteger.valueOf(50)));
        assertEquals("sku123", voucher.getSku());
        assertEquals("Voucher Name", voucher.getName());
        assertEquals("Description", voucher.getDescription());
        assertEquals("image.png", voucher.getImage());
        assertEquals("USD", voucher.getCurrencyID());
        assertEquals(Arrays.asList("tag1", "tag2"), voucher.getTags());
        assertEquals(Arrays.asList(BigInteger.valueOf(10), BigInteger.valueOf(20), BigInteger.valueOf(50)), voucher.getDenominations());
    }

    @Test
    void testVoucherBuilder() {
        Voucher voucher = Voucher.builder()
                .sku("sku123")
                .name("Voucher Name")
                .description("Description")
                .image("image.png")
                .currencyID("USD")
                .tags(Arrays.asList("tag1", "tag2"))
                .denominations(Arrays.asList(BigInteger.valueOf(10), BigInteger.valueOf(20), BigInteger.valueOf(50)))
                .build();
        assertEquals("sku123", voucher.getSku());
        assertEquals("Voucher Name", voucher.getName());
        assertEquals("Description", voucher.getDescription());
        assertEquals("image.png", voucher.getImage());
        assertEquals("USD", voucher.getCurrencyID());
        assertEquals(Arrays.asList("tag1", "tag2"), voucher.getTags());
        assertEquals(Arrays.asList(BigInteger.valueOf(10), BigInteger.valueOf(20), BigInteger.valueOf(50)), voucher.getDenominations());
    }

    @Test
    void testVoucherBuilderDefaults() {
        Voucher voucher = Voucher.builder().build();
        assertNotNull(voucher.getTags());
        assertTrue(voucher.getTags().isEmpty());
        assertNotNull(voucher.getDenominations());
        assertTrue(voucher.getDenominations().isEmpty());
    }

    @Test
    void testSettersAndGetters() {
        Voucher voucher = new Voucher();
        voucher.setSku("sku123");
        voucher.setName("Voucher Name");
        voucher.setDescription("Description");
        voucher.setImage("image.png");
        voucher.setCurrencyID("USD");
        voucher.setTags(Arrays.asList("tag1", "tag2"));
        voucher.setDenominations(Arrays.asList(BigInteger.valueOf(10), BigInteger.valueOf(20), BigInteger.valueOf(50)));

        assertEquals("sku123", voucher.getSku());
        assertEquals("Voucher Name", voucher.getName());
        assertEquals("Description", voucher.getDescription());
        assertEquals("image.png", voucher.getImage());
        assertEquals("USD", voucher.getCurrencyID());
        assertEquals(Arrays.asList("tag1", "tag2"), voucher.getTags());
        assertEquals(Arrays.asList(BigInteger.valueOf(10), BigInteger.valueOf(20), BigInteger.valueOf(50)), voucher.getDenominations());
    }
}
