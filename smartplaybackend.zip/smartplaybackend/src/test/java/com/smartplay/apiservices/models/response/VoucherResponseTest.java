package com.smartplay.apiservices.models.response;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigInteger;
import java.util.Arrays;

import org.junit.jupiter.api.Test;

class VoucherResponseTest {

    @Test
    void testVoucherResponseNoArgsConstructor() {
        VoucherResponse voucherResponse = new VoucherResponse();
        assertNotNull(voucherResponse);
        assertNotNull(voucherResponse.getCurrencies());
        assertTrue(voucherResponse.getCurrencies().isEmpty());
        assertNotNull(voucherResponse.getAllTags());
        assertTrue(voucherResponse.getAllTags().isEmpty());
        assertNotNull(voucherResponse.getVouchers());
        assertTrue(voucherResponse.getVouchers().isEmpty());
    }

    @Test
    void testVoucherResponseNoArgsConstructor2() {
        
        Currency currency = new Currency("USD", "United States Dollar", "$");
        Voucher voucher = new Voucher("sku123", "Voucher Name", "Description", "image.png", "USD", "sample tnc","tncUrl",
                Arrays.asList("tag1", "tag2"), Arrays.asList( BigInteger.valueOf(10), BigInteger.valueOf(20), BigInteger.valueOf(50)));

        VoucherResponse voucherResponse = new VoucherResponse();
        voucherResponse.getCurrencies().add(currency);
        voucherResponse.getVouchers().add(voucher);
        voucherResponse.getAllTags().addAll(Arrays.asList("tag1", "tag2"));

        voucher.toString();
        voucherResponse.toString();

        assertEquals(Arrays.asList(currency), voucherResponse.getCurrencies());
        assertEquals(Arrays.asList("tag1", "tag2"), voucherResponse.getAllTags());
        assertEquals(Arrays.asList(voucher), voucherResponse.getVouchers());
    }

    @Test
    void testVoucherResponseAllArgsConstructor() {
        Currency currency = new Currency("USD", "United States Dollar", "$");
        Voucher voucher = new Voucher("sku123", "Voucher Name", "Description", "image.png", "USD", "sample tnc","tncUrl",
        Arrays.asList("tag1", "tag2"), Arrays.asList( BigInteger.valueOf(10), BigInteger.valueOf(20), BigInteger.valueOf(50)));

        VoucherResponse voucherResponse = new VoucherResponse();
        voucherResponse.getCurrencies().add(currency);
        voucherResponse.getVouchers().add(voucher);
        voucherResponse.getAllTags().addAll(Arrays.asList("tag1", "tag2"));
        assertEquals(Arrays.asList(currency), voucherResponse.getCurrencies());
        assertEquals(Arrays.asList("tag1", "tag2"), voucherResponse.getAllTags());
        assertEquals(Arrays.asList(voucher), voucherResponse.getVouchers());
    }

    @Test
    void testVoucherResponseAllArgsConstructor2() {
        Currency currency = new Currency("USD", "United States Dollar", "$");
        Voucher voucher = new Voucher("sku123", "Voucher Name", "Description", "image.png", "USD", "sample tnc","tncUrl",
        Arrays.asList("tag1", "tag2"), Arrays.asList( BigInteger.valueOf(10), BigInteger.valueOf(20), BigInteger.valueOf(50)));

        VoucherResponse voucherResponse = new VoucherResponse(Arrays.asList(currency), Arrays.asList("tag1", "tag2"), Arrays.asList(voucher));

        voucher.toString();
        voucherResponse.toString();

        assertEquals(Arrays.asList(currency), voucherResponse.getCurrencies());
        assertEquals(Arrays.asList("tag1", "tag2"), voucherResponse.getAllTags());
        assertEquals(Arrays.asList(voucher), voucherResponse.getVouchers());
    }

    @Test
    void testVoucherResponseBuilderDefaults() {
        VoucherResponse voucherResponse = VoucherResponse.builder().build();
        assertNotNull(voucherResponse.getCurrencies());
        assertTrue(voucherResponse.getCurrencies().isEmpty());
        assertNotNull(voucherResponse.getAllTags());
        assertTrue(voucherResponse.getAllTags().isEmpty());
        assertNotNull(voucherResponse.getVouchers());
        assertTrue(voucherResponse.getVouchers().isEmpty());
    }

    @Test
    void testSettersAndGetters() {
        VoucherResponse voucherResponse = new VoucherResponse();
        Currency currency = new Currency("INR", "Indian Rupees", "₹");
        Voucher voucher = new Voucher("sku123", "Voucher Name", "Description", "image.png", "INR", "sample tnc","tncUrl",
        Arrays.asList("tag1", "tag2"), Arrays.asList( BigInteger.valueOf(10), BigInteger.valueOf(20), BigInteger.valueOf(50)));

        voucherResponse.setCurrencies(Arrays.asList(currency));
        voucherResponse.setAllTags(Arrays.asList("tag1", "tag2"));
        voucherResponse.setVouchers(Arrays.asList(voucher));

        assertEquals(Arrays.asList(currency), voucherResponse.getCurrencies());
        assertEquals(Arrays.asList("tag1", "tag2"), voucherResponse.getAllTags());
        assertEquals(Arrays.asList(voucher), voucherResponse.getVouchers());
    }
}
