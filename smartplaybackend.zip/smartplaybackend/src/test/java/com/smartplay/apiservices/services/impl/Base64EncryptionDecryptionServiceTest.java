package com.smartplay.apiservices.services.impl;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Base64EncryptionDecryptionServiceTest {

    private Base64EncryptionDecryptionService encryptionDecryptionService;

    @BeforeEach
    void setUp() {
        encryptionDecryptionService = new Base64EncryptionDecryptionService();
    }

    @Test
    void testEncrypt() {
        // Arrange
        String plainText = "Hello, World!";

        // Act
        String encryptedText = encryptionDecryptionService.encrypt(plainText);

        // Assert
        assertEquals("SGVsbG8sIFdvcmxkIQ==", encryptedText);
    }

    @Test
    void testDecrypt() {
        // Arrange
        String encryptedText = "SGVsbG8sIFdvcmxkIQ==";

        // Act
        String decryptedText = encryptionDecryptionService.decrypt(encryptedText);

        // Assert
        assertEquals("Hello, World!", decryptedText);
    }
}
