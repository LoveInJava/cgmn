package com.smartplay.apiservices.services.impl;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.smartplay.apiservices.models.response.Currency;

class CurrencyServiceTest {

    private CurrencyService currencyService;

    @BeforeEach
    public void setUp() {
        currencyService = new CurrencyService();
    }

    @Test
    void testGetCurrencies() {
        List<Currency> currencies = currencyService.getCurrencies();
        assertNotNull(currencies);
        assertEquals(4, currencies.size());
    }

    @Test
    void testGetDefaultCurrency() {
        Currency defaultCurrency = currencyService.getDefaultCurrency();
        assertNotNull(defaultCurrency);
        assertEquals("INR", defaultCurrency.getName());
    }

    @Test
    void testGetCurrencyByName() {
        Currency currency = currencyService.getCurrencyByName("USD");
        assertNotNull(currency);
        assertEquals("USD", currency.getName());
    }

    @Test
    void testGetCurrencyByName_NotFound() {
        Currency currency = currencyService.getCurrencyByName("ABC");
        assertNull(currency);
    }
}
