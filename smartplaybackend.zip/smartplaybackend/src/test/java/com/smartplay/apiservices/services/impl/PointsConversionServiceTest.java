// package com.smartplay.apiservices.services.impl;

// import java.util.UUID;

// import org.junit.jupiter.api.BeforeEach;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;

// import com.smartplay.apiservices.models.data.SmartPlayMoney;
// import com.smartplay.apiservices.models.data.UserSmartPlayGamePoint;
// import com.smartplay.apiservices.repository.interfaces.IInMemoryRepository;

// class PointsConversionServiceTest {

//     @Mock
//     private IInMemoryRepository<SmartPlayMoney, UUID> smartplayMoneyRepository;

//     @Mock
//     private IInMemoryRepository<UserSmartPlayGamePoint, String> gamepointRepository;

//     private RevenueConversionService pointsConversionService;

//     @BeforeEach
//     void setUp() {
//         MockitoAnnotations.openMocks(this);
//         pointsConversionService = new RevenueConversionService(smartplayMoneyRepository, gamepointRepository);
//     }

//     // @Test
//     // void testConvertPointsToMoney() {
//     //     // Arrange
//     //     UUID eventUuid = UUID.randomUUID();
//     //     SmartPlayGamePoint gamePoint1 = SmartPlayGamePoint.builder().eventUuid(eventUuid).gameId("001").requestId("req001").actionDateTime( LocalDateTime.now().plusMinutes(-10)).lpaId("lpaId1").build();
//     //     SmartPlayGamePoint gamePoint2 = SmartPlayGamePoint.builder().eventUuid(eventUuid).gameId("001").requestId("req001").actionDateTime( LocalDateTime.now()).lpaId("lpaId2").build();
//     //     List<SmartPlayGamePoint> gamePoints = new ArrayList<>();
//     //     gamePoints.add(gamePoint1);
//     //     gamePoints.add(gamePoint2);

//     //     SmartPlayMoney smartPlayMoney1 = SmartPlayMoney.builder().smartPlayId(UUID.randomUUID()).eventUuid(UUID.randomUUID()).lpaId("lpaId1").money(Money.builder().amount(50.0).currency(Currency.INR).build()).build();
//     //     SmartPlayMoney smartPlayMoney2 = SmartPlayMoney.builder().smartPlayId(UUID.randomUUID()).eventUuid(UUID.randomUUID()).lpaId("lpaId2").money(Money.builder().amount(75.0).currency(Currency.INR).build()).build();
//     //     List<SmartPlayMoney> expectedSmartPlayMoneyList = new ArrayList<>();
//     //     expectedSmartPlayMoneyList.add(smartPlayMoney1);
//     //     expectedSmartPlayMoneyList.add(smartPlayMoney2);

//     //     ResetTimerEvent event =ResetTimerEvent.builder().eventUuid(eventUuid).startDateTime(LocalDateTime.now()).source(this) .build();

//     //     when(currentEventService.getPreviousEvent()).thenReturn(event);
//     //     when(gamepointRepository.getAll()).thenReturn(gamePoints);

//     //     // Act
//     //     pointsConversionService.convertPointsToMoney();

//     //     // Assert
//     //     verify(currentEventService, times(2)).getPreviousEvent();
//     //     verify(gamepointRepository, times(1)).getAll();
//     //     verify(smartplayMoneyRepository, times(2)).add(any(SmartPlayMoney.class));
//     // }
// }
