package com.smartplay.apiservices.services.impl;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class PlainNoEncryptionNoDecryptionServiceTest {

    private PlainNoEncryptionNoDecryptionService encryptionDecryptionService;

    @BeforeEach
    void setUp() {
        encryptionDecryptionService = new PlainNoEncryptionNoDecryptionService();
    }

    @Test
    void testEncrypt() {
        // Arrange
        String plainText = "Hello, World!";

        // Act
        String encryptedText = encryptionDecryptionService.encrypt(plainText);

        // Assert
        assertEquals(plainText, encryptedText);
    }

    @Test
    void testDecrypt() {
        // Arrange
        String encryptedText = "Hello, World!";

        // Act
        String decryptedText = encryptionDecryptionService.decrypt(encryptedText);

        // Assert
        assertEquals(encryptedText, decryptedText);
    }
}
