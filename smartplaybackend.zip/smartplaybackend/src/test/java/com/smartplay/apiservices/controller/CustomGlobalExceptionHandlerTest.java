package com.smartplay.apiservices.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.smartplay.apiservices.exceptions.DataNotFoundException;
import com.smartplay.apiservices.exceptions.InvalidPhoneNumberException;
import com.smartplay.apiservices.exceptions.InvalidRequestBadPayload;
import com.smartplay.apiservices.exceptions.InvalidVerificationCodeException;
import com.smartplay.apiservices.exceptions.PhoneNumberAlreadyRegisteredException;
import com.smartplay.apiservices.exceptions.PhoneNumberAlreadyVerifiedException;

class CustomGlobalExceptionHandlerTest {

    private CustomGlobalExceptionHandler exceptionHandler = new CustomGlobalExceptionHandler();

    @Mock
    private InvalidPhoneNumberException invalidPhoneNumberException;

    @Mock
    private PhoneNumberAlreadyVerifiedException phoneNumberAlreadyVerifiedException;

    @Mock
    private InvalidVerificationCodeException invalidVerificationCodeException;

    @Mock
    private InvalidRequestBadPayload invalidRequestBadPayload;
    @Mock
    private DataNotFoundException dataNotFoundException;

    @Test
    void handleInvalidPhoneNumberException() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();

        ResponseEntity<Map<String, Object>> result = exceptionHandler.handleInvalidPhoneNumberException(response, request, invalidPhoneNumberException);

        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
    }

    @Test
    void handlePhoneNumberAlreadyRegisteredException(){
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();
        String mobileNumber = "1234567890";
        String lpaId = "LPA123";

        PhoneNumberAlreadyRegisteredException phoneNumberAlreadyRegisteredException = mock(PhoneNumberAlreadyRegisteredException.class);

        when(phoneNumberAlreadyRegisteredException.getMobileNumber()).thenReturn(mobileNumber);
        when(phoneNumberAlreadyRegisteredException.getLpaId()).thenReturn(lpaId);

        ResponseEntity<Map<String, Object>> result = exceptionHandler.handlePhoneNumberAlreadyRegisteredException(response, request, phoneNumberAlreadyRegisteredException);

        assertEquals(HttpStatus.SEE_OTHER, result.getStatusCode());
        assertEquals(HttpStatus.SEE_OTHER.value(), response.getStatus());

        UriComponents location = UriComponentsBuilder.fromPath("/api/v1/status/{lpaid}")
                .buildAndExpand(lpaId);

        Map<String, Object> expectedResponseBody = new HashMap<>();
        expectedResponseBody.put("message", "Redirect to: " + location.toUriString());
        expectedResponseBody.put("status", HttpStatus.SEE_OTHER.value());

        assertEquals(expectedResponseBody, result.getBody());
        assertEquals(location.toUriString(), result.getHeaders().getFirst("Location"));
    }

    @Test
    void handlePhoneNumberAlreadyVerifiedException() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();

        ResponseEntity<Map<String, Object>> result = exceptionHandler.handlePhoneNumberAlreadyVerifiedException(response, request, phoneNumberAlreadyVerifiedException);

        assertEquals(HttpStatus.CONFLICT, result.getStatusCode());
    }

    @Test
    void handleInvalidVerificationCodeException() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();

        ResponseEntity<Map<String, Object>> result = exceptionHandler.handleInvalidVerificationCodeException(response, request, invalidVerificationCodeException);

        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
    }

    @Test
    void handleInvalidRequestBadPayload() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();

        ResponseEntity<Map<String, Object>> result = exceptionHandler.handleInvalidRequestBadPayload(response, request, invalidRequestBadPayload);

        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
    }

    @Test
    void handleInvalidRequestDataNotFoundException() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();

        ResponseEntity<Map<String, Object>> result = exceptionHandler.handleInvalidRequestDataNotFoundException(response, request, dataNotFoundException);

        assertEquals(HttpStatus.NOT_FOUND, result.getStatusCode());
    }

}
