package com.smartplay.apiservices.models.response;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ReponseTypeTest {

    @Test
    void testAboutResponseType() {
        // Arrange
        ReponseType responseType = ReponseType.ABOUT;

        // Act
        String label = responseType.getLabel();

        // Assert
        assertEquals("about", label);
    }

    @Test
    void testFaqResponseType() {
        // Arrange
        ReponseType responseType = ReponseType.FAQ;

        // Act
        String label = responseType.getLabel();

        // Assert
        assertEquals("faq", label);
    }

    @Test
    void testNewsResponseType() {
        // Arrange
        ReponseType responseType = ReponseType.NEWS;

        // Act
        String label = responseType.getLabel();

        // Assert
        assertEquals("news", label);
    }

    @Test
    void testGamesResponseType() {
        // Arrange
        ReponseType responseType = ReponseType.GAMES;

        // Act
        String label = responseType.getLabel();

        // Assert
        assertEquals("games", label);
    }

    @Test
    void testRewardsResponseType() {
        // Arrange
        ReponseType responseType = ReponseType.REWARDS;

        // Act
        String label = responseType.getLabel();

        // Assert
        assertEquals("rewards", label);
    }

    @Test
    void testPrivacyPolicyResponseType() {
        // Arrange
        ReponseType responseType = ReponseType.PRIVACYPOLICY;

        // Act
        String label = responseType.getLabel();

        // Assert
        assertEquals("privacypolicy", label);
    }

    @Test
    void testSmartPointResponseType() {
        // Arrange
        ReponseType responseType = ReponseType.SMARTPOINT;

        // Act
        String label = responseType.getLabel();

        // Assert
        assertEquals("smartpoint", label);
    }
    @Test
    void testSmartPointResponseType_ToString() {
        // Arrange
        ReponseType responseType = ReponseType.SMARTPOINT;

        // Act
        String label = responseType.toString();

        // Assert
        assertEquals("smartpoint", label);
    }
}
