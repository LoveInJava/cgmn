package com.smartplay.apiservices.services.impl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.smartplay.apiservices.services.interfaces.IGamePointService;
import com.smartplay.apiservices.services.interfaces.IRevenueConversionService;


@ExtendWith(MockitoExtension.class)
class ResetTimerListenerTest {

    @Mock
    private IRevenueConversionService pointsConversionService;

    @Mock
    private IGamePointService gamePointService;

    private ResetTimerListener resetTimerListener;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        resetTimerListener = new ResetTimerListener( pointsConversionService, gamePointService);
    }

    // @Test
    // void onApplicationEvent_shouldResetTimerAndPerformActions() {
    //     // Arrange
    //     ResetTimerEvent event = ResetTimerEvent.builder().source(this).eventUuid(UUID.randomUUID()).startDateTime(LocalDateTime.now()).build();

    //     // Act
    //     resetTimerListener.onApplicationEvent(event);

    //     // Assert
    //     verify(currentEventService, times(1)).setCurrentEvent(event);
    //     verify(pointsConversionService, times(1)).convertPointsToMoney();
    //     verify(gamePointService, times(1)).resetGamePoints();
    //     // Add assertions for other actions if needed
    // }
}
