package com.smartplay.apiservices.config;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Collection;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.smartplay.apiservices.services.interfaces.IPinelabTokenService;

import feign.RequestTemplate;

class PinelabDynamicHeaderRequestInterceptorTest {

    @Mock
    private IPinelabTokenService pinelabTokenService;

    @InjectMocks
    private PinelabDynamicHeaderRequestInterceptor interceptor;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testApply() {
        String expectedToken = "Bearer testToken";
        when(pinelabTokenService.getBearerTokenString()).thenReturn(expectedToken);

        RequestTemplate template = new RequestTemplate();
        template.header("Authorization", "oldToken");
        template.header("dateAtClient", "oldDate");

        interceptor.apply(template);

        Collection<String> authHeaders = template.headers().get("Authorization");
        
        assertTrue(authHeaders.contains(expectedToken));
        
    }
}