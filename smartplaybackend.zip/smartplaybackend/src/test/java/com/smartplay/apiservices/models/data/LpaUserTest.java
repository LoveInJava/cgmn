package com.smartplay.apiservices.models.data;

import static org.junit.jupiter.api.Assertions.*;

import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class LpaUserTest {

    private LpaUser lpaUser;

    @BeforeEach
    void setUp() {
        lpaUser = LpaUser.builder()
                .lpaId(UUID.randomUUID().toString())
                .phoneNumber("1234567890")
                .isPhoneNumberVerified(true)
                .build();
    }

    @Test
    void testAddDeviceId() {
        // Arrange
        String deviceId = "ABC123";

        // Act
        lpaUser.addDeviceId(deviceId);

        // Assert
        assertEquals(1, lpaUser.getDeviceIds().size());
        assertEquals(deviceId, lpaUser.getDeviceIds().get(0));
    }

    @Test
    void testAddDeviceId_ThrowsException() {
        // Arrange
        lpaUser.addDeviceId("ABC123");

        // Act & Assert
        assertThrows(IllegalStateException.class, () -> lpaUser.addDeviceId("XYZ789"));
    }
}
