// package com.smartplay.apiservices.repository.impl;

// import static org.junit.jupiter.api.Assertions.*;

// import java.util.List;
// import java.util.UUID;
// import java.util.function.Predicate;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;

// import com.smartplay.apiservices.models.data.LpaUser;

// class LpaUserRepositoryTest {

//     private LpaUserService repository;

//     @BeforeEach
//     void setUp() {
//         repository = new LpaUserService();
//     }

//     @Test
//     void testFindByPhoneNumber() {
//         // Arrange
//         UUID id = UUID.randomUUID();
//         LpaUser user = LpaUser.builder().lpaId(id.toString()).phoneNumber("1234567890").isPhoneNumberVerified(false).build();
//         repository.save(user);

//         // Act
//         LpaUser foundUser = repository.findByPhoneNumber("1234567890");

//         // Assert
//         assertNotNull(foundUser);
//         assertEquals(user, foundUser);
//     }

//     @Test
//     void testFindByLpaId() {
//         // Arrange
//         UUID id = UUID.randomUUID();
//         LpaUser user = LpaUser.builder().lpaId(id.toString()).phoneNumber("1234567890").isPhoneNumberVerified(false).build();
//         repository.save(user);

//         // Act
//         LpaUser foundUser = repository.findByLpaId(user.getLpaId());

//         // Assert
//         assertNotNull(foundUser);
//         assertEquals(user, foundUser);
//     }

//     @Test
//     void testFindById() {
//         // Arrange
//         UUID id = UUID.randomUUID();
//         LpaUser user = LpaUser.builder().lpaId(id.toString()).phoneNumber("1234567890").isPhoneNumberVerified(false).build();
//         repository.save(user);

//         // Act
//         LpaUser foundUser = repository.findById(id);

//         // Assert
//         assertNotNull(foundUser);
//         assertEquals(user, foundUser);
//     }

//     @Test
//     void testFindByDeviceId() {
//         // Arrange
//         UUID id = UUID.randomUUID();
//         LpaUser user = LpaUser.builder().lpaId(id.toString()).phoneNumber("1234567890").isPhoneNumberVerified(false).build();
//         user.addDeviceId("device1");
//         repository.save(user);

//         // Act
//         LpaUser foundUser = repository.findByDeviceId("device1");

//         // Assert
//         assertNotNull(foundUser);
//         assertEquals(user, foundUser);
//     }

//     @Test
//     void testIsDeviceRegistered() {
//         // Arrange
//         UUID id = UUID.randomUUID();
//         LpaUser user = LpaUser.builder().lpaId(id.toString()).phoneNumber("1234567890").isPhoneNumberVerified(false).build();
//         user.addDeviceId("device1");
//         repository.save(user);

//         // Act
//         boolean isRegistered = repository.isDeviceRegistered("device1");

//         // Assert
//         assertTrue(isRegistered);
//     }

//     @Test
//     void testFilter() {
//         // Arrange
//         UUID id1 = UUID.randomUUID();
//         LpaUser user1 = LpaUser.builder().lpaId(id1.toString()).phoneNumber("1234567890").isPhoneNumberVerified(false).build();
//         repository.save(user1);

//         UUID id2 = UUID.randomUUID();
//         LpaUser user2 = LpaUser.builder().lpaId(id2.toString()).phoneNumber("9876543210").isPhoneNumberVerified(true).build();
//         repository.save(user2);

//         UUID id3 = UUID.randomUUID();
//         LpaUser user3 = LpaUser.builder().lpaId(id3.toString()).phoneNumber("5555555555").isPhoneNumberVerified(false).build();
//         repository.save(user3);

//         Predicate<LpaUser> predicate = user -> user.isPhoneNumberVerified();

//         // Act
//         List<LpaUser> filteredUsers = repository.filter(predicate);

//         // Assert
//         assertEquals(1, filteredUsers.size());
//         assertEquals(user2, filteredUsers.get(0));
//     }
// }
