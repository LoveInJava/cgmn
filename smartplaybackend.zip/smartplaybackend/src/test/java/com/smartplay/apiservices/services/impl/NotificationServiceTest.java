// package com.smartplay.apiservices.services.impl;

// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;

// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.extension.ExtendWith;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.junit.jupiter.MockitoExtension;
// import org.springframework.context.ApplicationEventPublisher;

// import com.smartplay.apiservices.exceptions.NotImplementedException;
// import com.smartplay.apiservices.repository.impl.OtpService;
// import com.smartplay.apiservices.services.interfaces.ISmsService;


// @ExtendWith(MockitoExtension.class)
// class NotificationServiceTest {

//     @InjectMocks
//     private NotificationService notificationService;

//     @Mock
//     private ApplicationEventPublisher applicationEventPublisher;

//     @Mock
//     private OtpService otpRepository;

//     @Mock
//     private ISmsService smsService;

//     @Test
//     void testPublishEvent() {
//         // Arrange
//         Object event = new Object();

//         // Act
//         notificationService.publishEvent(event);

//         // Assert
//         verify(applicationEventPublisher, times(1)).publishEvent(event);
//     }

//     @Test
//     void testSendSms() {
//         // Arrange
//         String phoneNumber = "1234567890";
//         String message = "Test message";

//         // Act
//         notificationService.sendSms(phoneNumber, message);

//         // Assert
//         verify(smsService, times(1)).sendSms(phoneNumber, message);
//     }

//     @Test
//     void testSendVerificationCode() {
//         // Arrange
//         String phoneNumber = "1234567890";
//         String verificationCode = "123456";

//         // Act
//         notificationService.sendVerificationCode(phoneNumber, verificationCode);

//         // Assert
//         verify(otpRepository, times(1)).saveOtp(phoneNumber, verificationCode, 180);
//     }

//     @Test
//     void testRetrySendVerificationCode_ExistingOtp() {
//         // Arrange
//         String phoneNumber = "1234567890";
//         String newVerificationCode = "654321";
//         String existingOtp = "123456";

//         when(otpRepository.getOtp(phoneNumber)).thenReturn(existingOtp);

//         // Act
//         notificationService.retrySendVerificationCode(phoneNumber, newVerificationCode);

//         // Assert
//         verify(otpRepository, times(1)).getOtp(phoneNumber);
//     }

//     @Test
//     void testRetrySendVerificationCode_NewOtp() {
//         // Arrange
//         String phoneNumber = "1234567890";
//         String newVerificationCode = "654321";

//         when(otpRepository.getOtp(phoneNumber)).thenReturn(null);

//         // Act
//         notificationService.retrySendVerificationCode(phoneNumber, newVerificationCode);

//         // Assert
//         verify(otpRepository, times(1)).getOtp(phoneNumber);
//     }

//     @Test
//     void testSendEmail() {
//         // Arrange
//         String emailAddress = "test@example.com";
//         String subject = "Test Subject";
//         String message = "Test Message";

//         // Act
//         assertThrows(NotImplementedException.class, ()-> notificationService.sendEmail(emailAddress, subject, message));
//     }
// }
