// package com.smartplay.apiservices.models.data;

// import static org.junit.jupiter.api.Assertions.*;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;

// class SmartPlayMoneyTest {

//     private SmartPlayMoney smartPlayMoney;

//     @BeforeEach
//     void setUp() {
//         smartPlayMoney = new SmartPlayMoney();
//     }

//     // @Test
//     // void testGetId() {
//     //     // Arrange
//     //     UUID smartPlayId = UUID.randomUUID();
//     //     smartPlayMoney.setLpaId(smartPlayId);

//     //     // Act
//     //     UUID id = smartPlayMoney.getId();

//     //     // Assert
//     //     assertNotNull(id);
//     //     assertEquals(smartPlayId, id);
//     // }

//     // @Test
//     // void testGetSetSmartPlayId() {
//     //     // Arrange
//     //     UUID smartPlayId = UUID.randomUUID();

//     //     // Act
//     //     smartPlayMoney.setLpaId(smartPlayId);
//     //     UUID retrievedSmartPlayId = smartPlayMoney.getLpaId();

//     //     // Assert
//     //     assertEquals(smartPlayId, retrievedSmartPlayId);
//     // }

//     // @Test
//     // void testGetSetEventUuid() {
//     //     // Arrange
//     //     UUID eventUuid = UUID.randomUUID();

//     //     // Act
//     //     smartPlayMoney.setEventUuid(eventUuid);
//     //     UUID retrievedEventUuid = smartPlayMoney.getEventUuid();

//     //     // Assert
//     //     assertEquals(eventUuid, retrievedEventUuid);
//     // }

//     @Test
//     void testGetSetMoney() {
//         // Arrange
//         Money money = new Money();

//         // Act
//         smartPlayMoney.setMoney(money);
//         Money retrievedMoney = smartPlayMoney.getMoney();

//         // Assert
//         assertEquals(money, retrievedMoney);
//     }

//     @Test
//     void testGetSetLpaId() {
//         // Arrange
//         String lpaId = "LPA123";

//         // Act
//         smartPlayMoney.setLpaId(lpaId);
//         String retrievedLpaId = smartPlayMoney.getLpaId();

//         // Assert
//         assertEquals(lpaId, retrievedLpaId);
//     }
// }
