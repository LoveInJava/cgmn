// package com.smartplay.apiservices.services.impl;

// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.ArgumentMatchers.*;
// import static org.mockito.Mockito.*;

// import java.security.Key;
// import java.util.Date;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;

// import com.smartplay.apiservices.config.PinelabSettingConfiguration;
// import com.smartplay.apiservices.repository.interfaces.IPinelabTokenRepository;
// import com.smartplay.apiservices.services.integration.payments.pinelabs.interfaces.OAuth2Client;
// import com.smartplay.apiservices.services.integration.payments.pinelabs.models.AuthorizationCodeRequest;
// import com.smartplay.apiservices.services.integration.payments.pinelabs.models.AuthorizationCodeResponse;
// import com.smartplay.apiservices.services.integration.payments.pinelabs.models.BearerTokenRequest;
// import com.smartplay.apiservices.services.integration.payments.pinelabs.models.BearerTokenResponse;

// import io.jsonwebtoken.Jwts;
// import io.jsonwebtoken.SignatureAlgorithm;
// import io.jsonwebtoken.security.Keys;

// class PinelabTokenServiceTest {

//     @Mock
//     private IPinelabTokenRepository tokenRepository;

//     @Mock
//     private OAuth2Client oauth2Client;

//     @Mock
//     private PinelabSettingConfiguration pinelabSettingConfiguration;

//     @InjectMocks
//     private PinelabTokenService pinelabTokenService;

//     @BeforeEach
//     public void setUp() {
//         MockitoAnnotations.openMocks(this);
//     }

//     private static final Key key = Keys.secretKeyFor(SignatureAlgorithm.HS256);

//     private static String generateTokenWithExpiry(boolean valid) {
//         long nowMillis = System.currentTimeMillis();
//         Date now = new Date(nowMillis);

//         // Set the expiration time to 10 minutes from now
//         long expMillis = nowMillis + 10 * 60 * 1000;
//         Date exp = valid? new Date(expMillis):new Date(0);

//         return Jwts.builder()
//                 // .setSubject("user")
//                 .setIssuedAt(now)
//                 .setExpiration(exp)
//                 .signWith(key)
//                 .compact();
//     }

//     @Test
//     void testGetToken_ValidToken() {
//         String validToken = generateTokenWithExpiry(true);
//         when(tokenRepository.getToken()).thenReturn(validToken);

//         String token = pinelabTokenService.getToken();

//         assertEquals(validToken, token);
//         verify(tokenRepository, times(1)).getToken();
//     }

//     @Test
//     void testGetToken_InvalidToken() {

//         String clientId = "clientId";
//         String username = "username";
//         String password = "password";
//         String clientSecret = "clientSecret";
//         String authorizationCode = "authorizationCode";


//         when(pinelabSettingConfiguration.getClientId()).thenReturn(clientId);
//         when(pinelabSettingConfiguration.getUsername()).thenReturn(username);
//         when(pinelabSettingConfiguration.getPassword()).thenReturn(password);
//         when(pinelabSettingConfiguration.getClientSecret()).thenReturn(clientSecret);

//         AuthorizationCodeRequest authCodeRequest = AuthorizationCodeRequest.builder()
//             .clientId(clientId)
//             .username(username)
//             .password(password)
//             .build();
//         AuthorizationCodeResponse authCodeResponse = new AuthorizationCodeResponse();
//         authCodeResponse.setAuthorizationCode(authorizationCode);
//         when(oauth2Client.getAuthorizationCode(authCodeRequest)).thenReturn(authCodeResponse);

//         String invalidToken = generateTokenWithExpiry(false);
//         String newToken = generateTokenWithExpiry(true);
//         when(tokenRepository.getToken()).thenReturn(invalidToken);

//         BearerTokenResponse tokenResponse = new BearerTokenResponse();
//         tokenResponse.setToken(newToken);
//         when(oauth2Client.getAccessToken(any())).thenReturn(tokenResponse);

//         when(pinelabTokenService.refreshToken()).thenReturn(newToken);

//         String token = pinelabTokenService.getToken();

//         assertEquals(newToken, token);
//         verify(tokenRepository, times(1)).getToken();
//     }

//     @Test
//     void testRefreshToken() {

//         String clientId = "clientId";
//         String username = "username";
//         String password = "password";
//         String clientSecret = "clientSecret";
//         String authorizationCode = "authorizationCode";


//         when(pinelabSettingConfiguration.getClientId()).thenReturn(clientId);
//         when(pinelabSettingConfiguration.getUsername()).thenReturn(username);
//         when(pinelabSettingConfiguration.getPassword()).thenReturn(password);
//         when(pinelabSettingConfiguration.getClientSecret()).thenReturn(clientSecret);

//         AuthorizationCodeRequest authCodeRequest = AuthorizationCodeRequest.builder()
//             .clientId(clientId)
//             .username(username)
//             .password(password)
//             .build();
//         AuthorizationCodeResponse authCodeResponse = new AuthorizationCodeResponse();
//         authCodeResponse.setAuthorizationCode(authorizationCode);
//         when(oauth2Client.getAuthorizationCode(authCodeRequest)).thenReturn(authCodeResponse);

//         String newToken = generateTokenWithExpiry(true);

//         BearerTokenResponse tokenResponse = new BearerTokenResponse();
//         tokenResponse.setToken(newToken);
//         when(oauth2Client.getAccessToken(any())).thenReturn(tokenResponse);

//         when(tokenRepository.setToken(newToken)).thenReturn(newToken);

//         //ACT
//         String token = pinelabTokenService.refreshToken();

//         assertEquals(newToken, token);
//         verify(tokenRepository, times(1)).setToken(newToken);
//     }

//     @Test
//     void testGetBearerTokenString() {

//         String clientId = "clientId";
//         String username = "username";
//         String password = "password";
//         String clientSecret = "clientSecret";
//         String authorizationCode = "authorizationCode";


//         when(pinelabSettingConfiguration.getClientId()).thenReturn(clientId);
//         when(pinelabSettingConfiguration.getUsername()).thenReturn(username);
//         when(pinelabSettingConfiguration.getPassword()).thenReturn(password);
//         when(pinelabSettingConfiguration.getClientSecret()).thenReturn(clientSecret);

//         AuthorizationCodeRequest authCodeRequest = AuthorizationCodeRequest.builder()
//             .clientId(clientId)
//             .username(username)
//             .password(password)
//             .build();
//         AuthorizationCodeResponse authCodeResponse = new AuthorizationCodeResponse();
//         authCodeResponse.setAuthorizationCode(authorizationCode);
//         when(oauth2Client.getAuthorizationCode(authCodeRequest)).thenReturn(authCodeResponse);

//         String newToken = generateTokenWithExpiry(true);

//         BearerTokenResponse tokenResponse = new BearerTokenResponse();
//         tokenResponse.setToken(newToken);
//         when(oauth2Client.getAccessToken(any())).thenReturn(tokenResponse);

//         when(tokenRepository.setToken(newToken)).thenReturn(newToken);

//         String bearerToken = pinelabTokenService.getBearerTokenString();

//         assertEquals("Bearer " + newToken, bearerToken);
//     }

//     @Test
//     void testGenerateNewJwtToken() {
//         String clientId = "clientId";
//         String username = "username";
//         String password = "password";
//         String clientSecret = "clientSecret";
//         String authorizationCode = "authorizationCode";
//         String newToken = "newToken";

//         when(pinelabSettingConfiguration.getClientId()).thenReturn(clientId);
//         when(pinelabSettingConfiguration.getUsername()).thenReturn(username);
//         when(pinelabSettingConfiguration.getPassword()).thenReturn(password);
//         when(pinelabSettingConfiguration.getClientSecret()).thenReturn(clientSecret);

//         AuthorizationCodeRequest authCodeRequest = AuthorizationCodeRequest.builder()
//             .clientId(clientId)
//             .username(username)
//             .password(password)
//             .build();
//         AuthorizationCodeResponse authCodeResponse = new AuthorizationCodeResponse();
//         authCodeResponse.setAuthorizationCode(authorizationCode);
//         when(oauth2Client.getAuthorizationCode(authCodeRequest)).thenReturn(authCodeResponse);

//         BearerTokenRequest tokenRequest = BearerTokenRequest.builder()
//             .clientId(clientId)
//             .clientSecret(clientSecret)
//             .authorizationCode(authorizationCode)
//             .build();
//         BearerTokenResponse tokenResponse = new BearerTokenResponse();
//         tokenResponse.setToken(newToken);
//         when(oauth2Client.getAccessToken(tokenRequest)).thenReturn(tokenResponse);

//         String token = pinelabTokenService.generateNewJwtToken();

//         assertEquals(newToken, token);
//         verify(oauth2Client, times(1)).getAuthorizationCode(authCodeRequest);
//         verify(oauth2Client, times(1)).getAccessToken(tokenRequest);
//     }
// }
