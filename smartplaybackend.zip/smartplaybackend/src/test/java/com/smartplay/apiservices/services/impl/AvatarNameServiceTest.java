package com.smartplay.apiservices.services.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.smartplay.apiservices.services.interfaces.IResourceService;

class AvatarNameServiceTest {

    @Mock
    private IResourceService resourceService;

    @InjectMocks
    private AvatarNameService avatarNameService;

    @BeforeEach
    public void setUp() throws IOException {
        MockitoAnnotations.openMocks(this);

        // Mock the resource files
        List<String> adjectives = Arrays.asList("Happy", "Sad", "Angry");
        List<String> nouns = Arrays.asList("Cat", "Dog", "Bird");

        when(resourceService.readLinesFromResource("adjectives.txt")).thenReturn(adjectives);
        when(resourceService.readLinesFromResource("nouns.txt")).thenReturn(nouns);
    }

    @Test
    void testGetRandomElement() {
        List<String> list = Arrays.asList("One", "Two", "Three");
        String element = avatarNameService.getRandomElement(list);
        assertTrue(list.contains(element));
    }

    @Test
    void testCombineWords() {
        String combined = avatarNameService.combineWords("Happy", "Cat");
        assertEquals("HappyCat", combined);
    }
}
