package com.smartplay.apiservices.tools;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.HashMap;
import java.util.Map;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerMapping;

import com.smartplay.apiservices.exceptions.InvalidRequestBadPayload;
import com.smartplay.apiservices.services.impl.HeaderPayloadVerificationService;

import jakarta.servlet.http.HttpServletRequest;

@Aspect
@Component
class VerifyHeaderToParamPayloadAspectTest {

    @Mock
    private HeaderPayloadVerificationService headerPayloadVerificationService;

    @Mock
    private HttpServletRequest request;

    @InjectMocks
    private VerifyHeaderToParamPayloadAspect verifyHeaderToParamPayloadAspect;

    @Mock
    private ProceedingJoinPoint joinPoint;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testVerifyHeaderToParamPayload_Success() throws Throwable {
        // Arrange
        String headerDeviceId = "headerDeviceId";
        String paramDeviceId = "paramDeviceId";
        when(request.getHeader("headerDeviceId")).thenReturn(headerDeviceId);
        Map<String, String> pathVariables = new HashMap<>();
        pathVariables.put("paramDeviceId", paramDeviceId);
        when(request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE)).thenReturn(pathVariables);
        when(headerPayloadVerificationService.verifyHeaderToParamPayload(headerDeviceId, paramDeviceId)).thenReturn(true);

        // Act
        verifyHeaderToParamPayloadAspect.verifyHeaderToParamPayload(joinPoint, new VerifyHeaderToParamPayload() {
            @Override
            public Class<? extends java.lang.annotation.Annotation> annotationType() {
                return VerifyHeaderToParamPayload.class;
            }

            @Override
            public String headerDeviceId() {
                return "headerDeviceId";
            }

            @Override
            public String paramDeviceId() {
                return "paramDeviceId";
            }
        });

        // Assert
        verify(joinPoint, times(1)).proceed();
    }

    @Test
    void testVerifyHeaderToParamPayload_Failure() throws Throwable {
        // Arrange
        String headerDeviceId = "headerDeviceId";
        String paramDeviceId = "paramDeviceId";
        when(request.getHeader("headerDeviceId")).thenReturn(headerDeviceId);
        Map<String, String> pathVariables = new HashMap<>();
        pathVariables.put("paramDeviceId", paramDeviceId);
        when(request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE)).thenReturn(pathVariables);
        when(headerPayloadVerificationService.verifyHeaderToParamPayload(headerDeviceId, paramDeviceId)).thenReturn(false);
        var verifyHeaderToParamPayload = getVerifyHeaderToParamPayload();

        assertThrows(InvalidRequestBadPayload.class, () -> verifyHeaderToParamPayloadAspect.verifyHeaderToParamPayload(joinPoint, verifyHeaderToParamPayload));
    }

    @Test
    void testVerifyHeaderToParamPayload_MissingHeaderOrParam() throws Throwable {
        // Arrange
        when(request.getHeader("headerDeviceId")).thenReturn(null);
        Map<String, String> pathVariables = new HashMap<>();
        pathVariables.put("paramDeviceId", null);
        when(request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE)).thenReturn(pathVariables);
        var verifyHeaderToParamPayload = getVerifyHeaderToParamPayload();

        assertThrows(InvalidRequestBadPayload.class, () -> verifyHeaderToParamPayloadAspect.verifyHeaderToParamPayload(joinPoint, verifyHeaderToParamPayload));
    }

    private VerifyHeaderToParamPayload getVerifyHeaderToParamPayload() {
        return new VerifyHeaderToParamPayload() {
            @Override
            public Class<? extends java.lang.annotation.Annotation> annotationType() {
                return VerifyHeaderToParamPayload.class;
            }

            @Override
            public String headerDeviceId() {
                return "headerDeviceId";
            }

            @Override
            public String paramDeviceId() {
                return "paramDeviceId";
            }
        };
    }
}
