// package com.smartplay.apiservices.controller;

// import static org.mockito.ArgumentMatchers.*;
// import static org.mockito.Mockito.*;
// import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
// import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Disabled;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;
// import org.springframework.http.MediaType;
// import org.springframework.test.web.servlet.MockMvc;
// import org.springframework.test.web.servlet.setup.MockMvcBuilders;

// import com.fasterxml.jackson.databind.ObjectMapper;
// import com.smartplay.apiservices.models.request.MobileRegistrationRequest;
// import com.smartplay.apiservices.models.response.RegistrationStatus;
// import com.smartplay.apiservices.services.interfaces.IRegistrationService;

// class RegistrationControllerTest {

//     private MockMvc mockMvc;

//     @Mock
//     private IRegistrationService registrationService;

//     @InjectMocks
//     private RegistrationController registrationController;

//     @BeforeEach
//     void setUp() {
//         MockitoAnnotations.openMocks(this);
//         mockMvc = MockMvcBuilders.standaloneSetup(registrationController).build();
//     }

//     @Test
//     void testRegisterFromDevice() throws Exception {
//         MobileRegistrationRequest request = MobileRegistrationRequest.builder().mobile("9818236314").build();
//         String deviceId = "device-123";
//         RegistrationStatus status = new RegistrationStatus();
//         when(registrationService.handleRegistrationRequest(anyString(), anyString())).thenReturn(null);
//         when(registrationService.generateStatusByLpaUser(null, deviceId)).thenReturn(status);

//         mockMvc.perform(post("/api/v1/mobile/register/{device-id}", deviceId)
//                 .contentType(MediaType.APPLICATION_JSON)
//                 .header("device-id", deviceId)
//                 .content(new ObjectMapper().writeValueAsString(request)))
//                 .andExpect(status().isOk());

//         verify(registrationService).handleRegistrationRequest(anyString(), anyString());
//         verify(registrationService).generateStatusByLpaUser(null, deviceId);
//     }

//     @Test
//     void testGetUserById() throws Exception {
//         String deviceId = "device-123";
//         String lpaId = "lpa-123";
//         RegistrationStatus status = new RegistrationStatus();
//         when(registrationService.getRegistrationStatusByLpaIdDeviceId(lpaId, deviceId)).thenReturn(status);

//         mockMvc.perform(get("/api/v1/mobile/register/{device-id}/{lpa-id}", deviceId, lpaId)
//                 .header("device-id", deviceId))
//                 .andExpect(status().isOk());

//         verify(registrationService).getRegistrationStatusByLpaIdDeviceId(lpaId, deviceId);
//     }

//     @Test
//     @Disabled("needs to be revisited")
//     void testVerifyFromDevice() throws Exception {
//         String deviceId = "device-123";
//         when(registrationService.handleVerificationCodeSubmission(anyString(), anyString())).thenReturn(null);


//         var requestJson = "{ 'verificationCode': '1221', 'mobile': '9818236314' }";

//         mockMvc.perform(post("/api/v1/mobile/verify/{device-id}", deviceId)
//                 .contentType(MediaType.APPLICATION_JSON)
//                 .header("device-id", deviceId)
//                 .content(requestJson))
//                 .andExpect(status().isOk());

//         verify(registrationService).handleVerificationCodeSubmission(anyString(), anyString());
//     }

//     @Test
//     void testGetStatusByDeviceId() throws Exception {
//         String deviceId = "device-123";
//         RegistrationStatus status = new RegistrationStatus();
//         when(registrationService.getRegistrationStatusByDeviceid(deviceId)).thenReturn(null);
//         when(registrationService.generateStatusByLpaUser(null, deviceId)).thenReturn(status);

//         mockMvc.perform(get("/api/v1/status/device/{device-id}", deviceId)
//                 .header("device-id", deviceId))
//                 .andExpect(status().isOk());

//         verify(registrationService).getRegistrationStatusByDeviceid(deviceId);
//         verify(registrationService).generateStatusByLpaUser(null, deviceId);
//     }

//     @Test
//     @Disabled("needs to be revisited")
//     void testGetStatusByMobile() throws Exception {
//         String mobileNumber = "9818236314";
//         RegistrationStatus status = new RegistrationStatus();
//         when(registrationService.getRegistrationStatusByMobile(mobileNumber)).thenReturn(null);
//         when(registrationService.generateStatusByLpaUser(null, null)).thenReturn(status);

//         mockMvc.perform(get("/api/v1/device/status-by-mobile/{mobile}", mobileNumber))
//                 .andExpect(status().isOk());

//         verify(registrationService).getRegistrationStatusByMobile(mobileNumber);
//         verify(registrationService).generateStatusByLpaUser(null, null);
//     }

//     @Test
//     @Disabled("needs to be revisited")
//     void testResendVerificationOtp() throws Exception {
//         String deviceId = "device-123";
//         String mobileNumber = "9818236314";
//         doNothing().when(registrationService).handleResendOtpVerificationCode(mobileNumber);

//         mockMvc.perform(post("/api/v1/mobile/resendverificationotp/{device-id}/{mobile}", deviceId, mobileNumber)
//                 .header("device-id", deviceId))
//                 .andExpect(status().isOk());

//         verify(registrationService).handleResendOtpVerificationCode(mobileNumber);
//     }

// }
