package com.smartplay.apiservices.services.impl;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ResourceServiceTest {

    private ResourceService resourceService;

    @BeforeEach
    void setUp() {
        resourceService = new ResourceService();
    }

    @Test
    void testReadLinesFromResource_ValidResource() throws IOException {
        String resourceName = "adjectives.txt";

        List<String> lines = resourceService.readLinesFromResource(resourceName);
        assertNotNull(lines);
        assertTrue(lines.size() > 0);
    }
}
