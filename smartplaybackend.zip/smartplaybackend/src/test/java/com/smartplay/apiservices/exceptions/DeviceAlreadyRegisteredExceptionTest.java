package com.smartplay.apiservices.exceptions;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

class DeviceAlreadyRegisteredExceptionTest {

    @Test
    void testExceptionMessage() {
        String message = "Device is already registered";
        String lpaId = "lpa123";
        DeviceAlreadyRegisteredException exception = new DeviceAlreadyRegisteredException(message, lpaId);

        assertEquals(message, exception.getMessage());
        assertEquals(lpaId, exception.getLpaId());
    }

    @Test
    void testResponseStatus() {
        String message = "Device is already registered";
        String lpaId = "lpa123";
        DeviceAlreadyRegisteredException exception = new DeviceAlreadyRegisteredException(message, lpaId);

        ResponseStatus responseStatus = exception.getClass().getAnnotation(ResponseStatus.class);
        assertNotNull(responseStatus);
        assertEquals(HttpStatus.CONFLICT, responseStatus.value());
    }
}
