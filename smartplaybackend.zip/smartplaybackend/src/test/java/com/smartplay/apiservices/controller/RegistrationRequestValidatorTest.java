package com.smartplay.apiservices.controller;

import static org.junit.jupiter.api.Assertions.*;

import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.smartplay.apiservices.models.request.MobileRegistrationRequest;
import com.smartplay.apiservices.models.validators.RegistrationRequestValidator;

import jakarta.validation.ConstraintValidatorContext;

class RegistrationRequestValidatorTest {

    @Mock
    private ConstraintValidatorContext context;

    private RegistrationRequestValidator validator;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        validator = new RegistrationRequestValidator();
    }

    @Test
    void testIsValidWithNullRequest() {
        assertFalse(validator.isValid(null, context));
    }

    @ParameterizedTest
    @MethodSource("provideRegistrationRequests")
    void testIsValidWithMobileNumbers(MobileRegistrationRequest request, boolean expected) {
        var actual = validator.isValid(request, context);
        assertEquals(expected, actual);
    }

    private static Stream<Arguments> provideRegistrationRequests() {
        return Stream.of(
                Arguments.of(createRegistrationRequest("+91 0918601283514"), false),
                Arguments.of(createRegistrationRequest("+91 09999918601283514"), false),
                Arguments.of(createRegistrationRequest("WAQU9876567892"), false),
                Arguments.of(createRegistrationRequest("ABCD9876541212"), false),
                Arguments.of(createRegistrationRequest("0226-895623124"), false),
                Arguments.of(createRegistrationRequest("0924645236"), false),
                Arguments.of(createRegistrationRequest("0222-895612"), false),
                Arguments.of(createRegistrationRequest("098-8956124"), false),
                Arguments.of(createRegistrationRequest("022-2413184"), false),

                Arguments.of(createRegistrationRequest("967889-2992031"), false),

                Arguments.of(createRegistrationRequest("9818236314"), true),
                Arguments.of(createRegistrationRequest("6856438922"), true),
                Arguments.of(createRegistrationRequest("7856128945"), true),
                Arguments.of(createRegistrationRequest("8945562713"), true),
                Arguments.of(createRegistrationRequest("9998564723"), true),
                Arguments.of(createRegistrationRequest("+91-9883443344"), true),
                Arguments.of(createRegistrationRequest("09883443344"), true),
                Arguments.of(createRegistrationRequest("919883443344"), true),
                Arguments.of(createRegistrationRequest("0919883443344"), true),
                Arguments.of(createRegistrationRequest("+919883443344"), true),
                Arguments.of(createRegistrationRequest("+91-9883443344"), true),
                Arguments.of(createRegistrationRequest("0091-9883443344"), true),
                Arguments.of(createRegistrationRequest("+91 9883443344"), true),
                Arguments.of(createRegistrationRequest("+91-785-612-8945"), true),
                Arguments.of(createRegistrationRequest("+91 999 856 4723"), true));
    }

    private static MobileRegistrationRequest createRegistrationRequest(String mobile) {
        MobileRegistrationRequest request = new MobileRegistrationRequest();
        request.setMobile(mobile);
        return request;
    }

    @Test
    void testIsValidWithNoEmailOrMobile() {
        MobileRegistrationRequest request = new MobileRegistrationRequest();
        assertFalse(validator.isValid(request, context));
    }
}
