package com.smartplay.apiservices.services.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.smartplay.apiservices.services.interfaces.IEncryptionDecryptionService;

@ExtendWith(MockitoExtension.class)
class CertificateBasedEncryptionDecryptionServiceTest {

    @InjectMocks
    private CertificateBasedEncryptionDecryptionService encryptionDecryptionService;
    @Mock
    private IEncryptionDecryptionService mockEncryptionDecryptionService;

    @Test
    void testEncrypt() {
        // Arrange
        String plainText = "Hello World";
        String encryptedText = "Encrypted Text";
        when(mockEncryptionDecryptionService.encrypt(plainText)).thenReturn(encryptedText);

        // Act
        String result = encryptionDecryptionService.encrypt(plainText);

        // Assert
        assertEquals(encryptedText, result);
        verify(mockEncryptionDecryptionService).encrypt(plainText);
    }

    @Test
    void testDecrypt() {
        // Arrange
        String encryptedText = "Encrypted Text";
        String decryptedText = "Hello World";
        when(mockEncryptionDecryptionService.decrypt(encryptedText)).thenReturn(decryptedText);

        // Act
        String result = encryptionDecryptionService.decrypt(encryptedText);

        // Assert
        assertEquals(decryptedText, result);
        verify(mockEncryptionDecryptionService).decrypt(encryptedText);
    }
}
