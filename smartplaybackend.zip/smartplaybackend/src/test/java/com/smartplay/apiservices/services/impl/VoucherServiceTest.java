// package com.smartplay.apiservices.services.impl;
// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.ArgumentMatchers.*;
// import static org.mockito.Mockito.*;

// import java.util.Arrays;
// import java.util.List;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;

// import com.smartplay.apiservices.models.data.PurchasedVoucher;
// import com.smartplay.apiservices.models.data.VoucherProduct;
// import com.smartplay.apiservices.models.request.VoucherOrderRequest;
// import com.smartplay.apiservices.repository.interfaces.IInMemoryRepository;
// import com.smartplay.apiservices.services.interfaces.IMapper;

// class VoucherServiceTest {

//     @Mock
//     private IInMemoryRepository<PurchasedVoucher, String> purchasedVoucherRepository;

//     @Mock
//     private IInMemoryRepository<VoucherProduct, String> voucherProductRepository;

//     private IMapper mapper;

//     @InjectMocks
//     private VoucherService voucherService;

//     @BeforeEach
//     void setUp() {
//         MockitoAnnotations.openMocks(this);
//         mapper = new MapperService();
//         voucherService = new VoucherService(purchasedVoucherRepository, voucherProductRepository, mapper);
//     }

//     @Test
//     void testSavePurchasedVoucher() {
//         PurchasedVoucher purchasedVoucher = new PurchasedVoucher();
//         when(purchasedVoucherRepository.save(purchasedVoucher)).thenReturn(purchasedVoucher);

//         PurchasedVoucher result = voucherService.savePurchasedVoucher(purchasedVoucher);

//         assertNotNull(result);
//         assertEquals(purchasedVoucher, result);
//         verify(purchasedVoucherRepository, times(1)).save(purchasedVoucher);
//     }

//     @Test
//     void testGetPurchasedVoucherByLpaId() {
//         String lpaId = "lpa123";
//         List<PurchasedVoucher> vouchers = Arrays.asList(new PurchasedVoucher(), new PurchasedVoucher());
//         when(purchasedVoucherRepository.filter(any())).thenReturn(vouchers);

//         List<PurchasedVoucher> result = voucherService.getPurchasedVoucherByLpaId(lpaId);

//         assertNotNull(result);
//         assertEquals(2, result.size());
//         verify(purchasedVoucherRepository, times(1)).filter(any());
//     }

//     @Test
//     void testGetAllProductVouchers() {
//         List<VoucherProduct> voucherProducts = Arrays.asList(new VoucherProduct(), new VoucherProduct());
//         when(voucherProductRepository.getAll()).thenReturn(voucherProducts);

//         List<VoucherProduct> result = voucherService.getAllProductVouchers();

//         assertNotNull(result);
//         assertEquals(2, result.size());
//         verify(voucherProductRepository, times(1)).getAll();
//     }

//     @Test
//     void testOrderVoucher() {
//         VoucherOrderRequest orderRequest = new VoucherOrderRequest();
//         orderRequest.setProductSKU("sku123");
//         String lpaId = "lpa123";
//         String deviceId = "device123";

//         VoucherProduct voucherProduct = new VoucherProduct();
//         voucherProduct.setProviderSku("sku123");
//         voucherProduct.setName("Test Voucher");

//         List<VoucherProduct> voucherProducts = Arrays.asList(voucherProduct);
//         when(voucherProductRepository.filter(any())).thenReturn(voucherProducts);

//         voucherService.orderVoucher(orderRequest, lpaId, deviceId);

//         verify(voucherProductRepository, times(1)).filter(any());
//         verify(purchasedVoucherRepository, times(1)).save(any());
//     }

//     @Test
//     void testOrderVoucherProductNotFound() {
//         VoucherOrderRequest orderRequest = new VoucherOrderRequest();
//         orderRequest.setProductSKU("sku123");
//         String lpaId = "lpa123";
//         String deviceId = "device123";

//         when(voucherProductRepository.filter(any())).thenReturn(Arrays.asList());

//         Exception exception = assertThrows(UnsupportedOperationException.class, () -> {
//             voucherService.orderVoucher(orderRequest, lpaId, deviceId);
//         });

//         assertEquals("Product not found", exception.getMessage());
//         verify(voucherProductRepository, times(1)).filter(any());
//         verify(purchasedVoucherRepository, times(0)).save(any());
//     }
// }
