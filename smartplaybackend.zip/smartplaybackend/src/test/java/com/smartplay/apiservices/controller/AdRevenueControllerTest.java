package com.smartplay.apiservices.controller;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.math.BigDecimal;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartplay.apiservices.models.request.RevenueDetailsRequest;
import com.smartplay.apiservices.services.interfaces.IAdRevenueService;

// @WebMvcTest(AdRevenueController.class)
class AdRevenueControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private IAdRevenueService adRevenueService;

    @InjectMocks
    private AdRevenueController adRevenueController;

    private ObjectMapper objectMapper;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(adRevenueController).build();
        this.objectMapper = new ObjectMapper();
    }

    @Test
    void testCreateRevenueDetails_Success() throws Exception {
        RevenueDetailsRequest request = new RevenueDetailsRequest();
        request.setAdId("ad-001");
        request.setLpaId("lpa-001");
        request.setDeviceId("device-001");
        request.setRevenue(new BigDecimal("100.0"));
        request.setCurrency("USD");
        request.setGamePackageId("gamePackageId");
        request.setAdType("adType");
        request.setNetworkName("networkName");
        request.setRegisteredDeviceIp("127.0.0.1");

        var requestJson = objectMapper.writeValueAsString(request);

        mockMvc.perform(post("/api/v1/adrevenue/device-001/lpa-001")
                .header("device-id", "device-001")
                .contentType("application/json")
                .content(requestJson))
                .andExpect(status().isOk());

        verify(adRevenueService, times(1)).save(any(RevenueDetailsRequest.class));
    }

    @Test
    void testCreateRevenueDetails_MismatchedLpaId() throws Exception {
        RevenueDetailsRequest request = new RevenueDetailsRequest();
        request.setLpaId("wrongLpaId");
        request.setDeviceId("deviceId");
        request.setRevenue(new BigDecimal("100.0"));
        request.setCurrency("USD");
        request.setGamePackageId("gamePackageId");
        request.setAdType("adType");
        request.setNetworkName("networkName");
        request.setRegisteredDeviceIp("127.0.0.1");

        mockMvc.perform(post("/api/v1/adrevenue/deviceId/testLpaId/")
                .header("device-id", "deviceId")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());

        verify(adRevenueService, times(0)).save(any(RevenueDetailsRequest.class));
    }

    @Test
    void testCreateRevenueDetails_MismatchedDeviceId() throws Exception {
        RevenueDetailsRequest request = new RevenueDetailsRequest();
        request.setLpaId("testLpaId");
        request.setDeviceId("wrongDeviceId");
        request.setRevenue(new BigDecimal("100.0"));
        request.setCurrency("USD");
        request.setGamePackageId("gamePackageId");
        request.setAdType("adType");
        request.setNetworkName("networkName");
        request.setRegisteredDeviceIp("127.0.0.1");

        mockMvc.perform(post("/api/v1/adrevenue/deviceId/testLpaId/")
                .header("device-id", "deviceId")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());

        verify(adRevenueService, times(0)).save(any(RevenueDetailsRequest.class));
    }

    @Test
    void testCreateRevenueDetails_InvalidRequestBody() throws Exception {
        String invalidRequestBody = "{ \"invalidField\": \"value\" }";

        mockMvc.perform(post("/api/v1/adrevenue/deviceId/testLpaId/")
                .header("device-id", "deviceId")
                .contentType("application/json")
                .content(invalidRequestBody))
                .andExpect(status().isBadRequest());

        verify(adRevenueService, times(0)).save(any(RevenueDetailsRequest.class));
    }

    @Test
    void testCreateRevenueDetails_BadRequest_01() throws Exception {
        RevenueDetailsRequest request = new RevenueDetailsRequest();
        request.setAdId("ad-001");
        request.setLpaId("lpa-001b");
        request.setDeviceId("device-001");
        request.setRevenue(new BigDecimal("100.0"));
        request.setCurrency("USD");
        request.setGamePackageId("gamePackageId");
        request.setAdType("adType");
        request.setNetworkName("networkName");
        request.setRegisteredDeviceIp("127.0.0.1");

        var requestJson = objectMapper.writeValueAsString(request);

        mockMvc.perform(post("/api/v1/adrevenue/device-001/lpa-001")
                .header("device-id", "device-001")
                .contentType("application/json")
                .content(requestJson))
                .andExpect(status().isBadRequest());

    }
    @Test
    void testCreateRevenueDetails_BadRequest_02() throws Exception {
        RevenueDetailsRequest request = new RevenueDetailsRequest();
        request.setAdId("ad-001");
        request.setLpaId("lpa-001");
        request.setDeviceId("device-001b");
        request.setRevenue(new BigDecimal("100.0"));
        request.setCurrency("USD");
        request.setGamePackageId("gamePackageId");
        request.setAdType("adType");
        request.setNetworkName("networkName");
        request.setRegisteredDeviceIp("127.0.0.1");

        var requestJson = objectMapper.writeValueAsString(request);

        mockMvc.perform(post("/api/v1/adrevenue/device-001/lpa-001")
                .header("device-id", "device-001")
                .contentType("application/json")
                .content(requestJson))
                .andExpect(status().isBadRequest());

    }
}
