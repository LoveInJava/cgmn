package com.smartplay.apiservices.models.data;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class SmartPlayGamePointTest {

    // @Test
    // void testGetEventUuid() {
    //     UUID eventUuid = UUID.randomUUID();
    //     UserSmartPlayGamePoint gamePoint = new UserSmartPlayGamePoint();
    //     gamePoint.setEventUuid(eventUuid);
    //     Assertions.assertEquals(eventUuid, gamePoint.getEventUuid());
    // }

    // @Test
    // void testGetActionDateTime() {
    //     LocalDateTime actionDateTime = LocalDateTime.now();
    //     UserSmartPlayGamePoint gamePoint = new UserSmartPlayGamePoint();
    //     gamePoint.setActionDateTime(actionDateTime);
    //     Assertions.assertEquals(actionDateTime, gamePoint.getActionDateTime());
    // }

    // @Test
    // void testGetGameId() {
    //     String gameId = "12345";
    //     UserSmartPlayGamePoint gamePoint = new UserSmartPlayGamePoint();
    //     gamePoint.setGameId(gameId);
    //     Assertions.assertEquals(gameId, gamePoint.getGameId());
    // }

    @Test
    void testGetLpaId() {
        String lpaId = "player123";
        UserSmartPlayGamePoint gamePoint = new UserSmartPlayGamePoint();
        gamePoint.setLpaId(lpaId);
        Assertions.assertEquals(lpaId, gamePoint.getLpaId());
    }

    // @Test
    // void testGetRequestId() {
    //     String requestId = UUID.randomUUID().toString();
    //     UserSmartPlayGamePoint gamePoint = new UserSmartPlayGamePoint();
    //     gamePoint.setRequestId(requestId);
    //     Assertions.assertEquals(requestId, gamePoint.getRequestId());
    // }

    // @Test
    // void testGetPoints() {
    //     int points = 100;
    //     UserSmartPlayGamePoint gamePoint = new UserSmartPlayGamePoint();
    //     gamePoint.setPoints(points);
    //     Assertions.assertEquals(points, gamePoint.getPoints());
    // }

    // @Test
    // void testGetId() {
    //     String requestId = UUID.randomUUID().toString();
    //     UserSmartPlayGamePoint gamePoint = new UserSmartPlayGamePoint();
    //     gamePoint.setRequestId(requestId);
    //     // Assertions.assertEquals(requestId, gamePoint.getId());
    // }
}
