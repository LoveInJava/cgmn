package com.smartplay.apiservices.tools;

import static org.junit.jupiter.api.Assertions.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.CategoryResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.ProductListResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.ProductResponse;

class SerializeDeserializeTest {

    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    @ParameterizedTest
    @MethodSource("getProductTests")
    void testDeserializeProductResponse(String jsonContent, String expectedId, String expectedSku,
            String expectedName) {
        // Arrange

        // Act
        ProductResponse productResponse = deserializeJson(jsonContent, ProductResponse.class);

        // Assert
        assertNotNull(productResponse);

        assertEquals(expectedId, productResponse.getId());
        assertEquals(expectedSku, productResponse.getSku());
        assertEquals(expectedName, productResponse.getName());
    }

    @ParameterizedTest
    @MethodSource("getProductByCategoryTests")
    void testDeserializeProductListByCategoryResponse(String jsonContent, int productCount) {
        // Arrange

        // Act
        ProductListResponse productResponse = deserializeJson(jsonContent, ProductListResponse.class);

        // Assert
        assertNotNull(productResponse);

        assertEquals(productCount, productResponse.getProductsCount());
        assertEquals(productCount, productResponse.getProducts().size());
    }

    @ParameterizedTest
    @MethodSource("getCategoriesTests")
    void testDeserializeCategoriesResponse(String jsonContent) {
        // Arrange

        // Act
        CategoryResponse categoriesResponse = deserializeJson(jsonContent, CategoryResponse.class);

        // Assert
        assertNotNull(categoriesResponse);

    }

    private static Stream<Arguments> getCategoriesTests() throws IOException {
        return Stream.of(
                Arguments.of(getJsonContent("products/categories_example.json")),
                Arguments.of(getJsonContent("products/categories.json")));
    }
    
    private static Stream<Arguments> getProductByCategoryTests() throws IOException {
        return Stream.of(
                Arguments.of(getJsonContent("products/productlist_example.json"),2),
                Arguments.of(getJsonContent("products/CAT_121_products.json"), 16));
    }

    private static Stream<Arguments> getProductTests() throws IOException {
        return Stream.of(
                Arguments.of("{ \"id\": \"66\",\"sku\": \"EGCGBFK001\",\"name\": \"Fastrack E-Gift Card\"}", "66",
                        "EGCGBFK001", "Fastrack E-Gift Card"),
                Arguments.of(getJsonContent("products/EGCGBFK001.json"), "66", "EGCGBFK001", "Fastrack E-Gift Card"),
                Arguments.of(getJsonContent("products/CNPIN.json"),"324", "CNPIN", "API TESTING - CN & PIN"),
                Arguments.of(getJsonContent("products/product_example.json"), "385", "testsku25", "testsku25"));
    }

    private static String getJsonContent(String resourceName) throws IOException {
        List<String> lines = readAllLinesFromResource(resourceName);
        return String.join("\n", lines);
    }

    private static List<String> readAllLinesFromResource(String resourceName) throws IOException {
        List<String> lines = new ArrayList<>();
        try (InputStream inputStream = SerializeDeserializeTest.class.getClassLoader()
                .getResourceAsStream(resourceName);
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
        }
        return lines;
    }

    private <T> T deserializeJson(String jsonContent, Class<T> valueType) {
        try {
            return objectMapper.readValue(jsonContent, valueType);
        } catch (IOException e) {
            System.out.println("Error deserializing JSON: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
}