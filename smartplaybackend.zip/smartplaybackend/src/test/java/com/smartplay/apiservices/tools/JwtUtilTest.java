package com.smartplay.apiservices.tools;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;

class JwtUtilTest {

    private static final String VALID_TOKEN = "valid.token.here";
    private static final String EXPIRED_TOKEN = "expired.token.here";
    private static final String INVALID_TOKEN = "invalid.token.here";

    private DecodedJWT validJwt;
    private DecodedJWT expiredJwt;

    @BeforeEach
    public void setUp() {
        validJwt = mock(DecodedJWT.class);
        expiredJwt = mock(DecodedJWT.class);

        when(validJwt.getExpiresAt()).thenReturn(new Date(System.currentTimeMillis() + 10000)); // 10 seconds in the future
        when(expiredJwt.getExpiresAt()).thenReturn(new Date(System.currentTimeMillis() - 10000)); // 10 seconds in the past
    }

    @Test
    void testGetExpirationDate_ValidToken() {
        try (MockedStatic<JWT> mockedJWT = Mockito.mockStatic(JWT.class)) {
            mockedJWT.when(() -> JWT.decode(VALID_TOKEN)).thenReturn(validJwt);

            Date expirationDate = JwtUtil.getExpirationDate(VALID_TOKEN);
            assertNotNull(expirationDate);
            assertTrue(expirationDate.after(new Date()));
        }
    }

    @Test
    void testGetExpirationDate_InvalidToken() {
        Date expirationDate = JwtUtil.getExpirationDate(INVALID_TOKEN);
        assertNotNull(expirationDate);
        assertEquals(new Date(0), expirationDate);
    }

    @Test
    void testIsTokenExpired_ExpiredToken() {
        try (MockedStatic<JWT> mockedJWT = Mockito.mockStatic(JWT.class)) {
            mockedJWT.when(() -> JWT.decode(EXPIRED_TOKEN)).thenReturn(expiredJwt);

            assertTrue(JwtUtil.isTokenExpired(EXPIRED_TOKEN));
        }
    }

    @Test
    void testIsTokenExpired_ValidToken() {
        try (MockedStatic<JWT> mockedJWT = Mockito.mockStatic(JWT.class)) {
            mockedJWT.when(() -> JWT.decode(VALID_TOKEN)).thenReturn(validJwt);

            assertFalse(JwtUtil.isTokenExpired(VALID_TOKEN));
        }
    }

    @Test
    void testIsJwtTokenInvalidOrExpired_EmptyToken() {
        assertTrue(JwtUtil.isJwtTokenInvalidOrExpired(""));
    }

    @Test
    void testIsJwtTokenInvalidOrExpired_ExpiredToken() {
        try (MockedStatic<JWT> mockedJWT = Mockito.mockStatic(JWT.class)) {
            mockedJWT.when(() -> JWT.decode(EXPIRED_TOKEN)).thenReturn(expiredJwt);

            assertTrue(JwtUtil.isJwtTokenInvalidOrExpired(EXPIRED_TOKEN));
        }
    }

    @Test
    void testIsJwtTokenInvalidOrExpired_ValidToken() {
        try (MockedStatic<JWT> mockedJWT = Mockito.mockStatic(JWT.class)) {
            mockedJWT.when(() -> JWT.decode(VALID_TOKEN)).thenReturn(validJwt);

            assertFalse(JwtUtil.isJwtTokenInvalidOrExpired(VALID_TOKEN));
        }
    }
}