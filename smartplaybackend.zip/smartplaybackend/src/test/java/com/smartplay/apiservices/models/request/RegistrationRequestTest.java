package com.smartplay.apiservices.models.request;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class RegistrationRequestTest {

    @Test
    void testValidMobileNumbers() {
        String[] validMobileNumbers = {
            "+919876543210",
            "+91-9876543210",
            "09876543210",
            "9876543210",
            "9433214152",
            "9818236314"
        };

        for (String mobileNumber : validMobileNumbers) {
            assertTrue(mobileNumber.matches(MobileRegistrationRequest.MOBILE_REGEX));
        }
    }

    @Test
    void testInvalidMobileNumbers() {
        String[] invalidMobileNumbers = {
            "+911234567890", // Invalid country code
            "+91987654321", // Invalid length
            "1234567890", // Invalid format
            "987654321a" // Contains non-digit characters
        };

        for (String mobileNumber : invalidMobileNumbers) {
            assertFalse(mobileNumber.matches(MobileRegistrationRequest.MOBILE_REGEX));
        }
    }
}
