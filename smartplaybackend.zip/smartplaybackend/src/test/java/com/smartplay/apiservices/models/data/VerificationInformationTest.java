package com.smartplay.apiservices.models.data;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.smartplay.apiservices.models.enums.VerificationStatus;

class VerificationInformationTest {

    private VerificationInformation verificationInformation;

    @BeforeEach
    void setUp() {
        verificationInformation = new VerificationInformation();
    }

    @Test
    void testGetSetVerificationStatus() {
        // Arrange
        VerificationStatus verificationStatus = VerificationStatus.NOTVERIFIED;

        // Act
        verificationInformation.setVerificationStatus(verificationStatus);
        VerificationStatus retrievedVerificationStatus = verificationInformation.getVerificationStatus();

        // Assert
        assertEquals(verificationStatus, retrievedVerificationStatus);
    }

    @Test
    void testGetSetDatetime() {
        // Arrange
        LocalDateTime datetime = LocalDateTime.now();

        // Act
        verificationInformation.setDatetime(datetime);
        LocalDateTime retrievedDatetime = verificationInformation.getDatetime();

        // Assert
        assertEquals(datetime, retrievedDatetime);
    }

    @Test
    void testGetSetVerificationCode() {


        LocalDateTime startTime = LocalDateTime.of(2024, 9, 7, 16, 52,14);
        LocalDateTime endTime = LocalDateTime.of(2024, 9, 7, 16, 57,14);

        long hoursBetween = ChronoUnit.HOURS.between(startTime, endTime);
        long minutesBetween = ChronoUnit.MINUTES.between(startTime, endTime);

        System.out.println("Hours between: " + hoursBetween); // Should print 0 if less than 1 hour
        System.out.println("Minutes between: " + minutesBetween); // Should print the actual difference in minutes

        // Arrange
        String verificationCode = "123456";

        // Act
        verificationInformation.setVerificationCode(verificationCode);
        String retrievedVerificationCode = verificationInformation.getVerificationCode();

        // Assert
        assertEquals(verificationCode, retrievedVerificationCode);
    }

}
