package com.smartplay.apiservices.services.impl;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.smartplay.apiservices.services.interfaces.IRandomInformationGenerator;

@ExtendWith(MockitoExtension.class)
class RandomInformationGeneratorServiceTest {

    private IRandomInformationGenerator randomInformationGenerator;

    @BeforeEach
    void setUp() {
        randomInformationGenerator = new RandomInformationGeneratorService();
    }

    @Test
    void testGenerateVerificationCode() {
        // Act
        String verificationCode = randomInformationGenerator.generateVerificationCode();

        // Assert
        assertNotNull(verificationCode);
        assertEquals(6, verificationCode.length());
    }
}
