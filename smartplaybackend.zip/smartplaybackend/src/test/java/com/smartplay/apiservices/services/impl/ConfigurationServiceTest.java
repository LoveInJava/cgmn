package com.smartplay.apiservices.services.impl;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.smartplay.apiservices.models.response.About;
import com.smartplay.apiservices.models.response.Faq;
import com.smartplay.apiservices.models.response.Games;
import com.smartplay.apiservices.models.response.News;
import com.smartplay.apiservices.models.response.PrivacyPolicy;

class ConfigurationServiceTest {

    private ConfigurationService configurationService;

    @BeforeEach
    public void setUp() {
        configurationService = new ConfigurationService();
    }

    // @Test
    // void testGetDefaultBonusPoint() {
    //     int bonusPoint = configurationService.getDefaultBonusPoint();
    //     assertEquals(5000, bonusPoint);
    // }

    @Test
    void testGetAbout() {
        About about = configurationService.getAbout();
        assertNotNull(about);
        assertNotNull(about.getInfo());
        assertEquals("sample about", about.getInfo().getDescription());
        assertEquals("banner text", about.getInfo().getBanner());
        assertEquals("https://demo.sirv.com/nuphar.jpg?w=100", about.getInfo().getWebUrl());
    }

    @Test
    void testGetNews() {
        News news = configurationService.getNews();
        assertNotNull(news);
        assertNotNull(news.getInfo());
        assertEquals("sample news", news.getInfo().getDescription());
        assertEquals("banner text", news.getInfo().getBanner());
        assertEquals("https://demo.sirv.com/nuphar.jpg?w=100", news.getInfo().getWebUrl());
        assertEquals(2, news.getDetails().size());
    }

    @Test
    void testGetFaq() {
        Faq faq = configurationService.getFaq();
        assertNotNull(faq);
        assertNotNull(faq.getInfo());
        assertEquals("https://storage.googleapis.com/smartplay-app-images/qna.json", faq.getInfo().getWebUrl());
    }

    @Test
    void testGetPrivacyPolicy() {
        PrivacyPolicy privacyPolicy = configurationService.getPrivacyPolicy();
        assertNotNull(privacyPolicy);
        assertNotNull(privacyPolicy.getInfo());
        assertEquals("Privacy Policy Document", privacyPolicy.getInfo().getBanner());
        assertEquals("https://storage.googleapis.com/smartplay-app-images/tnc.html", privacyPolicy.getInfo().getWebUrl());
    }

    @Test
    void testGetGames() {
        Games games = configurationService.getGames();
        assertNotNull(games);
        assertNotNull(games.getInfo());
        assertEquals("List of games", games.getInfo().getDescription());
        assertEquals("List of games", games.getInfo().getBanner());
        assertEquals("https://demo.sirv.com/nuphar.jpg?w=100", games.getInfo().getWebUrl());
        assertEquals(2, games.getDetails().size());
    }
}
