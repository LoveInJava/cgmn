package com.smartplay.apiservices.services.impl;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.smartplay.apiservices.models.data.PinelabsProduct;
import com.smartplay.apiservices.models.data.VoucherProduct;
import com.smartplay.apiservices.models.response.PurchasedVoucher;
import com.smartplay.apiservices.models.response.PurchasedVoucherResponse;
import com.smartplay.apiservices.models.response.Voucher;
import com.smartplay.apiservices.models.response.VoucherResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.Currency;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.Images;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.Price;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.ProductResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.Tnc;

class MapperServiceTest {

    private MapperService mapperService;

    @BeforeEach
    void setUp() {
        mapperService = new MapperService();
    }

    @Test
    void testMapPurchasedVoucher() {
        PurchasedVoucher purchasedVoucher = new PurchasedVoucher();
        // Set properties of purchasedVoucher as needed
        purchasedVoucher.setId("1");
        purchasedVoucher.setVoucherName("Test Voucher");

        PurchasedVoucherResponse result = mapperService.map(purchasedVoucher);

        assertNotNull(result);
        assertEquals("1", result.getId());
        assertEquals("Test Voucher", result.getVoucherName());
    }

    @Test
    void testMapPurchasedVoucherList() {
        PurchasedVoucher purchasedVoucher1 = new PurchasedVoucher();
        purchasedVoucher1.setId("1");
        purchasedVoucher1.setVoucherName("Voucher 1");

        PurchasedVoucher purchasedVoucher2 = new PurchasedVoucher();
        purchasedVoucher2.setId("2");
        purchasedVoucher2.setVoucherName("Voucher 2");

        List<PurchasedVoucher> purchasedVoucherList = Arrays.asList(purchasedVoucher1, purchasedVoucher2);

        List<PurchasedVoucherResponse> result = mapperService.map(purchasedVoucherList);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("1", result.get(0).getId());
        assertEquals("Voucher 1", result.get(0).getVoucherName());
        assertEquals("2", result.get(1).getId());
        assertEquals("Voucher 2", result.get(1).getVoucherName());
    }

    @Test
    void testMapVoucherProduct() {
        VoucherProduct voucherProduct = new VoucherProduct();
        // Set properties of voucherProduct as needed
        voucherProduct.setId("1");
        voucherProduct.setDescription("Test Product");

        Voucher result = mapperService.map(voucherProduct);

        assertNotNull(result);
        assertEquals("Test Product", result.getDescription());
    }

    // @Test
    // void testMapToPurchasedVoucherList() {
    //     VoucherOrderRequest orderRequest1 = new VoucherOrderRequest();
    //     orderRequest1.setProductSKU("sku001");

    //     VoucherOrderRequest orderRequest2 = new VoucherOrderRequest();
    //     orderRequest2.setProductSKU("sku002");

    //     List<VoucherOrderRequest> orderRequestList = Arrays.asList(orderRequest1, orderRequest2);

    //     String voucherName = "Test Voucher";
    //     String lpaId = "lpa123";

    //     List<PurchasedVoucher> result = orderRequestList.stream()
    //         .map(orderRequest -> mapperService.mapToPurchasedVoucher(orderRequest, voucherName, lpaId))
    //         .toList();

    //     assertNotNull(result);
    //     assertEquals(2, result.size());
    //     assertEquals("sku001", result.get(0).getSku());
    //     assertEquals("Test Voucher", result.get(0).getVoucherName());
    //     assertEquals("lpa123", result.get(0).getLpaId());
    //     assertEquals("sku002", result.get(1).getSku());
    //     assertEquals("Test Voucher", result.get(1).getVoucherName());
    //     assertEquals("lpa123", result.get(1).getLpaId());
    // }

    @Test
    void testMapToVouchers() {
        VoucherProduct voucherProduct1 = new VoucherProduct();
        voucherProduct1.setId("1");
        voucherProduct1.setDescription("Product 1");

        VoucherProduct voucherProduct2 = new VoucherProduct();
        voucherProduct2.setId("2");
        voucherProduct2.setDescription("Product 2");

        List<VoucherProduct> voucherProductList = Arrays.asList(voucherProduct1, voucherProduct2);

        List<Voucher> result = mapperService.mapToVouchers(voucherProductList);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Product 1", result.get(0).getDescription());
        assertEquals("Product 2", result.get(1).getDescription());
    }

    @Test
    void testMapPinelabsProductToVoucherResponse() {
        PinelabsProduct pinelabsProduct1 = new PinelabsProduct();
        ProductResponse productResponse1 = new ProductResponse();
        productResponse1.setSku("sku1");
        productResponse1.setName("Product 1");
        productResponse1.setDescription("Description 1");
        productResponse1.setImages(Images.builder().thumbnail("thumbnail1").build());
        productResponse1.setTnc(new Tnc("link1", "content1"));

        Currency currency = new Currency("INR", "₹","356");
        Price price1 = Price.builder()
            .price("1000")
            .type("fixed")
            .min("500")
            .max("1500")
            .denominations(Arrays.asList("500", "1000", "1500"))
            .currency(currency)
            .build();

        productResponse1.setPrice(price1);

        pinelabsProduct1.setProductDetails(productResponse1);

        PinelabsProduct pinelabsProduct2 = new PinelabsProduct();
        ProductResponse productResponse2 = new ProductResponse();
        productResponse2.setSku("sku2");
        productResponse2.setName("Product 2");
        productResponse2.setDescription("Description 2");
        productResponse2.setImages(Images.builder().thumbnail("thumbnail2").build());
        productResponse2.setTnc(new Tnc("link2", "content2"));
        Price price2 = Price.builder()
            .price("1000")
            .type("fixed")
            .min("500")
            .max("1500")
            .denominations(Arrays.asList("300", "400"))
            .currency(currency)
            .build();

        productResponse1.setPrice(price1);
        productResponse2.setPrice(price2);
        pinelabsProduct2.setProductDetails(productResponse2);

        List<PinelabsProduct> pinelabsProducts = Arrays.asList(pinelabsProduct1, pinelabsProduct2);

        VoucherResponse result = mapperService.mapPinelabsProductToVoucherResponse(pinelabsProducts);

        assertNotNull(result);
        assertEquals(2, result.getVouchers().size());
        assertEquals("sku1", result.getVouchers().get(0).getSku());
        assertEquals("Product 1", result.getVouchers().get(0).getName());
        assertEquals("Description 1", result.getVouchers().get(0).getDescription());
        assertEquals("thumbnail1", result.getVouchers().get(0).getImage());
        assertEquals("INR", result.getVouchers().get(0).getCurrencyID());
        assertEquals("content1", result.getVouchers().get(0).getTnc());
        assertEquals("link1", result.getVouchers().get(0).getTncUrl());
        assertEquals(Arrays.asList(new BigInteger("500"), new BigInteger("1000"), new BigInteger("1500")), result.getVouchers().get(0).getDenominations());

        assertEquals("sku2", result.getVouchers().get(1).getSku());
        assertEquals("Product 2", result.getVouchers().get(1).getName());
        assertEquals("Description 2", result.getVouchers().get(1).getDescription());
        assertEquals("thumbnail2", result.getVouchers().get(1).getImage());
        assertEquals("INR", result.getVouchers().get(1).getCurrencyID());
        assertEquals("content2", result.getVouchers().get(1).getTnc());
        assertEquals("link2", result.getVouchers().get(1).getTncUrl());
        assertEquals(Arrays.asList(new BigInteger("300"), new BigInteger("400")), result.getVouchers().get(1).getDenominations());

        assertEquals(1, result.getCurrencies().size());
        assertEquals("INR", result.getCurrencies().get(0).getName());
        assertEquals("₹", result.getCurrencies().get(0).getSymbol());
    }

    @Test
    void testMapToVoucher() {
        ProductResponse productResponse = new ProductResponse();
        productResponse.setSku("sku1");
        productResponse.setName("Product 1");
        productResponse.setDescription("Description 1");
        productResponse.setImages(Images.builder().thumbnail("thumbnail1").build());
        productResponse.setTnc(new Tnc("link1", "content1"));
        Currency currency = new Currency("INR", "₹","356");
        Price price1 = Price.builder()
            .price("1000")
            .type("fixed")
            .min("500")
            .max("1500")
            .denominations(Arrays.asList("500", "1000", "1500"))
            .currency(currency)
            .build();

        productResponse.setPrice(price1);

        Voucher result = mapperService.mapToVoucher(productResponse);

        assertNotNull(result);
        assertEquals("sku1", result.getSku());
        assertEquals("Product 1", result.getName());
        assertEquals("Description 1", result.getDescription());
        assertEquals("thumbnail1", result.getImage());
        assertEquals("INR", result.getCurrencyID());
        assertEquals("content1", result.getTnc());
        assertEquals("link1", result.getTncUrl());
        assertEquals(Arrays.asList(new BigInteger("500"), new BigInteger("1000"), new BigInteger("1500")), result.getDenominations());
    }
}