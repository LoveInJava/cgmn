package com.smartplay.apiservices.exceptions;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

class PhoneNumberAlreadyRegisteredExceptionTest {

    @Test
    void testExceptionMessage() {
        String message = "Phone number is already registered";
        String lpaId = "lpa123";
        String mobileNumber = "1234567890";
        PhoneNumberAlreadyRegisteredException exception = new PhoneNumberAlreadyRegisteredException(message, lpaId, mobileNumber);

        assertEquals(message, exception.getMessage());
        assertEquals(lpaId, exception.getLpaId());
        assertEquals(mobileNumber, exception.getMobileNumber());
    }

    @Test
    void testResponseStatus() {
        String message = "Phone number is already registered";
        String lpaId = "lpa123";
        String mobileNumber = "1234567890";
        PhoneNumberAlreadyRegisteredException exception = new PhoneNumberAlreadyRegisteredException(message, lpaId, mobileNumber);

        ResponseStatus responseStatus = exception.getClass().getAnnotation(ResponseStatus.class);
        assertNotNull(responseStatus);
        assertEquals(HttpStatus.SEE_OTHER, responseStatus.value());
    }
}
