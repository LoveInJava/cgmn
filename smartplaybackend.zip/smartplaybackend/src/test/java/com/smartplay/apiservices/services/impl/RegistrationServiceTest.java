// package com.smartplay.apiservices.services.impl;


// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.ArgumentMatchers.*;
// import static org.mockito.Mockito.*;

// import java.util.UUID;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;

// import com.smartplay.apiservices.exceptions.InvalidPhoneNumberException;
// import com.smartplay.apiservices.exceptions.InvalidVerificationCodeException;
// import com.smartplay.apiservices.exceptions.PhoneNumberAlreadyVerifiedException;
// import com.smartplay.apiservices.models.data.LpaUser;
// import com.smartplay.apiservices.models.response.RegistrationStatus;
// import com.smartplay.apiservices.services.interfaces.IAvatarNameService;
// import com.smartplay.apiservices.services.interfaces.IGamePointService;
// import com.smartplay.apiservices.services.interfaces.INotificationService;
// import com.smartplay.apiservices.services.interfaces.IUserRegistrationService;

// class RegistrationServiceTest {

//     @Mock
//     private IUserRegistrationService userRegistrationService;

//     @Mock
//     private INotificationService notificationService;

//     @Mock
//     private IAvatarNameService avatarNameService;

//     @Mock
//     private IGamePointService gamePointService;

//     @InjectMocks
//     private RegistrationService registrationService;

//     @BeforeEach
//     void setUp() {
//         MockitoAnnotations.openMocks(this);
//     }

//     @Test
//     void testHandleRegistrationRequest_InvalidDeviceId() {
//         assertThrows(RuntimeException.class, () -> {
//             registrationService.handleRegistrationRequest("1234567890", "");
//         });
//     }

//     @Test
//     void testHandleRegistrationRequest_InvalidPhoneNumber() {
//         when(userRegistrationService.isPhoneNumberValid(anyString())).thenReturn(false);
//         assertThrows(InvalidPhoneNumberException.class, () -> {
//             registrationService.handleRegistrationRequest("invalid", "deviceId");
//         });
//     }

//     @Test
//     void testHandleRegistrationRequest_PhoneNumberAlreadyVerifiedWhenuserAlreadyRegistered() {
//         LpaUser lpaUser = new LpaUser();
//         lpaUser.setPhoneNumber("9818236315");
//         lpaUser.setPhoneNumberVerified(true);
//         when(userRegistrationService.getByDeviceId(anyString())).thenReturn(lpaUser);
//         when(userRegistrationService.isPhoneNumberValid(anyString())).thenReturn(true);

//         assertThrows(PhoneNumberAlreadyVerifiedException.class, () -> {
//             registrationService.handleRegistrationRequest("9818236314", "deviceId");
//         });
//     }

//     @Test
//     void testHandleRegistrationRequest_PhoneNumberAlreadyVerifiedWhenUserNotRegistered() {
//         when(userRegistrationService.getByDeviceId(anyString())).thenReturn(null);
//         when(userRegistrationService.isPhoneNumberValid(anyString())).thenReturn(true);
//         when(userRegistrationService.isPhoneNumberVerified(anyString())).thenReturn(true);

//         assertThrows(PhoneNumberAlreadyVerifiedException.class, () -> {
//             registrationService.handleRegistrationRequest("9818236314", "deviceId");
//         });
//     }

//     // @Test
//     // void testHandleRegistrationRequest_NewUser() {

//     //     when(userRegistrationService.getByDeviceId(anyString())).thenReturn(null);
//     //     when(avatarNameService.getUniqueAvatarNameDbVerified()).thenReturn("uniqueAvatar");
//     //     when(userRegistrationService.saveRegistrationRequest(any(LpaUser.class))).thenReturn(new LpaUser());

//     //     when(userRegistrationService.isPhoneNumberValid(anyString())).thenReturn(true);
//     //     when(userRegistrationService.generateVerificationCode()).thenReturn("123456");

//     //     LpaUser user = registrationService.handleRegistrationRequest("9818236314", "deviceId");

//     //     assertNotNull(user);
//     //     verify(notificationService, times(1)).sendVerificationCode(anyString(), anyString());
//     //     verify(gamePointService, times(1)).allocateBonusPoints(anyString(), anyString());
//     // }

//     @Test
//     void testHandleVerificationCodeSubmission_InvalidCode() {
//         when(userRegistrationService.validateOtp(anyString(), anyString())).thenReturn(false);

//         assertThrows(InvalidVerificationCodeException.class, () -> {
//             registrationService.handleVerificationCodeSubmission("1234567890", "invalidCode");
//         });
//     }

//     @Test
//     void testHandleVerificationCodeSubmission_ValidCode() {
//         when(userRegistrationService.validateOtp(anyString(), anyString())).thenReturn(true);
//         when(userRegistrationService.updateOtpVerificationStatus(anyString(), anyBoolean())).thenReturn(new LpaUser());

//         LpaUser user = registrationService.handleVerificationCodeSubmission("1234567890", "validCode");

//         assertNotNull(user);
//     }

//     @Test
//     void testGetRegistrationStatus_InvalidPhoneNumber() {
//         when(userRegistrationService.isPhoneNumberValid(anyString())).thenReturn(false);

//         assertThrows(InvalidPhoneNumberException.class, () -> {
//             registrationService.getRegistrationStatus("invalid", "deviceId");
//         });
//     }

//     @Test
//     void testGetRegistrationStatus_Valid() {
//         when(userRegistrationService.isPhoneNumberValid(anyString())).thenReturn(true);
//         when(userRegistrationService.getByPhoneNumberDeviceId(anyString(), anyString()))
//         .thenReturn(LpaUser.builder().lpaId(UUID.randomUUID().toString()).build());

//         RegistrationStatus status = registrationService.getRegistrationStatus("1234567890", "deviceId");

//         assertNotNull(status);
//     }

//     @Test
//     void testGetRegistrationStatusByLpaIdDeviceId() {
//         when(userRegistrationService.getByLpaIdDeviceId(anyString(), anyString())).thenReturn(LpaUser.builder().lpaId(UUID.randomUUID().toString()).build());

//         RegistrationStatus status = registrationService.getRegistrationStatusByLpaIdDeviceId("lpaId", "deviceId");

//         assertNotNull(status);
//     }

//     @Test
//     void testHandleResendOtpVerificationCode() {
//         when(userRegistrationService.updateOtpVerificationStatus(anyString(), anyBoolean())).thenReturn(new LpaUser());
//         when(userRegistrationService.generateVerificationCode()).thenReturn("123456");

//         LpaUser user = registrationService.handleResendOtpVerificationCode("1234567890");

//         assertNotNull(user);
//         verify(notificationService, times(1)).retrySendVerificationCode(anyString(), anyString());
//     }

//     @Test
//     void testGetRegistrationStatusByDeviceid() {
//         when(userRegistrationService.getByDeviceId(anyString())).thenReturn(new LpaUser());

//         LpaUser user = registrationService.getRegistrationStatusByDeviceid("deviceId");

//         assertNotNull(user);
//     }

//     @Test
//     void testGetRegistrationStatusByMobile() {
//         when(userRegistrationService.getByPhoneNumber(anyString())).thenReturn(new LpaUser());

//         LpaUser user = registrationService.getRegistrationStatusByMobile("1234567890");

//         assertNotNull(user);
//     }

//     @Test
//     void testGetRegistrationStatusByLpaid() {
//         when(userRegistrationService.getByLpaId(anyString())).thenReturn(new LpaUser());

//         LpaUser user = registrationService.getRegistrationStatusByLpaid("lpaId");

//         assertNotNull(user);
//     }

//     @Test
//     void testGetOtpByDeviceId() {
//         when(userRegistrationService.getOtpByDeviceId(anyString())).thenReturn("123456");

//         String otp = registrationService.getOtpByDeviceId("deviceId");

//         assertEquals("123456", otp);
//     }

//     @Test
//     void testGetGenerateStatusByLpaUser_PhoneNotverified() {
//         var lpauser = LpaUser.builder()
//                         .lpaId("fe48e3d6-573b-4723-a88c-d9b53bc76490")
//                         .phoneNumber("9818236314")
//                         .isPhoneNumberVerified(false)
//                         .username("testuser")
//                         .build();
//         var actual = registrationService.generateStatusByLpaUser(lpauser, "deviceId");

//         assertNotNull(actual);
//         assertEquals("testuser", actual.getUsername());
//         assertEquals("fe48e3d6-573b-4723-a88c-d9b53bc76490", actual.getLpaId());
//         assertTrue(actual.isMobileRegistered());
//         assertFalse(actual.isVerified());
//         assertFalse(actual.isDeviceRegistered());
//     }

//     @Test
//     void testGetGenerateStatusByLpaUser_Phoneverified() {
//         var lpauser = LpaUser.builder()
//                         .lpaId("fe48e3d6-573b-4723-a88c-d9b53bc76490")
//                         .phoneNumber("9818236314")
//                         .isPhoneNumberVerified(true)
//                         .username("testuser")
//                         .build();
//         var actual = registrationService.generateStatusByLpaUser(lpauser, "deviceId");

//         assertNotNull(actual);
//         assertEquals("testuser", actual.getUsername());
//         assertEquals("fe48e3d6-573b-4723-a88c-d9b53bc76490", actual.getLpaId());
//         assertTrue(actual.isMobileRegistered());
//         assertTrue(actual.isVerified());
//         assertFalse(actual.isDeviceRegistered());
//     }

//     @Test
//     void testGetGenerateStatusByLpaUser_PhoneNotRegistered() {
//         var lpauser = LpaUser.builder()
//                         .lpaId("fe48e3d6-573b-4723-a88c-d9b53bc76490")
//                         .isPhoneNumberVerified(true)
//                         .username("testuser")
//                         .build();
//         var actual = registrationService.generateStatusByLpaUser(lpauser, "deviceId");

//         assertNotNull(actual);
//         assertEquals("testuser", actual.getUsername());
//         assertEquals("fe48e3d6-573b-4723-a88c-d9b53bc76490", actual.getLpaId());
//         assertFalse(actual.isMobileRegistered());
//         assertTrue(actual.isVerified());
//         assertFalse(actual.isDeviceRegistered());
//     }
//     @Test
//     void testGetGenerateStatusByLpaUser_DeviceRegistered() {
//         var lpauser = LpaUser.builder()
//                         .lpaId("fe48e3d6-573b-4723-a88c-d9b53bc76490")
//                         .phoneNumber("9818236314")
//                         .isPhoneNumberVerified(true)
//                         .username("testuser")
//                         .build();
//         lpauser.addDeviceId("test-deviceId");
//         var actual = registrationService.generateStatusByLpaUser(lpauser, "test-deviceId");

//         assertNotNull(actual);
//         assertEquals("testuser", actual.getUsername());
//         assertEquals("fe48e3d6-573b-4723-a88c-d9b53bc76490", actual.getLpaId());
//         assertTrue(actual.isMobileRegistered());
//         assertTrue(actual.isVerified());
//         assertTrue(actual.isDeviceRegistered());
//     }
//     @Test
//     void testGetGenerateStatusByLpaUser_NotDeviceRegistered() {
//         var lpauser = createLpaUser();
//         var actual = registrationService.generateStatusByLpaUser(lpauser, "test-deviceId-002");

//         assertNotNull(actual);
//         assertEquals("testuser", actual.getUsername());
//         assertEquals("fe48e3d6-573b-4723-a88c-d9b53bc76490", actual.getLpaId());
//         assertTrue(actual.isMobileRegistered());
//         assertTrue(actual.isVerified());
//         assertFalse(actual.isDeviceRegistered());
//     }

//     private LpaUser createLpaUser() {
//         var lpauser = LpaUser.builder()
//                         .lpaId("fe48e3d6-573b-4723-a88c-d9b53bc76490")
//                         .phoneNumber("9818236314")
//                         .isPhoneNumberVerified(true)
//                         .username("testuser")
//                         .build();
//         lpauser.addDeviceId("test-deviceId-001");
//         return lpauser;
//     }

//     @Test
//     void testHandleRegistrationRequest_case1() {

//         LpaUser lpaUser = createLpaUser();
//         lpaUser.setPhoneNumber("9818236315");
//         lpaUser.setPhoneNumberVerified(true);
//         when(userRegistrationService.getByDeviceId(anyString())).thenReturn(lpaUser);

//         assertThrows(InvalidPhoneNumberException.class, () -> {
//             registrationService.handleRegistrationRequest("9818236314", "deviceId");
//         });
//     }

//     @Test
//     void testHandleRegistrationRequest_case2() {

//         LpaUser lpaUser = createLpaUser();
//         // lpaUser.setPhoneNumber("9818236315");
//         lpaUser.setPhoneNumberVerified(false);

//         // when(userRegistrationService.getByDeviceId(anyString())).thenReturn(lpaUser);
//         // when(userRegistrationService.isPhoneNumberValid(anyString())).thenReturn(true);
//         // when(userRegistrationService.saveRegistrationRequest(any(LpaUser.class))).thenReturn(new LpaUser());
//         // when(userRegistrationService.generateVerificationCode()).thenReturn("123456");

//         when(userRegistrationService.getByDeviceId(anyString())).thenReturn(lpaUser);

//         assertThrows(InvalidPhoneNumberException.class, () -> {
//             registrationService.handleRegistrationRequest("9818236314", "deviceId");
//         });
//     }

//     @Test
//     void testHandleRegistrationRequest_case3() {

//         LpaUser lpaUser = createLpaUser();
//         lpaUser.setPhoneNumber("9818236315");
//         lpaUser.setPhoneNumberVerified(true);
//         when(userRegistrationService.getByDeviceId(anyString())).thenReturn(lpaUser);

//         var actual = registrationService.handleRegistrationRequest("", "deviceId");
//         assertNotNull(actual);
//     }

// }
