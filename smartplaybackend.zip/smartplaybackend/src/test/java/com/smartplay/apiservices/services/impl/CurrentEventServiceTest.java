// package com.smartplay.apiservices.services.impl;

// import java.util.UUID;

// import org.junit.jupiter.api.extension.ExtendWith;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.junit.jupiter.MockitoExtension;

// import com.smartplay.apiservices.models.events.ResetTimerEvent;
// import com.smartplay.apiservices.repository.interfaces.IInMemoryRepository;

// @ExtendWith(MockitoExtension.class)
// class CurrentEventServiceTest {

//     @Mock
//     private IInMemoryRepository<ResetTimerEvent, UUID> currentEventRepository;

//     @InjectMocks
//     private CurrentEventService currentEventService;

//     @Test
//     void testSetCurrentEvent() {
//         // Arrange

//         ResetTimerEvent event = ResetTimerEvent.builder().source(this).eventUuid( UUID.randomUUID()).startDateTime(LocalDateTime.now()) .build();

//         // Act
//         currentEventService.setCurrentEvent(event);

//         // Assert
//         verify(currentEventRepository, times(1)).save(event);
//         assertEquals(event, currentEventService.getCurrentEvent());
//         assertNull(currentEventService.getPreviousEvent());
//     }
// }
