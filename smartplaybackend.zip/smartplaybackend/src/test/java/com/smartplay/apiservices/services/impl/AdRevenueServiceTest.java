// package com.smartplay.apiservices.services.impl;

// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.ArgumentMatchers.*;
// import static org.mockito.Mockito.*;

// import java.math.BigDecimal;
// import java.util.ArrayList;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;

// import com.smartplay.apiservices.models.data.UserAdRevenue;
// import com.smartplay.apiservices.models.request.RevenueDetailsRequest;
// import com.smartplay.apiservices.repository.interfaces.IInMemoryRepository;

// class AdRevenueServiceTest {

//     @Mock
//     private IInMemoryRepository<UserAdRevenue, String> userAdRevenueRepository;

//     @InjectMocks
//     private AdRevenueService revenueReportService;

//     @BeforeEach
//     public void setUp() {
//         MockitoAnnotations.openMocks(this);
//     }

//     @Test
//     void testSave_NewUserAdRevenue() {
//         // Arrange
//         RevenueDetailsRequest request = new RevenueDetailsRequest();
//         request.setLpaId("testLpaId");
//         request.setAdId("adId");
//         request.setDeviceId("deviceId");
//         request.setRevenue(new BigDecimal("100.0"));
//         request.setCurrency("USD");
//         request.setGamePackageId("gamePackageId");
//         request.setAdType("adType");
//         request.setNetworkName("networkName");
//         request.setRegisteredDeviceIp("127.0.0.1");

//         when(userAdRevenueRepository.get("testLpaId")).thenReturn(null);

//         // Act
//         revenueReportService.save(request);

//         // Assert
//         verify(userAdRevenueRepository, times(1)).get("testLpaId");
//         verify(userAdRevenueRepository, times(1)).save(any(UserAdRevenue.class));
//     }

//     @Test
//     void testSave_ExistingUserAdRevenue() {
//         // Arrange
//         RevenueDetailsRequest request = new RevenueDetailsRequest();
//         request.setLpaId("testLpaId");
//         request.setAdId("adId");
//         request.setDeviceId("deviceId");
//         request.setRevenue(new BigDecimal("100.0"));
//         request.setCurrency("USD");
//         request.setGamePackageId("gamePackageId");
//         request.setAdType("adType");
//         request.setNetworkName("networkName");
//         request.setRegisteredDeviceIp("127.0.0.1");

//         UserAdRevenue existingUserAdRevenue = UserAdRevenue.builder()
//                 .lpaId("testLpaId")
//                 .records(new ArrayList<>())
//                 .build();

//         when(userAdRevenueRepository.get("testLpaId")).thenReturn(existingUserAdRevenue);

//         // Act
//         revenueReportService.save(request);

//         // Assert
//         verify(userAdRevenueRepository, times(1)).get("testLpaId");
//         verify(userAdRevenueRepository, times(1)).save(existingUserAdRevenue);
//         assertEquals(1, existingUserAdRevenue.getRecords().size());
//     }

// }
