// package com.smartplay.apiservices.repository.impl;

// import static org.junit.jupiter.api.Assertions.*;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;

// class TokenRepositoryTest {

//     private PinelabTokenRepository tokenRepository;

//     @BeforeEach
//     public void setUp() {
//         tokenRepository = new PinelabTokenRepository();
//     }

//     @Test
//     void testGetToken() {
//         String expectedToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJjb25zdW1lcklkIjo3MTUsImV4cCI6MTcyNDUxOTkzMCwidG9rZW4iOiI2MGU3MGVjNTUxOTU1MmJiNzA0YjdjMjg5N2E0MjY3MiJ9.sJhXq2ZmqDiR6Fl2NMtSfDcEzGbeho74zqkUZt0RNVg";
//         String actualToken = tokenRepository.getToken();
//         assertEquals(expectedToken, actualToken);
//     }

//     @Test
//     void testSetToken() {
//         String newToken = "newTokenValue";
//         String returnedToken = tokenRepository.setToken(newToken);
//         assertEquals(newToken, returnedToken);
//         assertEquals(newToken, tokenRepository.getToken());
//     }
// }
