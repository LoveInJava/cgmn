package com.smartplay.apiservices.tools.validators;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.annotation.Annotation;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.smartplay.apiservices.models.validators.IndianPhoneNumber;

import jakarta.validation.ConstraintValidatorContext;
import jakarta.validation.Payload;

class IndianPhoneNumberValidatorTest {

    private IndianPhoneNumberValidator validator;
    @Mock
    private ConstraintValidatorContext context;

    @BeforeEach
    void setUp() {

        MockitoAnnotations.openMocks(this);
        validator = new IndianPhoneNumberValidator();

        // Assuming IndianPhoneNumber is your custom annotation
        IndianPhoneNumber annotation = new IndianPhoneNumber() {
            @Override
            public Class<? extends Annotation> annotationType() {
                return IndianPhoneNumber.class;
            }

            @Override
            public String message() {
                throw new UnsupportedOperationException("Unimplemented method 'message'");
            }

            @Override
            public Class<?>[] groups() {
                throw new UnsupportedOperationException("Unimplemented method 'groups'");
            }

            @Override
            public Class<? extends Payload>[] payload() {
                throw new UnsupportedOperationException("Unimplemented method 'payload'");
            }

            @Override
            public String regex() {
                return IndianPhoneNumber.PHONE_NUMBER_REGEX;
            }
        };

        validator.initialize(annotation);
    }

    @Test
    void testValidPhoneNumber() {
        // Arrange
        String phoneNumber = "9876543210";

        // Act
        boolean isValid = validator.isValid(phoneNumber, context);

        // Assert
        assertTrue(isValid);
    }

    @Test
    void testInvalidPhoneNumber() {
        // Arrange
        String phoneNumber = "123456789"; // Invalid phone number (less than 10 digits)

        // Act
        boolean isValid = validator.isValid(phoneNumber, context);

        // Assert
        assertFalse(isValid);
    }

    @Test
    void testNullPhoneNumber() {
        // Arrange
        String phoneNumber = null;

        // Act
        boolean isValid = validator.isValid(phoneNumber, context);

        // Assert
        assertTrue(isValid);
    }
}
