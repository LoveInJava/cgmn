// package com.smartplay.apiservices.services.impl;

// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.ArgumentMatchers.*;
// import static org.mockito.Mockito.*;

// import java.util.Arrays;
// import java.util.UUID;

// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.extension.ExtendWith;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.junit.jupiter.MockitoExtension;

// import com.smartplay.apiservices.models.data.SmartPlayGamePoint;
// import com.smartplay.apiservices.models.events.ResetTimerEvent;
// import com.smartplay.apiservices.models.request.GamePointCategory;
// import com.smartplay.apiservices.models.request.GamePointRequest;
// import com.smartplay.apiservices.repository.interfaces.IInMemoryRepository;
// import com.smartplay.apiservices.services.interfaces.ICurrentEventService;

// @ExtendWith(MockitoExtension.class)
// class GamePointServiceTest {

//     @Mock
//     private IInMemoryRepository<SmartPlayGamePoint, String> gamepointRepository;

//     @Mock
//     private ICurrentEventService currentEventService;

//     @InjectMocks
//     private GamePointService gamePointService;

//     @Test
//     void testGetCollectiveGamePointsByLpaId() {
//         // Arrange
//         String lpaId = "testLpaId";
//         UUID currentEventId = UUID.randomUUID();
//         SmartPlayGamePoint gamePoint1 = new SmartPlayGamePoint();
//         gamePoint1.setLpaId(lpaId);
//         gamePoint1.setEventUuid(currentEventId);
//         gamePoint1.setPoints(10);

//         SmartPlayGamePoint gamePoint2 = new SmartPlayGamePoint();
//         gamePoint2.setLpaId(lpaId);
//         gamePoint2.setEventUuid(currentEventId);
//         gamePoint2.setPoints(20);

//         UUID newEventId = UUID.randomUUID();

//         ResetTimerEvent resetTimerEvent = ResetTimerEvent.builder().eventUuid(newEventId).source(this).build();
//         when(currentEventService.getCurrentEvent()).thenReturn(resetTimerEvent);
//         // when(gamepointRepository.getAll()).thenReturn(Arrays.asList(gamePoint1, gamePoint2));
//         when(gamepointRepository.getAllWithLogging()).thenReturn(Arrays.asList(gamePoint1, gamePoint2));

//         // Act
//         Integer result = gamePointService.getCollectiveGamePointsByLpaId(lpaId);

//         // Assert
//         assertEquals(0, result);
//     }

//     @Test
//     void testUpdateGamePoint() {
//         // Arrange
//         GamePointRequest gamePointRequest = new GamePointRequest();
//         gamePointRequest.setRequestId("testRequestId");
//         gamePointRequest.setCategory(GamePointCategory.CATEGORY1);
//         gamePointRequest.setGameId("testGameId");
//         gamePointRequest.setLpaId("testLpaId");

//         UUID currentEventId = UUID.randomUUID();
//         ResetTimerEvent event = ResetTimerEvent.builder().eventUuid(currentEventId).source(this).build();
//         when(currentEventService.getCurrentEvent()).thenReturn(event);

//         SmartPlayGamePoint existingGamePoint = new SmartPlayGamePoint();
//         existingGamePoint.setRequestId(gamePointRequest.getRequestId());
//         when(gamepointRepository.get(gamePointRequest.getRequestId())).thenReturn(existingGamePoint);

//         // Act & Assert
//         gamePointService.updateGamePoint(gamePointRequest);
//         verify(gamepointRepository, never()).add(any(SmartPlayGamePoint.class));
//     }

//     @Test
//     void testUpdateGamePoint2() {
//         // Arrange
//         GamePointRequest gamePointRequest = new GamePointRequest();
//         gamePointRequest.setRequestId("testRequestId");
//         gamePointRequest.setCategory(GamePointCategory.CATEGORY1);
//         gamePointRequest.setGameId("testGameId");
//         gamePointRequest.setLpaId("testLpaId");

//         UUID currentEventId = UUID.randomUUID();
//         ResetTimerEvent event = ResetTimerEvent.builder().eventUuid(currentEventId).source(this).build();
//         when(currentEventService.getCurrentEvent()).thenReturn(event);

//         SmartPlayGamePoint existingGamePoint = new SmartPlayGamePoint();
//         existingGamePoint.setRequestId(gamePointRequest.getRequestId());
//         when(gamepointRepository.get(gamePointRequest.getRequestId())).thenReturn(null);

//         // Act & Assert
//         gamePointService.updateGamePoint(gamePointRequest);

//         verify(gamepointRepository, times(1)).add(any(SmartPlayGamePoint.class));
//     }
// }
