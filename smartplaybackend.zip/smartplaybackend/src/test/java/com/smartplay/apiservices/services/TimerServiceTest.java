package com.smartplay.apiservices.services;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import com.smartplay.apiservices.models.data.UserTimer;
import com.smartplay.apiservices.services.impl.TimerService;

public class TimerServiceTest {

    @ParameterizedTest
    @MethodSource("getTestData")
    void testA(UserTimer timer, LocalDateTime currentTime, UserTimer expectedTimer){

        UserTimer nextUserTimer = TimerService.getNextUserTimer(timer, currentTime);

        assertEquals(expectedTimer.getStartTime(), nextUserTimer.getStartTime());
        assertEquals(expectedTimer.getEndTime(), nextUserTimer.getEndTime());

    }

    private static Stream<Arguments> getTestData() {

        LocalDateTime startTime_5m = LocalDateTime.of(2024, 9, 7, 16, 52,14);
        LocalDateTime endTime_5m = LocalDateTime.of(2024, 9, 7, 16, 57,14);
        long durationInSeconds_5m = ChronoUnit.SECONDS.between(startTime_5m, endTime_5m);

        UserTimer timer_5m = UserTimer.builder().startTime(startTime_5m).endTime(endTime_5m).duration(durationInSeconds_5m) .build();

        LocalDateTime currentTime1 = LocalDateTime.of(2024, 9, 7, 19, 45,50);
        LocalDateTime nextStartTime1 = LocalDateTime.of(2024, 9, 7, 19, 42,14);
        LocalDateTime nextEndTime1 = LocalDateTime.of(2024, 9, 7, 19, 47,14);
        UserTimer expectedTimer1 = UserTimer.builder().startTime(nextStartTime1).endTime(nextEndTime1).duration(durationInSeconds_5m) .build();


        LocalDateTime currentTime2 = LocalDateTime.of(2024, 9, 7, 19, 50,50);
        LocalDateTime nextStartTime2 = LocalDateTime.of(2024, 9, 7, 19, 47,14);
        LocalDateTime nextEndTime2 = LocalDateTime.of(2024, 9, 7, 19, 52,14);
        UserTimer expectedTimer2 = UserTimer.builder().startTime(nextStartTime2).endTime(nextEndTime2).duration(durationInSeconds_5m) .build();

        LocalDateTime startTime_4h = LocalDateTime.of(2024, 9, 7, 13, 52,14);
        LocalDateTime endTime_4h = LocalDateTime.of(2024, 9, 7, 17, 52,14);
        long durationInSeconds_4h = ChronoUnit.SECONDS.between(startTime_4h, endTime_4h);

        UserTimer timer_4h = UserTimer.builder().startTime(startTime_4h).endTime(endTime_4h).duration(durationInSeconds_4h) .build();

        LocalDateTime currentTime3 = LocalDateTime.of(2024, 9, 7, 20, 45,50);
        LocalDateTime nextStartTime3 = LocalDateTime.of(2024, 9, 7, 17, 52,14);
        LocalDateTime nextEndTime3 = LocalDateTime.of(2024, 9, 7, 21, 52,14);
        UserTimer expectedTimer3 = UserTimer.builder().startTime(nextStartTime3).endTime(nextEndTime3).duration(durationInSeconds_4h) .build();


        LocalDateTime currentTime4 = LocalDateTime.of(2024, 9, 7, 22, 30,50);
        LocalDateTime nextStartTime4 = LocalDateTime.of(2024, 9, 7, 21, 52,14);
        LocalDateTime nextEndTime4 = LocalDateTime.of(2024, 9, 8, 1, 52,14);
        UserTimer expectedTimer4 = UserTimer.builder().startTime(nextStartTime4).endTime(nextEndTime4).duration(durationInSeconds_4h) .build();
        

        return Stream.of(
                Arguments.of(timer_5m, currentTime1, expectedTimer1),
                Arguments.of(timer_5m, currentTime2, expectedTimer2),
                Arguments.of(timer_4h, currentTime3, expectedTimer3),
                Arguments.of(timer_4h, currentTime4, expectedTimer4));
    }
}
