package com.smartplay.apiservices.controller;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.smartplay.apiservices.services.interfaces.IMapper;
import com.smartplay.apiservices.services.interfaces.IPinelabsProductsSyncService;
import com.smartplay.apiservices.services.interfaces.IVoucherService;

class PaymentControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @Mock
    private IVoucherService voucherService;
    @Mock
    private IMapper mapperService;
    @Mock
    private IPinelabsProductsSyncService pineLabsProductsSyncService;

    @InjectMocks
    private PaymentController controller;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
    }

    @Test
    void testPayment_success() throws Exception {
        mockMvc.perform(get("/api/v1/payment/voucher/encryptedDeviceId/lpaId/")
                .header("device-id", "encryptedDeviceId"))
                .andExpect(status().isOk());
    }

    @Test
    @Disabled("This test is failing because the the header handling is moved to aspect")
    void testPayment_headerPayloadMismatch() throws Exception {
        mockMvc.perform(get("/api/v1/payment/voucher/deviceId/lpaId/")
                .header("device-id", "wrongEncryptedDeviceId"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void testPayment_missingHeader() throws Exception {
        mockMvc.perform(get("/api/v1/payment/voucher/deviceId/lpaId/"))
        .andExpect(status().isBadRequest());
    }

    @Test
    void testGetPayment_success() throws Exception {

        String paymentRequestJson = "{\"productsku\": 100, \"denomination\": \"20\"}";
        mockMvc.perform(get("/api/v1/payment/voucher/deviceId/lpaId/")
            .header("device-id", "encryptedDeviceId")
            .contentType(MediaType.APPLICATION_JSON)
            .content(paymentRequestJson))
            .andExpect(status().isOk())
            ;
    }

    @Test
    @Disabled("This test is failing because the the header handling is moved to aspect")
    void testCreatePayment_Success() throws Exception {

        doNothing().when(voucherService).orderVoucher(any(), any(), any());

        String paymentRequestJson = "{\"productsku\": 100, \"denomination\": \"500\"}";
        mockMvc.perform(post("/api/v1/payment/voucher/deviceId/lpaId/")
            .header("device-id", "encryptedDeviceId")
            .contentType(MediaType.APPLICATION_JSON)
            .content(paymentRequestJson))
            .andExpect(status().isOk());

    }

    @Test
    @Disabled("This test is failing because the the header handling is moved to aspect")
    void testCreatePayment_missingHeader() throws Exception {
        // Assuming the header is missing
        String paymentRequestJson = "{\"productsku\": 100, \"denomination\": \"20\"}";

        mockMvc.perform(post("/api/v1/payment/voucher/deviceId/lpaId/")
                .contentType(MediaType.APPLICATION_JSON)
                .content(paymentRequestJson))
                .andExpect(status().isBadRequest());
    }

    @Test
    @Disabled("This test is failing because the the header handling is moved to aspect")
    void testCreatePayment_invalidDenomiationHeader() throws Exception {
        // Assuming the header is missing
        String paymentRequestJson = "{\"productsku\": 100, \"denomination\": \"10000\"}";

        mockMvc.perform(post("/api/v1/payment/voucher/deviceId/lpaId/")
                .contentType(MediaType.APPLICATION_JSON)
                .content(paymentRequestJson))
                .andExpect(status().isBadRequest());
    }

}
