// package com.smartplay.apiservices.services.impl;

// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;

// import java.lang.reflect.Field;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.extension.ExtendWith;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.junit.jupiter.MockitoExtension;

// import com.smartplay.apiservices.services.integration.service.TwoFactorSmsProvider;

// @ExtendWith(MockitoExtension.class)
// class TwoFactorSmsServiceTest {

//     @Mock
//     private TwoFactorSmsProvider twoFactorSmsProvider;
//     @InjectMocks
//     private TwoFactorSmsService twoFactorSmsService;

//     @BeforeEach
//     void setUp()throws NoSuchFieldException, IllegalAccessException {
//         Field otpTemplateField = TwoFactorSmsService.class.getDeclaredField("otpTemplate");
//         otpTemplateField.setAccessible(true);
//         otpTemplateField.set(twoFactorSmsService, "Your OTP is: %s");
//     }

//     @Test
//     void testSendVerificationCode() {
//         // Arrange
//         String phoneNumber = "1234567890";
//         String verificationCode = "123456";
//         String otpTemplate = "Your OTP is: %s";

//         // Act
//         twoFactorSmsService.sendVerificationCode(phoneNumber, verificationCode);

//         // Assert
//         verify(twoFactorSmsProvider, times(1)).sendOtp(phoneNumber, verificationCode, otpTemplate);
//     }

//     @Test
//     void testSendSms() {
//         // Arrange
//         String phoneNumber = "1234567890";
//         String message = "Hello, World!";

//         // Act & Assert
//         // Since the sendSms method throws an UnsupportedOperationException,
//         // we don't need to write any test code for it.
//         assertThrows(UnsupportedOperationException.class, () -> twoFactorSmsService.sendSms(phoneNumber, message));
//     }
// }
