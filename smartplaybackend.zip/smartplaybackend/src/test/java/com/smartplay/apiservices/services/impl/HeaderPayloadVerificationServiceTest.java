package com.smartplay.apiservices.services.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.smartplay.apiservices.services.interfaces.IEncryptionDecryptionService;

@ExtendWith(MockitoExtension.class)
class HeaderPayloadVerificationServiceTest {

    @Mock
    private IEncryptionDecryptionService certificateBasedEncryptionDecryptionService;

    @Mock
    private IEncryptionDecryptionService base64EncryptionDecryptionService;

    @InjectMocks
    private HeaderPayloadVerificationService headerPayloadVerificationService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        headerPayloadVerificationService = new HeaderPayloadVerificationService(
                base64EncryptionDecryptionService, certificateBasedEncryptionDecryptionService);
    }

    @Test
    void testVerifyHeaderToParamPayload() {
        // Arrange
        String headerDeviceId = "encryptedHeaderDeviceId";
        String paramDeviceId = "encryptedParamDeviceId";
        String decryptedHeaderDeviceId = "device001";
        String decryptedParamDeviceId = "device001";

        when(certificateBasedEncryptionDecryptionService.decrypt(headerDeviceId))
                .thenReturn(decryptedHeaderDeviceId);
        when(base64EncryptionDecryptionService.decrypt(paramDeviceId))
                .thenReturn(decryptedParamDeviceId);

        // Act
        boolean result = headerPayloadVerificationService.verifyHeaderToParamPayload(headerDeviceId, paramDeviceId);

        // Assert
        assertTrue(result);
        verify(certificateBasedEncryptionDecryptionService, times(1)).decrypt(headerDeviceId);
        verify(base64EncryptionDecryptionService, times(1)).decrypt(paramDeviceId);
    }
}
