package com.smartplay.apiservices.models.data;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class VoucherProductTest {

    private VoucherProduct voucherProduct;

    @BeforeEach
    void setUp() {
        voucherProduct = new VoucherProduct();
    }

    @Test
    void testGetAndSetId() {
        String id = "12345";
        voucherProduct.setId(id);
        assertEquals(id, voucherProduct.getId());
    }

    @Test
    void testGetAndSetProviderName() {
        String providerName = "Provider Name";
        voucherProduct.setProviderName(providerName);
        assertEquals(providerName, voucherProduct.getProviderName());
    }

    @Test
    void testGetAndSetProviderSku() {
        String providerSku = "SKU123";
        voucherProduct.setProviderSku(providerSku);
        assertEquals(providerSku, voucherProduct.getProviderSku());
    }

    @Test
    void testGetAndSetName() {
        String name = "Voucher Name";
        voucherProduct.setName(name);
        assertEquals(name, voucherProduct.getName());
    }

    @Test
    void testGetAndSetDescription() {
        String description = "Voucher Description";
        voucherProduct.setDescription(description);
        assertEquals(description, voucherProduct.getDescription());
    }

    @Test
    void testGetAndSetImage() {
        String image = "image.png";
        voucherProduct.setImage(image);
        assertEquals(image, voucherProduct.getImage());
    }

    @Test
    void testGetAndSetCurrencyID() {
        String currencyID = "USD";
        voucherProduct.setCurrencyID(currencyID);
        assertEquals(currencyID, voucherProduct.getCurrencyID());
    }

    @Test
    void testGetAndSetTags() {
        List<String> tags = new ArrayList<>();
        tags.add("tag1");
        tags.add("tag2");
        voucherProduct.setTags(tags);
        assertEquals(tags, voucherProduct.getTags());
    }

    @Test
    void testGetAndSetDenominations() {
        List<Integer> denominations = new ArrayList<>();
        denominations.add(10);
        denominations.add(20);
        voucherProduct.setDenominations(denominations);
        assertEquals(denominations, voucherProduct.getDenominations());
    }

    @Test
    void testAllArgsConstructor() {
        String id = "12345";
        String providerName = "Provider Name";
        String providerSku = "SKU123";
        String name = "Voucher Name";
        String description = "Voucher Description";
        String image = "image.png";
        String currencyID = "USD";
        List<String> tags = new ArrayList<>();
        tags.add("tag1");
        tags.add("tag2");
        List<Integer> denominations = new ArrayList<>();
        denominations.add(10);
        denominations.add(20);

        VoucherProduct product = new VoucherProduct(id, providerName, providerSku, name, description, image, currencyID, "sample tnc","tnc url", tags, denominations);

        assertEquals(id, product.getId());
        assertEquals(providerName, product.getProviderName());
        assertEquals(providerSku, product.getProviderSku());
        assertEquals(name, product.getName());
        assertEquals(description, product.getDescription());
        assertEquals(image, product.getImage());
        assertEquals(currencyID, product.getCurrencyID());
        assertEquals(tags, product.getTags());
        assertEquals(denominations, product.getDenominations());
    }

    @Test
    void testNoArgsConstructor() {
        VoucherProduct product = new VoucherProduct();

        assertNull(product.getId());
        assertNull(product.getProviderName());
        assertNull(product.getProviderSku());
        assertNull(product.getName());
        assertNull(product.getDescription());
        assertNull(product.getImage());
        assertNull(product.getCurrencyID());
        assertNotNull(product.getTags());
        assertNotNull(product.getDenominations());
    }

    @Test
    void testBuilder() {
        String id = "12345";
        String providerName = "Provider Name";
        String providerSku = "SKU123";
        String name = "Voucher Name";
        String description = "Voucher Description";
        String image = "image.png";
        String currencyID = "USD";
        List<String> tags = new ArrayList<>();
        tags.add("tag1");
        tags.add("tag2");
        List<Integer> denominations = new ArrayList<>();
        denominations.add(10);
        denominations.add(20);

        VoucherProduct product = VoucherProduct.builder()
                .id(id)
                .providerName(providerName)
                .providerSku(providerSku)
                .name(name)
                .description(description)
                .image(image)
                .currencyID(currencyID)
                .tags(tags)
                .denominations(denominations)
                .build();

        assertEquals(id, product.getId());
        assertEquals(providerName, product.getProviderName());
        assertEquals(providerSku, product.getProviderSku());
        assertEquals(name, product.getName());
        assertEquals(description, product.getDescription());
        assertEquals(image, product.getImage());
        assertEquals(currencyID, product.getCurrencyID());
        assertEquals(tags, product.getTags());
        assertEquals(denominations, product.getDenominations());
    }
}
