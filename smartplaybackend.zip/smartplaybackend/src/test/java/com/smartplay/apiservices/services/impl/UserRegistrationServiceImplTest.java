package com.smartplay.apiservices.services.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.smartplay.apiservices.models.data.LpaUser;
import com.smartplay.apiservices.repository.impl.LpaUserServiceDao;
import com.smartplay.apiservices.repository.impl.OtpService;

@ExtendWith(MockitoExtension.class)
class UserRegistrationServiceImplTest {

    @Mock
    private LpaUserServiceDao userRepository;

    @Mock
    private OtpService otpRepository;

    @InjectMocks
    private UserRegistrationServiceImpl userRegistrationService;
    
    @Test
    void testIsPhoneNumberValid_ValidPhoneNumber_ReturnsTrue() {
        // Arrange
        String phoneNumber = "9818236314";

        // Act
        boolean result = userRegistrationService.isPhoneNumberValid(phoneNumber);

        // Assert
        assertTrue(result);
    }

    @Test
    void testIsPhoneNumberValid_InvalidPhoneNumber_ReturnsFalse() {
        // Arrange
        String phoneNumber = "123";

        // Act
        boolean result = userRegistrationService.isPhoneNumberValid(phoneNumber);

        // Assert
        assertFalse(result);
    }

    @Test
    void testIsPhoneNumberRegistered_RegisteredPhoneNumber_ReturnsTrue() {
        // Arrange
        String phoneNumber = "1234567890";
        when(userRepository.findByPhoneNumber(phoneNumber)).thenReturn(new LpaUser());

        // Act
        boolean result = userRegistrationService.isPhoneNumberRegistered(phoneNumber);

        // Assert
        assertTrue(result);
    }

    @Test
    void testIsPhoneNumberRegistered_UnregisteredPhoneNumber_ReturnsFalse() {
        // Arrange
        String phoneNumber = "1234567890";
        when(userRepository.findByPhoneNumber(phoneNumber)).thenReturn(null);

        // Act
        boolean result = userRegistrationService.isPhoneNumberRegistered(phoneNumber);

        // Assert
        assertFalse(result);
    }

    @Test
    void testIsPhoneNumberVerified_PhoneNumberVerified_ReturnsTrue() {
        // Arrange
        String phoneNumber = "1234567890";
        LpaUser user = new LpaUser();
        user.setPhoneNumberVerified(true);
        when(userRepository.findByPhoneNumber(phoneNumber)).thenReturn(user);

        // Act
        boolean result = userRegistrationService.isPhoneNumberVerified(phoneNumber);

        // Assert
        assertTrue(result);
    }

    @Test
    void testIsPhoneNumberVerified_PhoneNumberNotVerified_ReturnsFalse() {
        // Arrange
        String phoneNumber = "1234567890";
        LpaUser user = new LpaUser();
        user.setPhoneNumberVerified(false);
        when(userRepository.findByPhoneNumber(phoneNumber)).thenReturn(user);

        // Act
        boolean result = userRegistrationService.isPhoneNumberVerified(phoneNumber);

        // Assert
        assertFalse(result);
    }
    @Test
    void testIsPhoneNumberVerified_PhoneNumberNotVerified_whenuserNotFound_ReturnsFalse() {
        // Arrange
        String phoneNumber = "1234567890";
        when(userRepository.findByPhoneNumber(phoneNumber)).thenReturn(null);

        // Act
        boolean result = userRegistrationService.isPhoneNumberVerified(phoneNumber);

        // Assert
        assertFalse(result);
    }

    @Test
    void testGenerateVerificationCode_ReturnsSixDigitCode() {
        // Act
        String verificationCode = userRegistrationService.generateVerificationCode();

        // Assert
        assertNotNull(verificationCode);
        assertEquals(6, verificationCode.length());
        assertTrue(verificationCode.matches("\\d{6}"));
    }

    // @Test
    // void testSaveRegistrationRequest_ValidUser_CallsUserRepositorySave() {
    //     // Arrange
    //     LpaUser user = new LpaUser();
    //     user.setPhoneNumber("9818236314");
    //     user.setLpaId(UUID.randomUUID().toString());

    //     // Act
    //     userRegistrationService.saveRegistrationRequest(user);

    //     // Assert
    //     verify(userRepository, times(1)).save(user);
    // }

    @Test
    void testSaveRegistrationRequest_NullUser_ThrowsIllegalArgumentException() {
        // Arrange
        LpaUser user = null;

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            userRegistrationService.saveRegistrationRequest(user);
        });
    }

    @Test
    void testSaveRegistrationRequest_UserWithoutId_ThrowsIllegalArgumentException() {
        // Arrange
        LpaUser user = new LpaUser();
        user.setPhoneNumber("1234567890");

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            userRegistrationService.saveRegistrationRequest(user);
        });
    }

    @Test
    void testValidateOtp_ValidOtp_ReturnsTrue() {
        // Arrange
        String phoneNumber = "1234567890";
        String verificationCode = "123456";
        when(otpRepository.validateOtp(phoneNumber, verificationCode)).thenReturn(true);

        // Act
        boolean result = userRegistrationService.validateOtp(phoneNumber, verificationCode);

        // Assert
        assertTrue(result);
    }

    @Test
    void testValidateOtp_InvalidOtp_ReturnsFalse() {
        // Arrange
        String phoneNumber = "1234567890";
        String verificationCode = "123456";
        when(otpRepository.validateOtp(phoneNumber, verificationCode)).thenReturn(false);

        // Act
        boolean result = userRegistrationService.validateOtp(phoneNumber, verificationCode);

        // Assert
        assertFalse(result);
    }

    @Test
    void testUpdateOtpVerificationStatus_ValidPhoneNumberAndStatus_CallsUserRepositorySave() {
        // Arrange
        String phoneNumber = "1234567890";
        String deviceID = "1234567890";
        boolean otpVerificationStatus = true;
        LpaUser user = new LpaUser();
        when(userRepository.findByPhoneNumber(phoneNumber)).thenReturn(user);

        // Act
        userRegistrationService.updateOtpVerificationStatus(phoneNumber, deviceID, otpVerificationStatus);

        // Assert
        verify(userRepository, times(1)).save(user);
        assertTrue(user.isPhoneNumberVerified());
    }

    @Test
    void testIsDeviceRegistered_DeviceRegistered_ReturnsTrue() {
        // Arrange
        String deviceId = "1234567890";
        when(userRepository.isDeviceRegistered(deviceId)).thenReturn(true);

        // Act
        boolean result = userRegistrationService.isDeviceRegistered(deviceId);

        // Assert
        assertTrue(result);
    }

    @Test
    void testIsDeviceRegistered_DeviceNotRegistered_ReturnsFalse() {
        // Arrange
        String deviceId = "1234567890";
        when(userRepository.isDeviceRegistered(deviceId)).thenReturn(false);

        // Act
        boolean result = userRegistrationService.isDeviceRegistered(deviceId);

        // Assert
        assertFalse(result);
    }

    @Test
    void testGetLpaId_PhoneNumberExists_ReturnsLpaId() {
        // Arrange
        String phoneNumber = "1234567890";
        LpaUser user = new LpaUser();
        UUID lpaId = UUID.randomUUID();
        user.setLpaId(lpaId.toString());
        when(userRepository.findByPhoneNumber(phoneNumber)).thenReturn(user);

        // Act
        String result = userRegistrationService.getLpaId(phoneNumber);

        // Assert
        assertEquals(lpaId.toString(), result);
    }

    @Test
    void testGetLpaId_PhoneNumberDoesNotExist_ReturnsNull() {
        // Arrange
        String phoneNumber = "1234567890";
        when(userRepository.findByPhoneNumber(phoneNumber)).thenReturn(null);

        // Act
        String result = userRegistrationService.getLpaId(phoneNumber);

        // Assert
        assertNull(result);
    }

    @Test
    void testGetUsername_PhoneNumberExists_ReturnsUsername() {
        // Arrange
        String phoneNumber = "1234567890";
        LpaUser user = new LpaUser();
        String username = "testUser";
        user.setUsername(username);
        when(userRepository.findByPhoneNumber(phoneNumber)).thenReturn(user);

        // Act
        String result = userRegistrationService.getUsername(phoneNumber);

        // Assert
        assertEquals(username, result);
    }

    @Test
    void testGetUsername_PhoneNumberDoesNotExist_ReturnsNull() {
        // Arrange
        String phoneNumber = "1234567890";
        when(userRepository.findByPhoneNumber(phoneNumber)).thenReturn(null);

        // Act
        String result = userRegistrationService.getUsername(phoneNumber);

        // Assert
        assertNull(result);
    }

    @Test
    void testGetByLpaId_LpaIdExists_ReturnsLpaUser() {
        // Arrange
        UUID lpaId = UUID.randomUUID();
        LpaUser user = new LpaUser();
        when(userRepository.findById(lpaId.toString())).thenReturn(user);

        // Act
        LpaUser result = userRegistrationService.getByLpaId(lpaId.toString());

        // Assert
        assertEquals(user, result);
    }

    @Test
    void testGetByLpaId_LpaIdDoesNotExist_ReturnsNull() {
        // Arrange
        UUID lpaId = UUID.randomUUID();
        when(userRepository.findById(lpaId.toString())).thenReturn(null);

        // Act
        LpaUser result = userRegistrationService.getByLpaId(lpaId.toString());

        // Assert
        assertNull(result);
    }

    @Test
    void testGetByLpaIdDeviceId_ValidLpaIdAndDeviceId_ReturnsLpaUser() {
        // Arrange
        String lpaId = UUID.randomUUID().toString();
        String deviceId = "device123";
        LpaUser user = new LpaUser();
        user.setLpaId(lpaId);
        user.addDeviceId(deviceId);
        when(userRepository.filter(any())).thenReturn(List.of(user));

        // Act
        LpaUser result = userRegistrationService.getByLpaIdDeviceId(lpaId, deviceId);

        // Assert
        assertEquals(user, result);
    }

    @Test
    void testGetByLpaIdDeviceId_InvalidDeviceId_ReturnsNull() {
        // Arrange
        String lpaId = UUID.randomUUID().toString();
        String deviceId = "device123";
        when(userRepository.filter(any())).thenReturn(List.of());

        // Act
        LpaUser result = userRegistrationService.getByLpaIdDeviceId(lpaId, deviceId);

        // Assert
        assertNull(result);
    }

    @Test
    void testGetByPhoneNumberDeviceId_ValidPhoneNumberAndDeviceId_ReturnsLpaUser() {
        // Arrange
        String phoneNumber = "1234567890";
        String deviceId = "device123";
        LpaUser user = new LpaUser();
        user.setPhoneNumber(phoneNumber);
        user.addDeviceId(deviceId);
        when(userRepository.filter(any())).thenReturn(List.of(user));

        // Act
        LpaUser result = userRegistrationService.getByPhoneNumberDeviceId(phoneNumber, deviceId);

        // Assert
        assertEquals(user, result);
    }

    @Test
    void testGetByPhoneNumberDeviceId_InvalidDeviceId_ReturnsNull() {
        // Arrange
        String phoneNumber = "1234567890";
        String deviceId = "device123";
        when(userRepository.filter(any())).thenReturn(List.of());

        // Act
        LpaUser result = userRegistrationService.getByPhoneNumberDeviceId(phoneNumber, deviceId);

        // Assert
        assertNull(result);
    }

    @Test
    void testGetByDeviceId_ValidDeviceId_ReturnsLpaUser() {
        // Arrange
        String deviceId = "device123";
        LpaUser user = new LpaUser();
        user.addDeviceId(deviceId);
        when(userRepository.filter(any())).thenReturn(List.of(user));

        // Act
        LpaUser result = userRegistrationService.getByDeviceId(deviceId);

        // Assert
        assertEquals(user, result);
    }

    @Test
    void testGetByDeviceId_InvalidDeviceId_ReturnsNull() {
        // Arrange
        String deviceId = "device123";
        when(userRepository.filter(any())).thenReturn(List.of());

        // Act
        LpaUser result = userRegistrationService.getByDeviceId(deviceId);

        // Assert
        assertNull(result);
    }

    @Test
    void testGetByPhoneNumber_ValidPhoneNumber_ReturnsLpaUser() {
        // Arrange
        String phoneNumber = "1234567890";
        LpaUser user = new LpaUser();
        user.setPhoneNumber(phoneNumber);
        when(userRepository.filter(any())).thenReturn(List.of(user));

        // Act
        LpaUser result = userRegistrationService.getByPhoneNumber(phoneNumber);

        // Assert
        assertEquals(user, result);
    }

    @Test
    void testGetByPhoneNumber_InvalidPhoneNumber_ReturnsNull() {
        // Arrange
        String phoneNumber = "1234567890";
        when(userRepository.filter(any())).thenReturn(List.of());

        // Act
        LpaUser result = userRegistrationService.getByPhoneNumber(phoneNumber);

        // Assert
        assertNull(result);
    }

    @Test
    void testGetOtpByDeviceId_ValidDeviceId_ReturnsOtp() {
        // Arrange
        String deviceId = "device123";
        String phoneNumber = "1234567890";
        String otp = "123456";
        LpaUser user = new LpaUser();
        user.setPhoneNumber(phoneNumber);
        user.addDeviceId(deviceId);
        when(userRepository.filter(any())).thenReturn(List.of(user));
        when(otpRepository.getOtp(phoneNumber)).thenReturn(otp);

        // Act
        String result = userRegistrationService.getOtpByDeviceId(deviceId);

        // Assert
        assertEquals(otp, result);
    }

    @Test
    void testGetOtpByDeviceId_InvalidDeviceId_ReturnsNull() {
        // Arrange
        String deviceId = "device123";
        when(userRepository.filter(any())).thenReturn(List.of());

        // Act
        String result = userRegistrationService.getOtpByDeviceId(deviceId);

        // Assert
        assertNull(result);
    }
}
