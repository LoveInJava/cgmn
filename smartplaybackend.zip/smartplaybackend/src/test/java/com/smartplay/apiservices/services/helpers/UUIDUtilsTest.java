package com.smartplay.apiservices.services.helpers;

import static org.junit.jupiter.api.Assertions.*;

import java.util.UUID;

import org.junit.jupiter.api.Test;

class UUIDUtilsTest {

    @Test
    void testToLpaIdString() {
        // Arrange
        UUID uuid = UUID.fromString("c4a760a8-dbcf-5254-a0d9-6a4474bd1b62");

        // Act
        String result = UUIDUtils.toLpaIdString(uuid);

        // Assert
        assertEquals("C4A760A8DBCF5254A0D96A4474BD1B62", result);
    }
}
