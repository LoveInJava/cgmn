package com.smartplay.apiservices.models.response;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PurchasedVoucherResponseTest {

    private PurchasedVoucherResponse purchasedVoucherResponse;

    @BeforeEach
    void setUp() {
        purchasedVoucherResponse = new PurchasedVoucherResponse();
    }

    @Test
    void testGetAndSetId() {
        String id = "12345";
        purchasedVoucherResponse.setId(id);
        assertEquals(id, purchasedVoucherResponse.getId());
    }

    @Test
    void testGetAndSetLpaId() {
        String lpaId = "lpa123";
        purchasedVoucherResponse.setLpaId(lpaId);
        assertEquals(lpaId, purchasedVoucherResponse.getLpaId());
    }

    @Test
    void testGetAndSetVoucherName() {
        String voucherName = "Voucher Name";
        purchasedVoucherResponse.setVoucherName(voucherName);
        assertEquals(voucherName, purchasedVoucherResponse.getVoucherName());
    }

    @Test
    void testGetAndSetPurchasedOn() {
        String purchasedOn = "2023-10-01";
        purchasedVoucherResponse.setPurchasedOn(purchasedOn);
        assertEquals(purchasedOn, purchasedVoucherResponse.getPurchasedOn());
    }

    @Test
    void testGetAndSetAmount() {
        int amount = 100;
        purchasedVoucherResponse.setAmount(amount);
        assertEquals(amount, purchasedVoucherResponse.getAmount());
    }

    // @Test
    // void testAllArgsConstructor() {
    //     String id = "12345";
    //     String lpaId = "lpa123";
    //     String voucherName = "Voucher Name";
    //     String purchasedOn = "2023-10-01";
    //     int amount = 100;

    //     PurchasedVoucherResponse response = new PurchasedVoucherResponse(id, lpaId, voucherName, purchasedOn, amount);

    //     assertEquals(id, response.getId());
    //     assertEquals(lpaId, response.getLpaId());
    //     assertEquals(voucherName, response.getVoucherName());
    //     assertEquals(purchasedOn, response.getPurchasedOn());
    //     assertEquals(amount, response.getAmount());
    // }

    @Test
    void testNoArgsConstructor() {
        PurchasedVoucherResponse response = new PurchasedVoucherResponse();

        assertNull(response.getId());
        assertNull(response.getLpaId());
        assertNull(response.getVoucherName());
        assertNull(response.getPurchasedOn());
        assertEquals(0.0, response.getAmount());
    }

    @Test
    void testBuilder() {
        String id = "12345";
        String lpaId = "lpa123";
        String voucherName = "Voucher Name";
        String purchasedOn = "2023-10-01";
        int amount = 100;

        PurchasedVoucherResponse response = PurchasedVoucherResponse.builder()
                .id(id)
                .lpaId(lpaId)
                .voucherName(voucherName)
                .purchasedOn(purchasedOn)
                .amount(amount)
                .build();

        assertEquals(id, response.getId());
        assertEquals(lpaId, response.getLpaId());
        assertEquals(voucherName, response.getVoucherName());
        assertEquals(purchasedOn, response.getPurchasedOn());
        assertEquals(amount, response.getAmount());
    }
}
