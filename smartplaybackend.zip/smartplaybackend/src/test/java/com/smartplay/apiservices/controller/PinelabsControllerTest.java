package com.smartplay.apiservices.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.smartplay.apiservices.models.data.PinelabsProduct;
import com.smartplay.apiservices.services.integration.payments.pinelabs.interfaces.IPinelabsApiService;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.CategoryResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.ProductListResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.ProductResponse;
import com.smartplay.apiservices.services.interfaces.IPinelabsProductsSyncService;

class PinelabsControllerTest {

    @Mock
    private IPinelabsApiService pinelabsService;

    @Mock
    private IPinelabsProductsSyncService pineLabsProductsSyncService;

    @InjectMocks
    private PinelabsController pinelabsController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetProduct() {
        String productSku = "sku123";
        ProductResponse mockResponse = new ProductResponse();
        when(pinelabsService.getProductBySku(productSku)).thenReturn(mockResponse);

        ProductResponse response = pinelabsController.getProduct(productSku);
        assertNotNull(response);
        assertEquals(mockResponse, response);
    }

    @Test
    void testGetProductByCategoryId() {
        String categoryId = "123";
        ProductListResponse mockResponse = new ProductListResponse();
        when(pinelabsService.getProductByCategoryId(categoryId)).thenReturn(mockResponse);

        ProductListResponse response = pinelabsController.getProductByCategoryId(categoryId);
        assertNotNull(response);
        assertEquals(mockResponse, response);
    }

    @Test
    void testGetProductByCategoryIdOverloaded() {
        CategoryResponse mockResponse = new CategoryResponse();
        when(pinelabsService.getCategory()).thenReturn(mockResponse);

        CategoryResponse response = pinelabsController.getProductByCategoryId();
        assertNotNull(response);
        assertEquals(mockResponse, response);
    }

    @Test
    void testGetAllProducts() {
        List<PinelabsProduct> mockResponse = Collections.singletonList(new PinelabsProduct());
        when(pineLabsProductsSyncService.getAll()).thenReturn(mockResponse);

        List<PinelabsProduct> response = pinelabsController.getAllProducts();
        assertNotNull(response);
        assertEquals(mockResponse, response);
    }

    @Test
    void testTriggerProductSync() {
        List<PinelabsProduct> mockResponse = Collections.singletonList(new PinelabsProduct());
        doNothing().when(pineLabsProductsSyncService).initiateSync();
        when(pineLabsProductsSyncService.getAll()).thenReturn(mockResponse);

        List<PinelabsProduct> response = pinelabsController.triggerProductSync();
        assertNotNull(response);
        assertEquals(mockResponse, response);
    }

    @Test
    void testClearData() {
        doNothing().when(pineLabsProductsSyncService).clear();

        pinelabsController.clearData();

        verify(pineLabsProductsSyncService, times(1)).clear();
    }
}
