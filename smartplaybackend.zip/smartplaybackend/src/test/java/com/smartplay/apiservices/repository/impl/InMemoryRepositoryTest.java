package com.smartplay.apiservices.repository.impl;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.smartplay.apiservices.repository.interfaces.IIdentifiable;

class InMemoryRepositoryTest {

    private InMemoryRepository<TestEntity, String> repository;

    @BeforeEach
    void setUp() {
        repository = new InMemoryRepository<>();
    }

    @Test
    void testAdd() {
        // Arrange
        TestEntity entity = new TestEntity("1", "Test Entity");

        // Act
        TestEntity addedEntity = repository.add(entity);

        // Assert
        assertNotNull(addedEntity);
        assertEquals(entity, addedEntity);
    }

    @Test
    void testGet() {
        // Arrange
        TestEntity entity = new TestEntity("1", "Test Entity");
        repository.add(entity);

        // Act
        TestEntity retrievedEntity = repository.get("1");

        // Assert
        assertNotNull(retrievedEntity);
        assertEquals(entity, retrievedEntity);
    }

    @Test
    void testUpdate() {
        // Arrange
        TestEntity entity = new TestEntity("1", "Test Entity");
        repository.add(entity);

        // Act
        entity.setName("Updated Entity");
        TestEntity updatedEntity = repository.update(entity);

        // Assert
        assertNotNull(updatedEntity);
        assertEquals(entity, updatedEntity);
    }

    @Test
    void testDelete() {
        // Arrange
        TestEntity entity = new TestEntity("1", "Test Entity");
        repository.add(entity);

        // Act
        repository.delete("1");
        TestEntity deletedEntity = repository.get("1");

        // Assert
        assertNull(deletedEntity);
    }

    @Test
    void testGetAll() {
        // Arrange
        TestEntity entity1 = new TestEntity("1", "Test Entity 1");
        TestEntity entity2 = new TestEntity("2", "Test Entity 2");
        repository.add(entity1);
        repository.add(entity2);

        // Act
        List<TestEntity> allEntities = repository.getAll();

        // Assert
        assertNotNull(allEntities);
        assertEquals(2, allEntities.size());
        assertTrue(allEntities.contains(entity1));
        assertTrue(allEntities.contains(entity2));
    }

    @Test
    void testSave_AddNewEntity() {
        // Arrange
        TestEntity entity = new TestEntity("1", "Test Entity");

        // Act
        TestEntity savedEntity = repository.save(entity);

        // Assert
        assertNotNull(savedEntity);
        assertEquals(entity, savedEntity);
    }

    @Test
    void testSave_UpdateExistingEntity() {
        // Arrange
        TestEntity entity = new TestEntity("1", "Test Entity");
        repository.add(entity);

        // Act
        entity.setName("Updated Entity");
        TestEntity savedEntity = repository.save(entity);

        // Assert
        assertNotNull(savedEntity);
        assertEquals(entity, savedEntity);
    }

    @Test
    void testReset() {
        // Arrange
        TestEntity entity = new TestEntity("1", "Test Entity");
        repository.add(entity);

        // Act
        repository.reset();
        TestEntity retrievedEntity = repository.get("1");

        // Assert
        assertNull(retrievedEntity);
    }

    @Test
    void testFilter() {
        InMemoryRepository<TestEntity, String> repository1 = new InMemoryRepository<TestEntity, String>();
        repository1.add(new TestEntity("1", "Entity1"));
        repository1.add(new TestEntity("2", "Entity2"));
        repository1.add(new TestEntity("3", "Entity3"));
        Predicate<TestEntity> predicate = entity -> entity.getName().contains("Entity");
        List<TestEntity> filteredEntities = repository1.filter(predicate);

        assertEquals(3, filteredEntities.size());
    }

    @Test
    void testExists() {

        InMemoryRepository<TestEntity, String> repository1 = new InMemoryRepository<TestEntity, String>();
        repository1.add(new TestEntity("1", "Entity1"));
        repository1.add(new TestEntity("2", "Entity2"));
        repository1.add(new TestEntity("3", "Entity3"));

        Predicate<TestEntity> predicate = entity -> entity.getName().equals("Entity2");
        boolean exists = repository1.exists(predicate);

        assertTrue(exists);

        Predicate<TestEntity> nonExistentPredicate = entity -> entity.getName().equals("NonExistentEntity");
        boolean nonExistent = repository1.exists(nonExistentPredicate);

        assertFalse(nonExistent);
    }

    // TestEntity class for testing purposes
    private static class TestEntity implements IIdentifiable<String> {
        private String id;
        private String name;

        public TestEntity(String id, String name) {
            this.id = id;
            this.name = name;
        }

        @Override
        public String getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            TestEntity other = (TestEntity) obj;
            return id.equals(other.id) && name.equals(other.name);
        }

        @Override
        public int hashCode() {
            return Objects.hash(id, name);
        }
    }
}
