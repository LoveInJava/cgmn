package com.smartplay.apiservices.models.enums;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CurrencyTest {

    @Test
    void testToString() {
        // Arrange
        Currency inr = Currency.INR;
        Currency usd = Currency.USD;
        Currency eur = Currency.EUR;
        Currency gbp = Currency.GBP;
        Currency jpy = Currency.JPY;
        Currency aud = Currency.AUD;
        Currency cad = Currency.CAD;
        Currency chf = Currency.CHF;
        Currency cny = Currency.CNY;
        Currency sek = Currency.SEK;
        Currency nzd = Currency.NZD;

        // Act & Assert
        assertEquals("INR", inr.toString());
        assertEquals("USD", usd.toString());
        assertEquals("EUR", eur.toString());
        assertEquals("GBP", gbp.toString());
        assertEquals("JPY", jpy.toString());
        assertEquals("AUD", aud.toString());
        assertEquals("CAD", cad.toString());
        assertEquals("CHF", chf.toString());
        assertEquals("CNY", cny.toString());
        assertEquals("SEK", sek.toString());
        assertEquals("NZD", nzd.toString());
    }

    @Test
    void testGetLabel() {
        // Arrange
        Currency inr = Currency.INR;
        Currency usd = Currency.USD;
        Currency eur = Currency.EUR;
        Currency gbp = Currency.GBP;
        Currency jpy = Currency.JPY;
        Currency aud = Currency.AUD;
        Currency cad = Currency.CAD;
        Currency chf = Currency.CHF;
        Currency cny = Currency.CNY;
        Currency sek = Currency.SEK;
        Currency nzd = Currency.NZD;

        // Act & Assert
        assertEquals("INR", inr.getLabel());
        assertEquals("USD", usd.getLabel());
        assertEquals("EUR", eur.getLabel());
        assertEquals("GBP", gbp.getLabel());
        assertEquals("JPY", jpy.getLabel());
        assertEquals("AUD", aud.getLabel());
        assertEquals("CAD", cad.getLabel());
        assertEquals("CHF", chf.getLabel());
        assertEquals("CNY", cny.getLabel());
        assertEquals("SEK", sek.getLabel());
        assertEquals("NZD", nzd.getLabel());
    }

    @Test
    void testGetSymbol() {
        // Arrange
        Currency inr = Currency.INR;
        Currency usd = Currency.USD;
        Currency eur = Currency.EUR;
        Currency gbp = Currency.GBP;
        Currency jpy = Currency.JPY;
        Currency aud = Currency.AUD;
        Currency cad = Currency.CAD;
        Currency chf = Currency.CHF;
        Currency cny = Currency.CNY;
        Currency sek = Currency.SEK;
        Currency nzd = Currency.NZD;

        // Act & Assert
        assertEquals("₹", inr.getSymbol());
        assertEquals("$", usd.getSymbol());
        assertEquals("€", eur.getSymbol());
        assertEquals("£", gbp.getSymbol());
        assertEquals("¥", jpy.getSymbol());
        assertEquals("$", aud.getSymbol());
        assertEquals("$", cad.getSymbol());
        assertEquals("Fr", chf.getSymbol());
        assertEquals("¥", cny.getSymbol());
        assertEquals("kr", sek.getSymbol());
        assertEquals("$", nzd.getSymbol());
    }
}
