package com.smartplay.apiservices.services.integrations.payments.pinelabs.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.smartplay.apiservices.services.integration.payments.pinelabs.impl.PinelabsService;
import com.smartplay.apiservices.services.integration.payments.pinelabs.interfaces.ProductClient;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.CategoryResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.ProductListResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.ProductResponse;

class PinelabsServiceTest {

    @Mock
    private ProductClient productClient;

    @InjectMocks
    private PinelabsService pinelabsService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetProductByCategoryId() {
        String categoryId = "123";
        ProductListResponse mockResponse = new ProductListResponse();
        when(productClient.getProductByCategoryId(categoryId)).thenReturn(mockResponse);

        ProductListResponse response = pinelabsService.getProductByCategoryId(categoryId);
        assertNotNull(response);
        assertEquals(mockResponse, response);
    }

    @Test
    void testGetProductBySku() {
        String productSku = "sku123";
        ProductResponse mockResponse = new ProductResponse();
        when(productClient.getProductBySku(productSku)).thenReturn(mockResponse);

        ProductResponse response = pinelabsService.getProductBySku(productSku);
        assertNotNull(response);
        assertEquals(mockResponse, response);
    }

    @Test
    void testGetCategory() {
        CategoryResponse mockResponse = new CategoryResponse();
        when(productClient.getCategories()).thenReturn(mockResponse);

        CategoryResponse response = pinelabsService.getCategory();
        assertNotNull(response);
        assertEquals(mockResponse, response);
    }
}