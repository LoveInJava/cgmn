package com.smartplay.apiservices.models.enums;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class VerificationStatusTest {

    @Test
    void testToString() {
        // Arrange
        VerificationStatus notVerified = VerificationStatus.NOTVERIFIED;
        VerificationStatus verificationInitiated = VerificationStatus.VERIFICATIONINITIATED;
        VerificationStatus verified = VerificationStatus.VERIFIED;
        VerificationStatus verificationFailed = VerificationStatus.VERIFICATIONFAILED;

        // Act & Assert
        assertEquals("NotVerified", notVerified.toString());
        assertEquals("VerificationInitiated", verificationInitiated.toString());
        assertEquals("Verified", verified.toString());
        assertEquals("VerificationFailed", verificationFailed.toString());
    }
}
