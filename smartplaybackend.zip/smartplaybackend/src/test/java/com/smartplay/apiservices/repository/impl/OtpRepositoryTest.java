package com.smartplay.apiservices.repository.impl;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class OtpRepositoryTest {

    private OtpService repository;

    @BeforeEach
    void setUp() {
        repository = new OtpService();
    }

    @Test
    void testSaveOtp() {
        // Arrange
        String phoneNumber = "1234567890";
        String otp = "1234";
        long ttlInSeconds = 60;

        // Act
        repository.saveOtp(phoneNumber, otp, ttlInSeconds);
        String savedOtp = repository.getOtp(phoneNumber);

        // Assert
        assertNotNull(savedOtp);
        assertEquals(otp, savedOtp);
    }

    @Test
    void testValidateOtp_ValidOtp() {
        // Arrange
        String phoneNumber = "1234567890";
        String otp = "1234";
        long ttlInSeconds = 60;
        repository.saveOtp(phoneNumber, otp, ttlInSeconds);

        // Act
        boolean isValid = repository.validateOtp(phoneNumber, otp);

        // Assert
        assertTrue(isValid);
        assertNull(repository.getOtp(phoneNumber));
    }

    @Test
    void testValidateOtp_InvalidOtp() {
        // Arrange
        String phoneNumber = "1234567890";
        String otp = "1234";
        long ttlInSeconds = 60;
        repository.saveOtp(phoneNumber, otp, ttlInSeconds);

        // Act
        boolean isValid = repository.validateOtp(phoneNumber, "5678");

        // Assert
        assertFalse(isValid);
        assertNotNull(repository.getOtp(phoneNumber));
    }

    @Test
    void testRemoveOtp() {
        // Arrange
        String phoneNumber = "1234567890";
        String otp = "1234";
        long ttlInSeconds = 60;
        repository.saveOtp(phoneNumber, otp, ttlInSeconds);

        // Act
        repository.removeOtp(phoneNumber);
        String removedOtp = repository.getOtp(phoneNumber);

        // Assert
        assertNull(removedOtp);
    }

    @Test
    void testGetOtp() {
        // Arrange
        String phoneNumber = "1234567890";
        String otp = "1234";
        long ttlInSeconds = 60;
        repository.saveOtp(phoneNumber, otp, ttlInSeconds);

        // Act
        String retrievedOtp = repository.getOtp(phoneNumber);

        // Assert
        assertNotNull(retrievedOtp);
        assertEquals(otp, retrievedOtp);
    }

}
