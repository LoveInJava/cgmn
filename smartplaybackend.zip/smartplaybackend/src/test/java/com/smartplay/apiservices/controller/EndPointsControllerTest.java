package com.smartplay.apiservices.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.Arrays;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartplay.apiservices.exceptions.InvalidRequestBadPayload;
import com.smartplay.apiservices.models.data.SmartPlayMoney;
import com.smartplay.apiservices.models.request.GamePointCategory;
import com.smartplay.apiservices.models.request.GamePointRequest;
import com.smartplay.apiservices.models.response.About;
import com.smartplay.apiservices.models.response.BannerInfo;
import com.smartplay.apiservices.models.response.Faq;
import com.smartplay.apiservices.models.response.News;
import com.smartplay.apiservices.models.response.NewsItem;
import com.smartplay.apiservices.models.response.PrivacyPolicy;
import com.smartplay.apiservices.repository.interfaces.IInMemoryRepository;
import com.smartplay.apiservices.services.interfaces.IConfigurationService;
import com.smartplay.apiservices.services.interfaces.IGamePointService;
import com.smartplay.apiservices.services.interfaces.IHeaderPayloadVerificationService;


class EndPointsControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private IGamePointService gamePointService;

    @Mock
    private IHeaderPayloadVerificationService headerPayloadVerificationService;

    @Mock
    private IInMemoryRepository<SmartPlayMoney, UUID> smartplayMoneyRepository;

    @Mock
    private IConfigurationService configurationService;

    @InjectMocks
    private EndPointsController controller;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
    }

    // @Test
    // void testGetSmartpoints() throws Exception {

    //     ZonedDateTime startDateTime = ZonedDateTime.parse("2007-12-03T10:15:30+05:30[Asia/Kolkata]");
	// 	ZonedDateTime endDateTime = ZonedDateTime.parse("2021-12-31T23:59:59+05:30[Asia/Kolkata]");
    //     var timerange = TimeRange.builder().start(startDateTime).end(endDateTime).build();

    //     Mockito.when(headerPayloadVerificationService.verifyHeaderToParamPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(true);
    //     Mockito.when(gamePointService.getCollectiveGamePointsByLpaId(anyString())).thenReturn(500);
    //     Mockito.when(gamePointService.getWelcomeBonusPoint(anyString())).thenReturn(100);
    //     // when(gamePointService.getCurrentGameEventDetails()).thenReturn(GamePointEventDetail.builder().bonus(100).target(1000).time(timerange).build());

    //     mockMvc.perform(MockMvcRequestBuilders
    //         .get("/api/v1/smartpoints/1234/lpaid001/")
    //         .header("device-id", "1234") // Add the header here
    //         .accept(MediaType.APPLICATION_JSON)
    //     )
    //         .andExpect(status().isOk());
    // }

    @Test
    void testAbout() throws Exception {
        when(configurationService.getAbout()).thenReturn(About.builder().info(BannerInfo.builder().banner("banner text").webUrl("https://demo.sirv.com/nuphar.jpg?w=100").build()).build());

        mockMvc.perform(MockMvcRequestBuilders
                .get("/api/v1/about")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.info.banner").value("banner text"))
                .andExpect(jsonPath("$.info.webUrl").value("https://demo.sirv.com/nuphar.jpg?w=100"));
    }

    @Test
    void testNews() throws Exception {
        when(configurationService.getNews()).thenReturn(News.builder().info(BannerInfo.builder().banner("banner text").webUrl("https://demo.sirv.com/nuphar.jpg?w=100").build())
                .details(Arrays.asList(
                        NewsItem.builder().id("10001").info(BannerInfo.builder().banner("banner text").webUrl("https://demo.sirv.com/nuphar.jpg?w=100").build()).order(2).build(),
                        NewsItem.builder().id("10002").info(BannerInfo.builder().banner("banner text").webUrl("https://demo.sirv.com/nuphar.jpg?w=100").build()).order(1).build()
                )).build());
        mockMvc.perform(MockMvcRequestBuilders
                .get("/api/v1/news")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.info.banner").value("banner text"))
                .andExpect(jsonPath("$.info.webUrl").value("https://demo.sirv.com/nuphar.jpg?w=100"))
                .andExpect(jsonPath("$.details[0].id").value("10001"))
                .andExpect(jsonPath("$.details[0].info.banner").value("banner text"))
                .andExpect(jsonPath("$.details[0].info.webUrl").value("https://demo.sirv.com/nuphar.jpg?w=100"))
                .andExpect(jsonPath("$.details[0].order").value(2))
                .andExpect(jsonPath("$.details[1].id").value("10002"))
                .andExpect(jsonPath("$.details[1].info.banner").value("banner text"))
                .andExpect(jsonPath("$.details[1].info.webUrl").value("https://demo.sirv.com/nuphar.jpg?w=100"))
                .andExpect(jsonPath("$.details[1].order").value(1));
    }

    @Test
    void testFaq() throws Exception {
        when(configurationService.getFaq()).thenReturn(Faq.builder().info(BannerInfo.builder().webUrl("https://storage.googleapis.com/smartplay-app-images/qna.json").build()).build());
        mockMvc.perform(MockMvcRequestBuilders
                .get("/api/v1/faq")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.info.webUrl").value("https://storage.googleapis.com/smartplay-app-images/qna.json"));
    }

    @Test
    void testPrivacyPolicy() throws Exception {
        when(configurationService.getPrivacyPolicy()).thenReturn(PrivacyPolicy.builder().info(BannerInfo.builder().banner("Privacy Policy Document").webUrl("https://storage.googleapis.com/smartplay-app-images/tnc.html").build()).build());
        mockMvc.perform(MockMvcRequestBuilders
                .get("/api/v1/privacypolicy")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.info.banner").value("Privacy Policy Document"))
                .andExpect(jsonPath("$.info.webUrl").value("https://storage.googleapis.com/smartplay-app-images/tnc.html"));
    }

    @Test
    void testRewards() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                .get("/api/v1/rewards/1234")
                .header(HttpHeaders.ACCEPT_LANGUAGE, "en-US")
                .header("device-id", "1234")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void testGames() throws Exception {
        when(configurationService.getGames()).thenReturn(com.smartplay.apiservices.models.response.Games.builder().info(BannerInfo.builder().description("List of games").banner("List of games").webUrl("https://demo.sirv.com/nuphar.jpg?w=100").build())
                .details(Arrays.asList(
                        com.smartplay.apiservices.models.response.GamesItem.builder().id("10001").info(BannerInfo.builder().description("Game1").banner("https://storage.googleapis.com/smartplay-app-images/gamelogo1.png").webUrl("https://demo.sirv.com/nuphar.jpg?w=100").build()).order(2).build(),
                        com.smartplay.apiservices.models.response.GamesItem.builder().id("10002").info(BannerInfo.builder().description("Game2").banner("https://storage.googleapis.com/smartplay-app-images/gamelogo2.png").webUrl("https://demo.sirv.com/nuphar.jpg?w=100").build()).order(1).build(),
                        com.smartplay.apiservices.models.response.GamesItem.builder().id("10003").info(BannerInfo.builder().description("Game3").banner("https://storage.googleapis.com/smartplay-app-images/gamelogo3.png").webUrl("https://demo.sirv.com/nuphar.jpg?w=100").build()).order(2).build(),
                        com.smartplay.apiservices.models.response.GamesItem.builder().id("10004").info(BannerInfo.builder().description("Game4").banner("https://storage.googleapis.com/smartplay-app-images/gamelogo4.png").webUrl("https://demo.sirv.com/nuphar.jpg?w=100").build()).order(1).build()
                )).build());
        mockMvc.perform(MockMvcRequestBuilders
                .get("/api/v1/games")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.info.banner").value("List of games"))
                .andExpect(jsonPath("$.info.webUrl").value("https://demo.sirv.com/nuphar.jpg?w=100"))
                .andExpect(jsonPath("$.details[0].id").value("10001"))
                .andExpect(jsonPath("$.details[0].info.description").value("Game1"))
                .andExpect(jsonPath("$.details[0].info.banner").value("https://storage.googleapis.com/smartplay-app-images/gamelogo1.png"))
                .andExpect(jsonPath("$.details[0].info.webUrl").value("https://demo.sirv.com/nuphar.jpg?w=100"))
                .andExpect(jsonPath("$.details[0].order").value(2))
                .andExpect(jsonPath("$.details[1].id").value("10002"))
                .andExpect(jsonPath("$.details[1].info.description").value("Game2"))
                .andExpect(jsonPath("$.details[1].info.banner").value("https://storage.googleapis.com/smartplay-app-images/gamelogo2.png"))
                .andExpect(jsonPath("$.details[1].info.webUrl").value("https://demo.sirv.com/nuphar.jpg?w=100"))
                .andExpect(jsonPath("$.details[1].order").value(1))
                .andExpect(jsonPath("$.details[2].id").value("10003"))
                .andExpect(jsonPath("$.details[2].info.description").value("Game3"))
                .andExpect(jsonPath("$.details[2].info.banner").value("https://storage.googleapis.com/smartplay-app-images/gamelogo3.png"))
                .andExpect(jsonPath("$.details[2].info.webUrl").value("https://demo.sirv.com/nuphar.jpg?w=100"))
                .andExpect(jsonPath("$.details[2].order").value(2))
                .andExpect(jsonPath("$.details[3].id").value("10004"))
                .andExpect(jsonPath("$.details[3].info.description").value("Game4"))
                .andExpect(jsonPath("$.details[3].info.banner").value("https://storage.googleapis.com/smartplay-app-images/gamelogo4.png"))
                .andExpect(jsonPath("$.details[3].info.webUrl").value("https://demo.sirv.com/nuphar.jpg?w=100"))
                .andExpect(jsonPath("$.details[3].order").value(1));
    }

    // @Test
    // void testSmartpoints() throws Exception {
    //     ZonedDateTime startDateTime = ZonedDateTime.parse("2007-12-03T10:15:30+05:30[Asia/Kolkata]");
	// 	ZonedDateTime endDateTime = ZonedDateTime.parse("2021-12-31T23:59:59+05:30[Asia/Kolkata]");
    //     var timerange = TimeRange.builder().start(startDateTime).end(endDateTime).build();

    //     when(smartplayMoneyRepository.getAll()).thenReturn(Arrays.asList(
    //             SmartPlayMoney.builder().lpaId("lpaid001").money(Money.builder().amount(100).currency(Currency.INR).build()).build(),
    //             SmartPlayMoney.builder().lpaId("lpaid001").money(Money.builder().amount(200).currency(Currency.INR).build()).build()
    //     ));
    //     when(gamePointService.getCollectiveGamePointsByLpaId(anyString())).thenReturn(500);
    //     when(gamePointService.getCurrentGameEventDetails()).thenReturn(GamePointEventDetail.builder().bonus(100).target(1000).time(timerange).build());


    //     when(headerPayloadVerificationService.verifyHeaderToParamPayload(anyString(), anyString())).thenReturn(true);
    //     when(smartplayMoneyRepository.getAll()).thenReturn(Arrays.asList(
    //             SmartPlayMoney.builder().lpaId("lpaid001").money(Money.builder().amount(100).currency(Currency.INR).build()).build(),
    //             SmartPlayMoney.builder().lpaId("lpaid001").money(Money.builder().amount(200).currency(Currency.INR).build()).build()
    //     ));
    //     when(gamePointService.getCollectiveGamePointsByLpaId(anyString())).thenReturn(500);

    //     mockMvc.perform(MockMvcRequestBuilders
    //             .get("/api/v1/smartpoints/1234/lpaid001/")
    //             .header("device-id", "1234")
    //             .accept(MediaType.APPLICATION_JSON))
    //             .andExpect(status().isOk())
    //             .andExpect(jsonPath("$.details.points.actual").value(500))
    //             .andExpect(jsonPath("$.details.points.bonus").value(100))
    //             .andExpect(jsonPath("$.details.points.target").value(1000))
    //             .andExpect(jsonPath("$.details.cashout.amount").value(300))
    //             .andExpect(jsonPath("$.details.cashout.currency").value("INR"))
    //             .andExpect(jsonPath("$.details.cashout.symbol").value("₹"));
    // }

    @Test
    @Disabled("Test failing because handling has been moved to aspect")
    void testSmartpoints_InvalidPayload() throws Exception {
        when(headerPayloadVerificationService.verifyHeaderToParamPayload(anyString(), anyString())).thenReturn(false);

        mockMvc.perform(MockMvcRequestBuilders
                .get("/api/v1/smartpoints/1234/lpaid001/")
                .header("device-id", "1234")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(result -> assertTrue(result.getResolvedException() instanceof InvalidRequestBadPayload));
    }

    @Test
    void testSmartpoints_Post() throws Exception {
        String geoCoordinates = "40.7128,-74.0060";
        String deviceId = "1234";

        GamePointRequest gamePointRequest = GamePointRequest.builder().gameId("10001").category(GamePointCategory.CATEGORY1)
        .geocoordinates(geoCoordinates).lpaId("lpaid001").requestId("requestId001").build();

        mockMvc.perform(MockMvcRequestBuilders
            .post("/api/v1/smartpoints/" + deviceId + "/")
            .header("device-id", deviceId)
            .header("geo-cordinates", geoCoordinates)
            .contentType(MediaType.APPLICATION_JSON)
            .content(asJsonString(gamePointRequest))
            .accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk());

        verify(gamePointService, times(1)).updateGamePoint(gamePointRequest);
    }

    // Helper method to convert object to JSON string
    private String asJsonString(Object obj) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
