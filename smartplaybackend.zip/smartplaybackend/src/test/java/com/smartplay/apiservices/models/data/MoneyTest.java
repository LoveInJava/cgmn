package com.smartplay.apiservices.models.data;

import java.math.BigDecimal;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.smartplay.apiservices.models.enums.Currency;
class MoneyTest {

    @Test
    void testGetAmount() {
        Money money = new Money(new BigDecimal("10.0"), Currency.USD);
        Assertions.assertEquals(new BigDecimal("10.0"), money.getAmount());
    }

    @Test
    void testGetCurrency() {
        Money money = new Money(new BigDecimal("10.0"), Currency.USD);
        Assertions.assertEquals(Currency.USD, money.getCurrency());
    }

    @Test
    void testEqualsAndHashCode() {
        Money money1 = new Money(new BigDecimal("10.0"), Currency.USD);
        Money money2 = new Money(new BigDecimal("10.0"), Currency.USD);
        Assertions.assertEquals(money1, money2);
        Assertions.assertEquals(money1.hashCode(), money2.hashCode());
    }
}
