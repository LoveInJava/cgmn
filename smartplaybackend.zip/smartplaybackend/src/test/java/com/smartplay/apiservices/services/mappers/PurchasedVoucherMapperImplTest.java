package com.smartplay.apiservices.services.mappers;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.smartplay.apiservices.models.response.PurchasedVoucher;
import com.smartplay.apiservices.models.response.PurchasedVoucherResponse;

class PurchasedVoucherMapperImplTest {

    private PurchasedVoucherMapperImpl purchasedVoucherMapper;

    @BeforeEach
    public void setUp() {
        purchasedVoucherMapper = new PurchasedVoucherMapperImpl();
    }

    @Test
    void testToResponse_NullInput() {
        PurchasedVoucherResponse response = purchasedVoucherMapper.toResponse(null);
        assertNull(response);
    }

    @Test
    void testToResponse_ValidInput() {
        PurchasedVoucher purchasedVoucher = new PurchasedVoucher();
        purchasedVoucher.setId("LPA001");
        purchasedVoucher.setLpaId("LPA123");
        purchasedVoucher.setPurchasedOn(LocalDateTime.of(2023, 10, 1, 12, 0));
        purchasedVoucher.setAmount(BigDecimal.valueOf(100));
        purchasedVoucher.setVoucherName("VoucherName");

        PurchasedVoucherResponse response = purchasedVoucherMapper.toResponse(purchasedVoucher);

        assertNotNull(response);
        assertEquals("LPA001", response.getId());
        assertEquals("LPA123", response.getLpaId());
        assertEquals("2023-10-01T12:00:00", response.getPurchasedOn());
        assertEquals(100.0, response.getAmount());
        assertEquals("VoucherName", response.getVoucherName());
    }

    @Test
    void testToResponseList_NullInput() {
        List<PurchasedVoucherResponse> responseList = purchasedVoucherMapper.toResponseList(null);
        assertNull(responseList);
    }

    @Test
    void testToResponseList_ValidInput() {
        PurchasedVoucher purchasedVoucher1 = new PurchasedVoucher();
        purchasedVoucher1.setId("LPA001");
        purchasedVoucher1.setLpaId("LPA123");
        purchasedVoucher1.setPurchasedOn(LocalDateTime.of(2023, 10, 1, 12, 0));
        purchasedVoucher1.setAmount(BigDecimal.valueOf(100));
        purchasedVoucher1.setVoucherName("VoucherName1");

        PurchasedVoucher purchasedVoucher2 = new PurchasedVoucher();
        purchasedVoucher2.setId("LPA002");
        purchasedVoucher2.setLpaId("LPA124");
        purchasedVoucher2.setPurchasedOn(LocalDateTime.of(2023, 10, 2, 12, 0));
        purchasedVoucher2.setAmount(BigDecimal.valueOf(200));
        purchasedVoucher2.setVoucherName("VoucherName2");

        List<PurchasedVoucher> purchasedVouchers = Arrays.asList(purchasedVoucher1, purchasedVoucher2);

        List<PurchasedVoucherResponse> responseList = purchasedVoucherMapper.toResponseList(purchasedVouchers);

        assertNotNull(responseList);
        assertEquals(2, responseList.size());

        PurchasedVoucherResponse response1 = responseList.get(0);
        assertEquals("LPA001", response1.getId());
        assertEquals("LPA123", response1.getLpaId());
        assertEquals("2023-10-01T12:00:00", response1.getPurchasedOn());
        assertEquals(100.0, response1.getAmount());
        assertEquals("VoucherName1", response1.getVoucherName());

        PurchasedVoucherResponse response2 = responseList.get(1);
        assertEquals("LPA002", response2.getId());
        assertEquals("LPA124", response2.getLpaId());
        assertEquals("2023-10-02T12:00:00", response2.getPurchasedOn());
        assertEquals(200.0, response2.getAmount());
        assertEquals("VoucherName2", response2.getVoucherName());
    }
}
