package com.smartplay.apiservices.repository.impl;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.springframework.stereotype.Service;

@Service
public class OtpService  {

    private final ConcurrentHashMap<String, String> otpData = new ConcurrentHashMap<>();
    private final ScheduledExecutorService executorService = Executors.newScheduledThreadPool(1);

    public void saveOtp(String phoneNumber, String otp, long ttlInSeconds) {
        otpData.put(phoneNumber, otp);
        executorService.schedule(() -> otpData.remove(phoneNumber), ttlInSeconds, TimeUnit.SECONDS);
    }

    public boolean validateOtp(String phoneNumber, String otp) {
        String existingOtp = otpData.get(phoneNumber);
        var status= existingOtp != null && existingOtp.equals(otp);
        if(status)
            removeOtp(phoneNumber);
        return status;
    }

    public void removeOtp(String phoneNumber) {
        otpData.remove(phoneNumber);
    }

    public String getOtp(String phoneNumber) {
        return otpData.getOrDefault(phoneNumber, null);
    }

}
