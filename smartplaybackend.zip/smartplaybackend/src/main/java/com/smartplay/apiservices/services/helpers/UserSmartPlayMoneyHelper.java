package com.smartplay.apiservices.services.helpers;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import com.smartplay.apiservices.models.data.CashoutOrder;
import com.smartplay.apiservices.models.data.Money;
import com.smartplay.apiservices.models.data.SmartPlayMoney;
import com.smartplay.apiservices.models.data.UserSmartPlayMoney;
import com.smartplay.apiservices.models.enums.Currency;
import com.smartplay.apiservices.models.response.Cashout;

public class UserSmartPlayMoneyHelper {

	private UserSmartPlayMoneyHelper() {
	}

	public static Cashout getAvailableCash(UUID lastTimerId, UUID timerId, UserSmartPlayMoney userSmartPlayMoney) {

		BigDecimal totalAmount = userSmartPlayMoney.getRecords().stream()
				.map(SmartPlayMoney::getMoney)
				.map(Money::getAmount)
				.reduce(BigDecimal.ZERO, BigDecimal::add);

		BigDecimal totalWithdrawlAmount = userSmartPlayMoney.getCashouts().stream()
				.map(CashoutOrder::getMoney)
				.map(Money::getAmount)
				.reduce(BigDecimal.ZERO, BigDecimal::add);

		totalAmount = totalAmount.subtract(totalWithdrawlAmount);

		if (timerId == null) {
			return Cashout.builder()
					.amount(totalAmount).currency(Currency.INR.toString()).symbol(Currency.INR.getSymbol())
					.build();
		}

		BigDecimal currentAmount = getCurrentAmountBySessions(lastTimerId, timerId, userSmartPlayMoney);
		//BigDecimal withdrawlAmountBySessions = getWithdrawlAmountBySessions(lastTimerId, timerId, userSmartPlayMoney);

		System.out.println("Current Amount in Session : "+ currentAmount);
		//System.out.println("Withdrawl Amount in Session : "+ withdrawlAmountBySessions);
		
		//currentAmount = currentAmount.subtract(withdrawlAmountBySessions);

		return Cashout.builder()
				.amount(totalAmount).currency(Currency.INR.toString()).symbol(Currency.INR.getSymbol())
				.currentAmount(currentAmount).build();
	}

	private static BigDecimal getCurrentAmountBySessions(UUID lastTimerId, UUID timerId,
			UserSmartPlayMoney userSmartPlayMoney) {

		BigDecimal currentAmount = BigDecimal.ZERO;

		List<SmartPlayMoney> list = userSmartPlayMoney.getRecords();

		SmartPlayMoney lastTimerSmartPlayMoney = list.stream()
				.filter(x -> x.getTimerId().equals(lastTimerId))
				.findFirst()
				.orElse(null);

		SmartPlayMoney currentTimerSmartPlayMoney = list.stream()
				.filter(x -> x.getTimerId().equals(timerId))
				.findFirst()
				.orElse(null);

		// If currentTimerSmartPlayMoney is null, assign the last record
		if (currentTimerSmartPlayMoney == null && !list.isEmpty()) {
			currentTimerSmartPlayMoney = list.get(list.size() - 1);
		}

		if (lastTimerSmartPlayMoney != null && currentTimerSmartPlayMoney != null) {
			for (SmartPlayMoney smartPlayMoney : list) {
				
				if (smartPlayMoney != null
						&& (smartPlayMoney.getStartTime().isEqual(lastTimerSmartPlayMoney.getStartTime())
								|| smartPlayMoney.getStartTime().isAfter(lastTimerSmartPlayMoney.getStartTime()))
						&& (lastTimerSmartPlayMoney.getStartTime().isBefore(currentTimerSmartPlayMoney.getStartTime()) 
						|| lastTimerSmartPlayMoney.getStartTime().isEqual(currentTimerSmartPlayMoney.getStartTime())) ) {
					currentAmount = currentAmount.add(smartPlayMoney.getMoney().getAmount());
				}
			}
		}
		return currentAmount;
	}
}
