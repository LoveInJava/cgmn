package com.smartplay.apiservices.models.request;

import java.math.BigDecimal;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@NotNull
public class RevenueDetailsRequest {

	@NotNull(message = "adId is required.")
	private String adId;

	@NotNull(message = "lpaId is required.")
	private String lpaId;

	@NotNull(message = "deviceId is required.")
	private String deviceId;

	@NotNull(message = "networkName is required.")
	private String networkName;

	@NotNull(message = "revenue is required.")
	private BigDecimal revenue;

	@NotNull(message = "currency is required.")
	private String currency;

	@NotNull(message = "gamePackageId is required.")
	private String gamePackageId;

	@NotNull(message = "adType is required.")
	private String adType;

	@NotNull(message = "Source device IP is required.")
	private String registeredDeviceIp;

}
