package com.smartplay.apiservices.services.integration.payments.pinelabs.models;

import java.util.List;

import lombok.Data;

@Data
public class ErrorModel {
    private int code;
    private String message;
    private List<String> messages;

}
