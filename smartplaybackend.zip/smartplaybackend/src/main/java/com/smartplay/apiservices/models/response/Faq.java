package com.smartplay.apiservices.models.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@Builder
@NoArgsConstructor
public class Faq{

	@Getter
	@Builder.Default
	private ReponseType type = ReponseType.FAQ;

	@Getter
	@Setter
	private BannerInfo info;

}
