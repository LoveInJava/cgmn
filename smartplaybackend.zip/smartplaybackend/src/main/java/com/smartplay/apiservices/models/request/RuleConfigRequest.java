package com.smartplay.apiservices.models.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@NotNull
public class RuleConfigRequest {

    @NotNull(message = "Rule Id is required")
    @NotEmpty(message = "Rule Id must not be empty")
    @JsonProperty("ruleId")
    private String ruleId;

    @NotNull(message = "Rule is required")
    @NotEmpty(message = "Rule must not be empty")
    private String rule;

    @NotNull(message = "Rule Value is required")
    @NotEmpty(message = "Rule Value must not be empty")
    private String value;

}
