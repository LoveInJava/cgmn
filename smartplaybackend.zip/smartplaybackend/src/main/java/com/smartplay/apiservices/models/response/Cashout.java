package com.smartplay.apiservices.models.response;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class Cashout {

	private BigDecimal amount;

	private String currency;

	private String symbol;

	private BigDecimal currentAmount;

}
