package com.smartplay.apiservices.models.request;

public interface GroupEmailUsername {
    // group marker interface
}
