package com.smartplay.apiservices.tools.converters;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverter;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.Payout;

public class PayoutConverter implements DynamoDBTypeConverter<String, Payout> {
    private static final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public String convert(Payout object) {
        try {
            return objectMapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error converting Payout to String", e);
        }
    }

    @Override
    public Payout unconvert(String object) {
        try {
            return objectMapper.readValue(object, Payout.class);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error converting String to Payout", e);
        }
    }
}