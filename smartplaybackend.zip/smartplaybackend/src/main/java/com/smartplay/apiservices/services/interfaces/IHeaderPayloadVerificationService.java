package com.smartplay.apiservices.services.interfaces;

public interface IHeaderPayloadVerificationService {

    boolean verifyHeaderToParamPayload(String headerDeviceid, String paramDeviceId);
}
