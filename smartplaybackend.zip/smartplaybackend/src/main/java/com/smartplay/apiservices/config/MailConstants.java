package com.smartplay.apiservices.config;

public class MailConstants {
    public static final String MAIL_HOST = "spring.mail.host";
    public static final String MAIL_PORT = "spring.mail.port";
    public static final String MAIL_USERNAME = "spring.mail.username";
    public static final String MAIL_PASSWORD = "spring.mail.password";
    public static final String EMAIL_VERIFICATION_URL = "EMAIL_VERIFICATION_URL";
}