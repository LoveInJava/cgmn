package com.smartplay.apiservices.services.interfaces;

import java.util.List;

import com.smartplay.apiservices.models.data.PinelabPurchasedVoucher;
import com.smartplay.apiservices.models.data.PinelabsProduct;
import com.smartplay.apiservices.models.data.RuleConfig;
import com.smartplay.apiservices.models.data.VoucherProduct;
import com.smartplay.apiservices.models.request.RuleConfigRequest;
import com.smartplay.apiservices.models.response.PurchasedVoucher;
import com.smartplay.apiservices.models.response.PurchasedVoucherResponse;
import com.smartplay.apiservices.models.response.RuleConfigResponse;
import com.smartplay.apiservices.models.response.Voucher;
import com.smartplay.apiservices.models.response.VoucherResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.ProductResponse;

public interface IMapper {
    PurchasedVoucherResponse map(PurchasedVoucher purchasedVoucher);

    List<PurchasedVoucherResponse> map(List<PurchasedVoucher> purchasedVoucherList);

    Voucher map(VoucherProduct voucherProduct);

    List<Voucher> mapToVouchers(List<VoucherProduct> voucherProductList);

    // PurchasedVoucher mapToPurchasedVoucher(VoucherOrderRequest orderRequest, String voucherName, String lpaId);

    VoucherResponse mapPinelabsProductToVoucherResponse(List<PinelabsProduct> pinelabsProducts);

    Voucher mapToVoucher(ProductResponse productDetails);

    List<PurchasedVoucher> mapResponse(List<PinelabPurchasedVoucher> records);

    RuleConfig mapToRuleConfig(RuleConfigRequest ruleConfigRequest);

    RuleConfigResponse mapToRuleConfigResponse(RuleConfig ruleConfig);


}
