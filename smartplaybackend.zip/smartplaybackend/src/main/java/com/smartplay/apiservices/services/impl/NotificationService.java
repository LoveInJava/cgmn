package com.smartplay.apiservices.services.impl;

import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import com.smartplay.apiservices.exceptions.NotImplementedException;
import com.smartplay.apiservices.repository.impl.OtpService;
import com.smartplay.apiservices.services.interfaces.INotificationService;
import com.smartplay.apiservices.services.interfaces.ISmsService;
import com.smartplay.apiservices.services.interfaces.IVoucherSmsService;

import lombok.SneakyThrows;

@Service
public class NotificationService implements INotificationService {

    private final ApplicationEventPublisher applicationEventPublisher;
    private final OtpService otpRepository;
    private final ISmsService smsService;
    private final IVoucherSmsService voucherSmsService;

    public NotificationService(
        @Autowired ApplicationEventPublisher applicationEventPublisher,
        @Autowired OtpService otpRepository,
        @Autowired ISmsService smsService,
        @Autowired IVoucherSmsService voucherSmsService) {
        super();
        this.applicationEventPublisher = applicationEventPublisher;
        this.otpRepository = otpRepository;
        this.voucherSmsService = voucherSmsService;
        this.smsService = smsService;

    }

    @Override
    public <T> void publishEvent(T event) {
        applicationEventPublisher.publishEvent(event);
    }

    @Override
    public void sendSms(String phoneNumber, String message) {
        voucherSmsService.sendSms(phoneNumber, message);
    }

    @Override
    @SneakyThrows
    public void sendEmail(String emailAddress,String subject, String message){
        throw new NotImplementedException("Not implemented");
    }

    @Override
    public void sendVerificationCode(String phoneNumber, String verificationCode) {
        otpRepository.saveOtp(phoneNumber, verificationCode, 180);
        CompletableFuture.runAsync(() -> smsService.sendVerificationCode(phoneNumber, verificationCode));
    }

    @Override
    public void retrySendVerificationCode(String phoneNumber, String newVerificationCode) {
        var otp = otpRepository.getOtp(phoneNumber);
        if(otp == null){
            otp = newVerificationCode;
        }
        this.sendVerificationCode(phoneNumber, otp);
    }

}
