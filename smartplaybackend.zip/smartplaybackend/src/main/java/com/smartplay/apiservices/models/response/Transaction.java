package com.smartplay.apiservices.models.response;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.smartplay.apiservices.config.JsonConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class Transaction {

	private String id;

	private Cashout cashout;

	private String type;

	@JsonFormat(pattern =JsonConfig.UTC_DATE_TIME_TZ_FORMAT, timezone = JsonConfig.UTC)
	private LocalDateTime timestamp;

	private String description;

	private String txnnumber;

	private String txnstatus;
}
