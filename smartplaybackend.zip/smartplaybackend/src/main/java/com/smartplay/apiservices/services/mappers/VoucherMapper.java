package com.smartplay.apiservices.services.mappers;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.smartplay.apiservices.models.data.VoucherProduct;
import com.smartplay.apiservices.models.response.Voucher;

@Mapper
public interface VoucherMapper {

    VoucherMapper INSTANCE = Mappers.getMapper(VoucherMapper.class);

    @Mapping(source = "providerSku", target = "sku")
    @Mapping(source = "name", target = "name")
    @Mapping(source = "description", target = "description")
    @Mapping(source = "image", target = "image")
    @Mapping(source = "currencyID", target = "currencyID")
    @Mapping(source = "tags", target = "tags")
    @Mapping(source = "denominations", target = "denominations")
    @Mapping(source = "tnc", target = "tnc")
    @Mapping(source = "tncUrl", target = "tncUrl")
    Voucher toVoucher(VoucherProduct voucherProduct);

    public List<Voucher> toResponseList(List<VoucherProduct> voucherProductList);
}
