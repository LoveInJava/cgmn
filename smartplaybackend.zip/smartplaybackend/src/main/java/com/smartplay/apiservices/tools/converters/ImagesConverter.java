package com.smartplay.apiservices.tools.converters;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverter;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.Images;

public class ImagesConverter implements DynamoDBTypeConverter<String, Images> {
    private static final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public String convert(Images object) {
        try {
            return objectMapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error converting Images to String", e);
        }
    }

    @Override
    public Images unconvert(String object) {
        try {
            return objectMapper.readValue(object, Images.class);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error converting String to Images", e);
        }
    }
}