package com.smartplay.apiservices.tools.utils;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

public class DateUtils {

    public static final String dd_MMM_yyyy = "dd-MMM-yyyy";
    public static final String yyyy_MM_dd_T_HH_mm_ssXXX = "yyyy-MM-dd'T'HH:mm:ssXXX";

    public static String convertDate(String inputFormat, String inputDate, String dd_MMM_yyyy){

        String formattedDate = "";

        switch (inputFormat) {
            case yyyy_MM_dd_T_HH_mm_ssXXX:
            OffsetDateTime dateTime = OffsetDateTime.parse(inputDate);
            // Define the desired output format
            DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern(dd_MMM_yyyy);  
            // Format the date
            formattedDate = dateTime.format(outputFormatter);
                break;
        
            default:
                break;
        }
        
        return formattedDate;
    }

}
