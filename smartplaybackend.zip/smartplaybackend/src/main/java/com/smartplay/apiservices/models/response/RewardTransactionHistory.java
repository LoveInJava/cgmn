package com.smartplay.apiservices.models.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class RewardTransactionHistory {

	private String id;

	private String amount;

	private String transactionId;

	private String result;

}
