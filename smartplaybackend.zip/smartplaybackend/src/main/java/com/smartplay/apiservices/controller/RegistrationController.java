package com.smartplay.apiservices.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartplay.apiservices.models.request.MobileRegistrationRequest;
import com.smartplay.apiservices.models.request.VerificationRequest;
import com.smartplay.apiservices.models.response.RegistrationStatus;
import com.smartplay.apiservices.services.interfaces.IRegistrationService;
import com.smartplay.apiservices.tools.VerifyHeaderToParamPayload;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1")
@Tag(name = "mobile", description = "Api's for mobile devices")
@Validated
public class RegistrationController {

    private final IRegistrationService registrationService;

    public RegistrationController(
        @Autowired IRegistrationService registrationService
        ) {
        this.registrationService = registrationService;
    }

    @PostMapping(value = "mobile/register/{device-id}", produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Register mobile number to Smartplay")
    @VerifyHeaderToParamPayload(headerDeviceId = "device-id", paramDeviceId = "device-id")
    public ResponseEntity<RegistrationStatus> registerFromDevice(
        @Parameter(description = "Encrypted device ID GAID( google)/IDFA (Apple)") @RequestHeader("device-id") String headerDeviceId,
        @Parameter(description = "Device id") @PathVariable("device-id") String paramDeviceId,
        @RequestBody @Valid MobileRegistrationRequest registrationRequest) {

            var user = registrationService.handleRegistrationRequest(registrationRequest.getMobile(), registrationRequest.getDeviceToken(), paramDeviceId);
            var registrationStatus = registrationService.generateStatusByLpaUser(user, paramDeviceId);
            return ResponseEntity.ok().body(registrationStatus);
    }

    @GetMapping(value="mobile/register/{device-id}/{lpa-id}", produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Get Smartplay user by lpaId")
    @VerifyHeaderToParamPayload(headerDeviceId = "device-id", paramDeviceId = "device-id")
    public ResponseEntity<RegistrationStatus> getUserById(
        @Parameter(description = "Encrypted device ID GAID( google)/IDFA (Apple)") @RequestHeader("device-id") String headerDeviceId,
        @Parameter(description = "Device id") @PathVariable("device-id") String paramDeviceId,
        @Parameter(description = "LPA id") @PathVariable("lpa-id") String lpaId) {

            var registrationStatus = registrationService.getRegistrationStatusByLpaIdDeviceId(lpaId, paramDeviceId);
            return ResponseEntity.ok().body(registrationStatus);
    }

    @PostMapping(value = "mobile/verify/{device-id}", produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "OTP Verification")
    @VerifyHeaderToParamPayload(headerDeviceId = "device-id", paramDeviceId = "device-id")
    public ResponseEntity<Void> verifyFromDevice(
        @Parameter(description = "Encrypted device ID GAID( google)/IDFA (Apple)") @RequestHeader("device-id") String headerDeviceId,
        @Parameter(description = "Device id") @PathVariable("device-id") String paramDeviceId,
        @RequestBody @Valid VerificationRequest verificationRequest) {

        registrationService.handleVerificationCodeSubmission(verificationRequest.getMobile(), paramDeviceId, verificationRequest.getVerificationCode());
        return ResponseEntity.ok().build();
    }

    @GetMapping(value = "status/device/{device-id}", produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Get registration Status by device id")
    @Tag(name = "game", description = "api's for regstered games")
    public ResponseEntity<RegistrationStatus> getStatusByDeviceId(
        @Parameter(description = "Device id") @RequestHeader("device-id") String deviceId,
        @Parameter(description = "Device id") @PathVariable("device-id") String paramDeviceId) {

        var user = registrationService.getRegistrationStatusByDeviceid(deviceId);
        var registrationStatus = registrationService.generateStatusByLpaUser(user, deviceId);
        return ResponseEntity.ok().body(registrationStatus);
    }

    @PostMapping("mobile/resendverificationotp/{device-id}/{mobile}")
    @Operation(summary = "Resend OTP Verification")
    @VerifyHeaderToParamPayload(headerDeviceId = "device-id", paramDeviceId = "device-id")
    public ResponseEntity<Void> resendVerificationOtp(
        @Parameter(description = "Encrypted device ID GAID( google)/IDFA (Apple)") @RequestHeader("device-id") String headerDeviceId,
        @Parameter(description = "Device id") @PathVariable("device-id") String paramDeviceId,
        @Parameter(description = "Mobile Number") @PathVariable("mobile") String mobileNumber) {

        registrationService.handleResendOtpVerificationCode(mobileNumber, paramDeviceId);
        return ResponseEntity.ok().build();
    }

}
