package com.smartplay.apiservices.services.integration.payments.pinelabs.models;

import java.util.ArrayList;
import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverted;
import com.smartplay.apiservices.tools.converters.DiscountListConverter;
import com.smartplay.apiservices.tools.converters.FulfillmentListConverter;
import com.smartplay.apiservices.tools.converters.ImagesConverter;
import com.smartplay.apiservices.tools.converters.IntegerListConverter;
import com.smartplay.apiservices.tools.converters.PayoutConverter;
import com.smartplay.apiservices.tools.converters.RelatedProductListConverter;
import com.smartplay.apiservices.tools.converters.ThemeListConverter;
import com.smartplay.apiservices.tools.converters.TncConverter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProductResponse {
    
    private String id;
    private String sku;
    private String name;
    private String description;
    // private String shortDescription;
    private Price price;
    private String kycEnabled;
    @Builder.Default
    @DynamoDBTypeConverted(converter = FulfillmentListConverter.class)
    private List<Fulfillment> allowed_fulfillments = new ArrayList<>();
    private String additionalForm;
    private MetaInformation metaInformation;
    private String type;
    private Boolean schedulingEnabled;
    private String currency;

    @DynamoDBTypeConverted(converter = ImagesConverter.class)
    private Images images;
    @DynamoDBTypeConverted(converter = TncConverter.class)
    private Tnc tnc;
    @Builder.Default
    @DynamoDBTypeConverted(converter = IntegerListConverter.class)
    private List<Integer> categories= new ArrayList<>();
    @Builder.Default
    @DynamoDBTypeConverted(converter = ThemeListConverter.class)
    private List<Theme> themes = new ArrayList<>();
    private Boolean reloadCardNumber;
    private String expiry;
    private String formatExpiry;
    @Builder.Default
    @DynamoDBTypeConverted(converter = DiscountListConverter.class)
    private List<Discount> discounts = new ArrayList<>();
    @Builder.Default
    @DynamoDBTypeConverted(converter = RelatedProductListConverter.class)
    private List<RelatedProduct> relatedProducts = new ArrayList<>();
    private String storeLocatorUrl;
    private String brandName;
    private String etaMessage;
    @DynamoDBTypeConverted(converter = PayoutConverter.class)
    private Payout payout;
    // @Builder.Default
    // private List<ConvenienceCharges> convenience_charges = new ArrayList<>();
    private String createdAt;
    private String updatedAt;
    private Cpg cpg;
}
