package com.smartplay.apiservices.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.smartplay.apiservices.exceptions.DataNotFoundException;
import com.smartplay.apiservices.exceptions.InvalidPhoneNumberException;
import com.smartplay.apiservices.exceptions.InvalidRequestBadPayload;
import com.smartplay.apiservices.exceptions.InvalidVerificationCodeException;
import com.smartplay.apiservices.exceptions.PhoneNumberAlreadyRegisteredException;
import com.smartplay.apiservices.exceptions.PhoneNumberAlreadyVerifiedException;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

@RestControllerAdvice
@Slf4j
public class CustomGlobalExceptionHandler extends ResponseEntityExceptionHandler {

    private static final String EXCEPTION_MESSAGE = "CustomGlobalExceptionHandler:: Exception occurred";

    @ExceptionHandler(InvalidPhoneNumberException.class)
    public ResponseEntity<Map<String, Object>> handleInvalidPhoneNumberException(HttpServletResponse response, HttpServletRequest request, InvalidPhoneNumberException ex) {
        log.error(EXCEPTION_MESSAGE, ex);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
    }

    @ExceptionHandler(PhoneNumberAlreadyRegisteredException.class)
    public ResponseEntity<Map<String, Object>> handlePhoneNumberAlreadyRegisteredException(HttpServletResponse response,
            HttpServletRequest request, PhoneNumberAlreadyRegisteredException ex
            ) {

        response.setStatus(HttpStatus.SEE_OTHER.value()); // set status code to 303

        UriComponents location = UriComponentsBuilder.fromPath("/api/v1/status/{lpaid}").buildAndExpand(ex.getLpaId());


        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put("message", "Redirect to: " + location.toUriString());
        responseBody.put("status", HttpStatus.SEE_OTHER.value());

        return ResponseEntity.status(HttpStatus.SEE_OTHER)
                .header("Location", location.toUriString())
                .body(responseBody);
    }

    @ExceptionHandler(PhoneNumberAlreadyVerifiedException.class)
    public ResponseEntity<Map<String, Object>>  handlePhoneNumberAlreadyVerifiedException(HttpServletResponse response,
    HttpServletRequest request, PhoneNumberAlreadyVerifiedException ex) {
        log.error(EXCEPTION_MESSAGE, ex);
        return ResponseEntity.status(HttpStatus.CONFLICT).build();
    }

    @ExceptionHandler(InvalidVerificationCodeException.class)
    public ResponseEntity<Map<String, Object>>  handleInvalidVerificationCodeException(HttpServletResponse response,
    HttpServletRequest request, InvalidVerificationCodeException ex) {
        log.error(EXCEPTION_MESSAGE, ex);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
    }

    @ExceptionHandler(InvalidRequestBadPayload.class)
    public ResponseEntity<Map<String, Object>>  handleInvalidRequestBadPayload(HttpServletResponse response,
    HttpServletRequest request, InvalidRequestBadPayload ex) {
        log.error(EXCEPTION_MESSAGE, ex);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
    }

    @ExceptionHandler(DataNotFoundException.class)
    public ResponseEntity<Map<String, Object>>  handleInvalidRequestDataNotFoundException(HttpServletResponse response,
    HttpServletRequest request, DataNotFoundException ex) {
        log.error(EXCEPTION_MESSAGE, ex);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

}
