package com.smartplay.apiservices.models.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@SuperBuilder
@NoArgsConstructor
@Data
public class ProductOption {
    private String id;
    private String currencyID;
    private String name;
    private String price;
    private String description;
    private double min;
    private double max;
}
