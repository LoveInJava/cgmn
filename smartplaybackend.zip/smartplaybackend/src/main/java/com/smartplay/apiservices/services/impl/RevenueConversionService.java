package com.smartplay.apiservices.services.impl;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartplay.apiservices.models.data.AdRevenue;
import com.smartplay.apiservices.models.data.Money;
import com.smartplay.apiservices.models.data.SmartPlayMoney;
import com.smartplay.apiservices.models.data.UserSmartPlayMoney;
import com.smartplay.apiservices.models.enums.Currency;
import com.smartplay.apiservices.models.events.ResetTimerEvent;
import com.smartplay.apiservices.repository.interfaces.IUserAdRevenueRepository;
import com.smartplay.apiservices.repository.interfaces.IUserSmartPlayMoneyRepository;
import com.smartplay.apiservices.services.interfaces.IConfigurationService;
import com.smartplay.apiservices.services.interfaces.IRevenueConversionService;

@Service
public class RevenueConversionService implements IRevenueConversionService {

    // private final IInMemoryRepository<SmartPlayMoney, UUID> smartplayMoneyRepository;
    // private final IInMemoryRepository<UserSmartPlayGamePoint, String> gamepointRepository;

    // private final IAdRevenueService adRevenueService;
    private final IUserAdRevenueRepository userAdRevenueRepository;
    private final IConfigurationService configurationService;
    private final IUserSmartPlayMoneyRepository userSmartplayMoneyRepository;

    public RevenueConversionService(
        // @Autowired IInMemoryRepository<SmartPlayMoney, UUID> smartplayMoneyRepository,
        // @Autowired IInMemoryRepository<UserSmartPlayGamePoint, String> gamepointRepository,
        // @Autowired IAdRevenueService adRevenueService,
        @Autowired IUserAdRevenueRepository userAdRevenueRepository,
        @Autowired IConfigurationService configurationService,
        @Autowired IUserSmartPlayMoneyRepository smartplayMoneyRepository
        ) {

        // this.smartplayMoneyRepository = smartplayMoneyRepository;
        // this.gamepointRepository = gamepointRepository;
        // this.adRevenueService = adRevenueService;
        this.userAdRevenueRepository = userAdRevenueRepository;
        this.configurationService = configurationService;
        this.userSmartplayMoneyRepository = smartplayMoneyRepository;

    }

    @Override
    public void convertRevenueToMoney(ResetTimerEvent event) {

        String lpaId = event.getLpaId();

        // step1: get all revenue accumulated
        // step2: add all accumulated revenue
        // step3: get multiplier from configuration service
        // step4: convert revenue to money by multiplying with multiplier with applying currency conversion
        // step5: save money to smartplayMoneyRepository
        // step6: clear all revenue records
        
        var userAdRevenue = userAdRevenueRepository.findById(lpaId).orElse(null);
        if(userAdRevenue == null){
            return;
        }

        // assuming we will get all amounts in USD
        BigDecimal totalRevenue = userAdRevenue.getRecords().stream()
        .map(AdRevenue::getRevenue)
        .reduce(BigDecimal.ZERO, BigDecimal::add); 

        BigDecimal multiplier = configurationService.getMultiplier();
        BigDecimal convertedMoney = totalRevenue.multiply(multiplier);

        UserSmartPlayMoney userSmartPlayMoney = userSmartplayMoneyRepository.findById(lpaId).orElse(UserSmartPlayMoney.builder().lpaId(lpaId).build());

        BigDecimal conversionMultiplier = configurationService.getCurrencyConversionRate(Currency.USD, Currency.INR);
        Money convertedMoneyInINR = Money.builder().amount(convertedMoney.multiply(conversionMultiplier)).currency(Currency.INR).build();

        userSmartPlayMoney.getRecords().add(SmartPlayMoney.builder().money(convertedMoneyInINR).timerId(event.getTimerId()) .startTime(event.getStartTime()).endTime(event.getEndTime()).build());

        userSmartplayMoneyRepository.save(userSmartPlayMoney);

        userAdRevenue.getRecords().clear();
        userAdRevenueRepository.save(userAdRevenue);
    }

}
