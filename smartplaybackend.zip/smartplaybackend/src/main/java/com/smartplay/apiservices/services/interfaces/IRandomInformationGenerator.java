package com.smartplay.apiservices.services.interfaces;

public interface IRandomInformationGenerator {

    String generateVerificationCode();

}
