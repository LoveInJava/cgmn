package com.smartplay.apiservices.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class InMemoryConfiguration {

    // @Bean
    // public IInMemoryRepository<PurchasedVoucher,String> getPurchasedVoucherRepository(){
    //     return new InMemoryRepository<>();
    // }

    // @Bean
    // public IInMemoryRepository<VoucherProduct,String> getVoucherProductRepository(){
    //     return new InMemoryRepository<>();
    // }

}
