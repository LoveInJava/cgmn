package com.smartplay.apiservices.services.interfaces;

import java.util.List;

import com.smartplay.apiservices.models.data.PinelabPurchasedVoucher;
import com.smartplay.apiservices.models.request.VoucherOrderRequest;
import com.smartplay.apiservices.models.response.PurchasedVoucher;

public interface IVoucherService {
    List<PurchasedVoucher> getPurchasedVoucherByLpaId(String lpaId);

    PinelabPurchasedVoucher orderVoucher(VoucherOrderRequest orderRequest, String lpaId, String deviceId);
}
