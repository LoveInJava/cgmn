package com.smartplay.apiservices.services.integration.payments.pinelabs.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class HandlingCharges {
    private String amount;
    private String label;
}
