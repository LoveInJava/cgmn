package com.smartplay.apiservices.models.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@SuperBuilder
@Data
@NoArgsConstructor
public class Points {

	private Integer actual;

	private Integer bonus;

	private Integer welcomebonus;

	private Integer target;

	private Integer bonusTargetPoints;
}
