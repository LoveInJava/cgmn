package com.smartplay.apiservices.services.integration.payments.pinelabs.models;

import java.util.ArrayList;
import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverted;
import com.smartplay.apiservices.tools.converters.RedemptionTermListConverter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Cpg {
    private Barcode barcode;

    @Builder.Default
    @DynamoDBTypeConverted(converter = RedemptionTermListConverter.class)
    private List<RedemptionTerm> redemptionTerms = new ArrayList<>();
}
