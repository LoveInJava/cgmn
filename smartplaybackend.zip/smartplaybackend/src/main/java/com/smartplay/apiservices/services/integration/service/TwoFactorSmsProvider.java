package com.smartplay.apiservices.services.integration.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.smartplay.apiservices.services.integration.model.OtpResponse;


@FeignClient(name = "2Factor.in",url = "${smsprovider.provider-2Factor.url}")
public interface TwoFactorSmsProvider {
    @GetMapping(path = "SMS/{mobileNumber}/{otp}/{template}",consumes = "application/json")
    ResponseEntity<OtpResponse> sendOtp(@PathVariable("mobileNumber") String mobileNumber, @PathVariable("otp") String otp, @PathVariable("template") String template);
}
