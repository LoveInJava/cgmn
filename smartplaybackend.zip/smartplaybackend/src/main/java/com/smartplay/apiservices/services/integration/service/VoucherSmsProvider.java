package com.smartplay.apiservices.services.integration.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.smartplay.apiservices.services.integration.model.OtpResponse;

@FeignClient(name = "voucherSmsProvider.in", url = "${smsprovider.provider-voucher.url}")
public interface VoucherSmsProvider {

    @PostMapping
    ResponseEntity<OtpResponse> sendSms(
            @RequestParam("module") String module,
            @RequestParam("apikey") String apiKey,
            @RequestParam("to") String to,
            @RequestParam("from") String from,
            @RequestParam("msg") String msg,
            @RequestParam("ctid") String ctid);

}
