package com.smartplay.apiservices.services.impl;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartplay.apiservices.models.data.PinelabsProduct;
import com.smartplay.apiservices.repository.interfaces.IPinelabsProductRepository;
import com.smartplay.apiservices.services.integration.payments.pinelabs.interfaces.IPinelabsApiService;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.CategoryResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.ProductResponse;
import com.smartplay.apiservices.services.interfaces.IPinelabsProductsSyncService;
import com.smartplay.apiservices.tools.StreamUtil;

@Service
public class PinelabsProductsSyncService implements IPinelabsProductsSyncService{

    private final IPinelabsApiService pinelabsApiService;
    private final IPinelabsProductRepository pinelabsProductRepository;

    public PinelabsProductsSyncService(
            @Autowired IPinelabsApiService productService,
            @Autowired IPinelabsProductRepository pinelabsProductRepository) {
        this.pinelabsApiService = productService;
        this.pinelabsProductRepository = pinelabsProductRepository;
    }

    @Override
    public void initiateSync() {
        
        this.clear();

        CategoryResponse category = pinelabsApiService.getCategory();
        
        var productByCategoryResponse= pinelabsApiService.getProductByCategoryId(category.getId());
        if(productByCategoryResponse.getProductsCount()<=0){
            return;
        }

        List<String> productSkuList = productByCategoryResponse.getProducts().stream().map(t->t.getSku()).toList();
        
        List<String> failedProductSkuList =  new CopyOnWriteArrayList<>();
        List<String> successProductSkuList = new CopyOnWriteArrayList<>();

        productSkuList.parallelStream().forEach(productSku->{
            try{
            ProductResponse product = pinelabsApiService.getProductBySku(productSku);
            var pinelabsProduct = PinelabsProduct.builder()
                .id(product.getSku())
                .sku(product.getSku())
                .categoryId(category.getId())
                .productDetails(product)
                .build();
            pinelabsProductRepository.save(pinelabsProduct);
            successProductSkuList.add(productSku);
            }catch(Exception e){
            failedProductSkuList.add(productSku);
            e.printStackTrace();
            }
        });

        System.out.println("=====================================================================================");
        System.out.println("Error in fetching with product sku's: " + failedProductSkuList);
        System.out.println("=====================================================================================");
        System.out.println("Success in fetching with product sku's: " + successProductSkuList);
        System.out.println("=====================================================================================");
    }

    @Override
    public void clear() {
        pinelabsProductRepository.deleteAll();
    }

    @Override
    public List<PinelabsProduct> getAll() {

        List<PinelabsProduct> list = StreamUtil.stream(pinelabsProductRepository.findAll()).toList();
        //if list empty then initiate sync
        if(list.isEmpty()){
            initiateSync();
        }
        list = StreamUtil.stream(pinelabsProductRepository.findAll()).toList();
        return list;
        //StreamUtil.stream(pinelabsProductRepository.findAll()).toList();
    }

}
