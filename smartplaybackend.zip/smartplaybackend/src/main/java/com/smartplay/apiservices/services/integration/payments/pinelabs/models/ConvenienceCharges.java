package com.smartplay.apiservices.services.integration.payments.pinelabs.models;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
class ConvenienceCharges {
    private String minAmount;
    private String maxAmount;

    @Builder.Default
    private List<ConvenienceChargeRange> convenience_charge_range = new ArrayList<>();
}
