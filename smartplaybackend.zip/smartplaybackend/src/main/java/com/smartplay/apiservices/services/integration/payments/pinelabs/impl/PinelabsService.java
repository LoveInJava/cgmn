package com.smartplay.apiservices.services.integration.payments.pinelabs.impl;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import com.smartplay.apiservices.services.integration.payments.pinelabs.models.*;
import com.smartplay.apiservices.tools.utils.DecryptUtilAES;
import com.smartplay.apiservices.tools.utils.Encryptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartplay.apiservices.models.data.LpaUser;
import com.smartplay.apiservices.models.data.PinelabPurchasedVoucher;
import com.smartplay.apiservices.models.data.PurchasedVoucher;
import com.smartplay.apiservices.models.enums.Currency;
import com.smartplay.apiservices.repository.interfaces.IPurchasedVoucherRepository;
import com.smartplay.apiservices.services.integration.payments.pinelabs.interfaces.IPinelabsApiService;
import com.smartplay.apiservices.services.integration.payments.pinelabs.interfaces.ProductClient;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.response.OrderResponse;
import com.smartplay.apiservices.services.interfaces.IConfigurationService;
import com.smartplay.apiservices.services.interfaces.IEmailService;
import com.smartplay.apiservices.services.interfaces.ISmsService;
import com.smartplay.apiservices.services.interfaces.ITemplateService;
import com.smartplay.apiservices.services.interfaces.IUserRegistrationService;
import com.smartplay.apiservices.services.interfaces.IVoucherSmsService;

import lombok.SneakyThrows;

@Service
public class PinelabsService implements IPinelabsApiService {
    private final ProductClient productClient;
    private final IConfigurationService configurationService;
    private final IPurchasedVoucherRepository pinelabPurchasedVoucherRepository;
    private final ObjectMapper objectMapper;
    private final IUserRegistrationService userRegistrationService;
    private final ISmsService smsService;
    private final IVoucherSmsService voucherSmsService;
    private final IEmailService emailService;
    private final ITemplateService templateService;

    public static final String INITIATING_ORDER = "INITIATING ORDER";
    public static final String SUCCESS = "SUCCESS";
    public static final String FAILED = "FAILED";

    public PinelabsService(
            @Autowired IUserRegistrationService userRegistrationService,
            @Autowired ISmsService smsService,
            @Autowired IVoucherSmsService voucherSmsService,
            @Autowired ProductClient productClient,
            @Autowired IConfigurationService configurationService,
            @Autowired IPurchasedVoucherRepository pinelabPurchasedVoucherRepository,
            @Autowired ObjectMapper objectMapper,
            @Autowired IEmailService emailService,
            @Autowired ITemplateService templateService) {
        this.userRegistrationService = userRegistrationService;
        this.smsService = smsService;
        this.voucherSmsService = voucherSmsService;
        this.productClient = productClient;
        this.configurationService = configurationService;
        this.pinelabPurchasedVoucherRepository = pinelabPurchasedVoucherRepository;
        this.objectMapper = objectMapper;
        this.emailService = emailService;
        this.templateService = templateService;
    }

    @Override
    public ProductListResponse getProductByCategoryId(String categoryId) {
        return productClient.getProductByCategoryId(categoryId);
    }

    @Override
    public ProductResponse getProductBySku(String productSku) {
        return productClient.getProductBySku(productSku);
    }

    @Override
    public CategoryResponse getCategory() {
        return productClient.getCategories();
    }

    private String getReferenceNum(){
        return "RUPLAY_" + UUID.randomUUID().toString().substring(0, 13).replace("-","");
    }
    @Override
    public OrderResponse placeOrder(String lpaId, String voucherName, String productSku, int price, int qty, String purchaserEmailId) {

        String referenceNumber = getReferenceNum();
        OrderRequest orderRequest = new OrderRequest();
        String firstname = configurationService.getBillerFirstname();
        String email = configurationService.getBillerEmail();
        String phoneno = configurationService.getBillerPhoneNumber();
        String country = configurationService.getBillerCountry();

        Address address = Address.builder().firstname(firstname).email(email).country(country).telephone(phoneno).build();
        Billing billing = Billing.builder().firstname(firstname).email(email).country(country).telephone(phoneno).build();
        Payment payment = Payment.builder().amount(price).build();
        Product product = Product.builder().sku(productSku).price(price).qty(qty).currency("356").theme("").build();

        orderRequest.setAddress(address);
        orderRequest.setBilling(billing);
        orderRequest.setRefno(referenceNumber);
        orderRequest.getPayments().add(payment);
        orderRequest.getProducts().add(product);

        String requestString = serializeToJson(orderRequest);

        PurchasedVoucher purchasedVouchers = pinelabPurchasedVoucherRepository.findById(lpaId).orElse(
                PurchasedVoucher.builder()
                        .lpaId(lpaId)
                        .build());


        PinelabPurchasedVoucher voucher = PinelabPurchasedVoucher.builder()
                .id(UUID.randomUUID().toString())
                .lpaid(lpaId)
                .sku(productSku)
                .voucherName(voucherName)
                .amount(BigDecimal.valueOf(price))
                .referenceNumber(referenceNumber)
                .orderRequest(requestString)
                .timestamp(LocalDateTime.now())
                .status(PinelabsService.INITIATING_ORDER)
                .currency(Currency.INR.toString())
                .build();

        purchasedVouchers.getRecords().add(voucher);

        //step 1: save the order request
        CompletableFuture<Void> saveOrderRequest = CompletableFuture.runAsync(() ->
                pinelabPurchasedVoucherRepository.save(purchasedVouchers)
        );

        //step 2: call the product client
        CompletableFuture<OrderResponse> orderResponseFuture = CompletableFuture.supplyAsync(() -> {
                    return productClient.orderVoucher(orderRequest);
                }).orTimeout(10, TimeUnit.SECONDS) // Automatically trigger timeout after 10 seconds
                .exceptionally(ex -> {
                    System.out.println("Request timed out or encountered an error: " + ex.getMessage());
                    return null; // Return null to indicate timeout or error
                });

        //step 3: save the order response on completion of step 2
        CompletableFuture<OrderResponse> finalResponse = orderResponseFuture.thenCompose(response -> {
            if (response != null) {
                // If order was successful, save and return the response
                voucher.setOrderId(response.getOrderId());
                voucher.setOrderResponse(DecryptUtilAES.encrypt(serializeToJson(response), Encryptor.secretKey, Encryptor.salt));
                voucher.setStatus(PinelabsService.SUCCESS);
                pinelabPurchasedVoucherRepository.save(purchasedVouchers);
                return CompletableFuture.completedFuture(response); // Return immediately
            } else {
                // If response is null (timeout/error), call retryCheckOrderStatus
                return retryCheckOrderStatus(0, referenceNumber, voucher, purchasedVouchers);
            }
        });

        // Wait for both saveOrderRequest and finalResponse to complete
        CompletableFuture.allOf(saveOrderRequest, finalResponse).join();

        // Return the final result, or null if it failed
        return finalResponse.handle((result, ex) -> {
            if (ex != null) {
                voucher.setStatus(PinelabsService.FAILED); // Update the status as failed
                pinelabPurchasedVoucherRepository.save(purchasedVouchers); // Save the updated voucher
                return null; // Return null in case of an exception
            }
            return result; // Return the actual response if successful
        }).join();
    }


    private CompletableFuture<OrderResponse> retryCheckOrderStatus(int currentAttempt, String referenceNumber, PinelabPurchasedVoucher voucher, PurchasedVoucher purchasedVouchers) {
        final int maxRetries = 3;
        final long retryInterval = 40000; // 40 seconds in milliseconds
        AtomicBoolean activated = new AtomicBoolean(false); // To track if activateCardApi has been called

        return checkOrderStatus(referenceNumber)
                .thenCompose(statusResponse -> {
                    if ("Complete".equalsIgnoreCase(statusResponse.getStatus()) && !activated.get()) {
                        // Delay and then activate the card
                        return CompletableFuture.supplyAsync(() -> {
                            try {
                                Thread.sleep(10000); // Delay for 10 seconds
                            } catch (InterruptedException e) {
                                Thread.currentThread().interrupt();
                            }
                            activated.set(true);
                            return activateCardApi(statusResponse.getOrderId());
                        }).thenCompose(response -> response); // Flatten the nested CompletableFuture<OrderResponse>

                    } else if ("Processing".equalsIgnoreCase(statusResponse.getStatus()) && currentAttempt < maxRetries) {
                        // Wait and retry if the status is "Processing" and maxRetries not reached
                        return CompletableFuture.runAsync(() -> {
                            try {
                                Thread.sleep(retryInterval);
                            } catch (InterruptedException e) {
                                Thread.currentThread().interrupt();
                            }
                        }).thenCompose(v -> retryCheckOrderStatus(currentAttempt + 1, referenceNumber, voucher, purchasedVouchers)); // Retry the process

                    }
                    // Return a completed future with null if retries are exhausted or status is not Processing/Complete
                    return CompletableFuture.completedFuture(null);
                });
    }






    private CompletableFuture<OrderStatusResponse> checkOrderStatus(String orderId) {
        // Implement your status API call logic here
        // Return the response as OrderStatusResponse

        return CompletableFuture.supplyAsync(() -> {
            return productClient.getOrderStatus(orderId);
        });

    }

    private CompletableFuture<OrderResponse> activateCardApi(String orderId) {
        // Implement your Activated Cards API call logic here
        System.out.println("Called Activated Cards API for order ID: " + orderId);

        return CompletableFuture.supplyAsync(() -> {
            ActivatedCardsResponse act = productClient.getActivatedCards(orderId);
            OrderResponse orderResponse = new OrderResponse();
            orderResponse.setOrderId(act.getOrderId());
            orderResponse.setStatus(act.getStatus());
            return orderResponse;
        });
    }

//    private void sendEmail(OrderResponse orderResponse, String email) {
//        ProductResponse productResponse = getProductBySku(orderResponse.getCards().get(0).getSku());
//        String tnc = productResponse.getTnc().getLink();
//        String emailBody = templateService.renderVoucherEmailContent(orderResponse, tnc);
//        emailService.sendEmail(email, "Purchased LPA voucher", emailBody, true);
//    }

//    private void sendSMS(OrderResponse orderResponse, String phoneNumber) {
//        String message = templateService.renderVoucherSMSContent(orderResponse);
//        CompletableFuture.runAsync(() -> voucherSmsService.sendSms(phoneNumber, message));
//    }

    @SneakyThrows
    private String serializeToJson(Object object) {
        return objectMapper.writeValueAsString(object);
    }

}
