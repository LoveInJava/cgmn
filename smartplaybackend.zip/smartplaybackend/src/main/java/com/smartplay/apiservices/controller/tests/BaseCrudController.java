package com.smartplay.apiservices.controller.tests;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
public abstract class BaseCrudController<T, ID, R extends CrudRepository<T, ID>> {

    @Autowired
    protected R repository;

    @PostMapping
    @Tag(name = "DB CRUD CHECK", description = "API's for CRUD operations")
    public T create(@RequestBody T entity) {
        return repository.save(entity);
    }

    @GetMapping("/{id}")
    @Tag(name = "DB CRUD CHECK", description = "API's for CRUD operations")
    public T getById(@PathVariable ID id) {
        return repository.findById(id).orElse(null);
    }

    @GetMapping
    @Tag(name = "DB CRUD CHECK", description = "API's for CRUD operations")
    public Iterable<T> getAll() {
        return repository.findAll();
    }

    @DeleteMapping("/{id}")
    @Tag(name = "DB CRUD CHECK", description = "API's for CRUD operations")
    public void deleteById(@PathVariable ID id) {
        repository.deleteById(id);
    }
}