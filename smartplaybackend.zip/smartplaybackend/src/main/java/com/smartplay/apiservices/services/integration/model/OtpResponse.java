package com.smartplay.apiservices.services.integration.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OtpResponse {
    @JsonProperty(value = "Status")
    private String status;
    @JsonProperty(value = "Details")
    private String details;
}
