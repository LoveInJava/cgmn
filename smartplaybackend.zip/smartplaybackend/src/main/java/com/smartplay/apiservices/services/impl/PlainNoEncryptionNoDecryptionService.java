package com.smartplay.apiservices.services.impl;

import org.springframework.stereotype.Service;

import com.smartplay.apiservices.services.interfaces.IEncryptionDecryptionService;

@Service(value = PlainNoEncryptionNoDecryptionService.SERVICE_NAME)
public class PlainNoEncryptionNoDecryptionService implements IEncryptionDecryptionService {

    public static final String SERVICE_NAME = "plainEncryptionDecryptionService";

	 // Encrypts the given plain text using Base64 encoding
    @Override
	public String encrypt(String plainText) {
        return plainText;
    }

    // Decrypts the given Base64 encoded string to plain text
    @Override
	public String decrypt(String encryptedText) {
        return encryptedText;
    }
}
