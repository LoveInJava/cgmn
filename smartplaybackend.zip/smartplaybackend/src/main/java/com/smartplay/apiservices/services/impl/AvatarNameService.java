package com.smartplay.apiservices.services.impl;

import java.io.IOException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartplay.apiservices.services.interfaces.IAvatarNameService;
import com.smartplay.apiservices.services.interfaces.IResourceService;
import com.smartplay.apiservices.services.interfaces.IUserRegistrationService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AvatarNameService implements IAvatarNameService {

    private final List<String> adjectives;
    private final List<String> nouns;
    private final SecureRandom secureRandom;

    private final IUserRegistrationService userRegistrationService;
    private final IResourceService resourceService;

    public AvatarNameService(
            @Autowired IUserRegistrationService userRegistrationService,
            @Autowired IResourceService resourceService) {
        adjectives = new ArrayList<>();
        nouns = new ArrayList<>();
        secureRandom = new SecureRandom();

        this.userRegistrationService = userRegistrationService;
        this.resourceService = resourceService;
         // Populate the adjective and noun lists from resources
        try {
            // Populate the adjective and noun lists
            adjectives.addAll( this.resourceService.readLinesFromResource("adjectives.txt"));
            nouns.addAll( this.resourceService.readLinesFromResource("nouns.txt"));
        } catch (IOException e) {
            log.error("Error reading resources", e);
        }
    }

    @Override
    public String getAvatarName() {
        String adjective = getRandomElement(adjectives);
        String noun = getRandomElement(nouns);
        int suffix = secureRandom.nextInt(10000);
        return combineWords(adjective, noun).toLowerCase() + String.format("%04d", suffix);
    }

    public String getRandomElement(List<String> list) {
        int index = secureRandom.nextInt(list.size());
        return list.get(index);
    }

    public String combineWords(String adjective, String noun) {
        return adjective + noun;
    }

    @Override
    public String getUniqueAvatarNameDbVerified() {
        String avatarName = getAvatarName();
        while (userRegistrationService.exists(avatarName)){
            avatarName = getAvatarName();
        }
        return avatarName;
    }
}
