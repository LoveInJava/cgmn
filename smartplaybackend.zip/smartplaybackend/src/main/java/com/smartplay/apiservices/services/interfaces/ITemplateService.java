package com.smartplay.apiservices.services.interfaces;

import java.util.Map;

import com.smartplay.apiservices.services.integration.payments.pinelabs.models.response.OrderResponse;

public interface ITemplateService{
	String renderVerificationEmailContent( Map<String, Object> options) ;
	String renderVoucherEmailContent(OrderResponse orderResponse, String tnc);
	String renderVoucherSMSContent(OrderResponse orderResponse);
}
