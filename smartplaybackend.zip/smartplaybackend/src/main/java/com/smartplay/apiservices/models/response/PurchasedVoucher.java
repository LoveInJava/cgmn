package com.smartplay.apiservices.models.response;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.smartplay.apiservices.repository.interfaces.IIdentifiable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@SuperBuilder
@NoArgsConstructor
// @Data
public class PurchasedVoucher implements IIdentifiable<String>{

    private String id;
    private String lpaId;
    private String voucherName;
    private String sku;
    private LocalDateTime purchasedOn;
    private BigDecimal amount;
    private String currency;
    private String transactionId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLpaId() {
        return lpaId;
    }

    public void setLpaId(String lpaId) {
        this.lpaId = lpaId;
    }

    public LocalDateTime getPurchasedOn() {
        return purchasedOn;
    }

    public void setPurchasedOn(LocalDateTime purchasedOn) {
        this.purchasedOn = purchasedOn;
    }

    public String getVoucherName() {
        return voucherName;
    }

    public void setVoucherName(String voucherName) {
        this.voucherName = voucherName;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }
}
