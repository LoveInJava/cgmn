package com.smartplay.apiservices.services.integration.payments.pinelabs.models;

import java.util.ArrayList;
import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverted;
import com.smartplay.apiservices.tools.converters.StringListConverter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Price {
    private String price;
    private String type;
    private String min;
    private String max;
    @Builder.Default
    @DynamoDBTypeConverted(converter = StringListConverter.class)
    private List<String> denominations= new ArrayList<>();
    private Currency currency;
}
