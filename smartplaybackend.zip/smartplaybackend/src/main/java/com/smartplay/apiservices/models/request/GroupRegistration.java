package com.smartplay.apiservices.models.request;

import jakarta.validation.GroupSequence;

@GroupSequence({GroupMobileUsername.class, GroupEmailUsername.class})
public interface GroupRegistration {
    // group sequence interface
}
