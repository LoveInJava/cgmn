package com.smartplay.apiservices.services.helpers;

import java.util.UUID;

public class UUIDUtils {

    private UUIDUtils() {

    }

    public static String toLpaIdString(UUID uuid) {
        return uuid.toString().replace("-", "").toUpperCase();
    }
}
