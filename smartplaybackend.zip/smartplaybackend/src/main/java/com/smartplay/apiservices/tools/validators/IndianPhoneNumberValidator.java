package com.smartplay.apiservices.tools.validators;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

import com.smartplay.apiservices.models.validators.IndianPhoneNumber;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

@Component
public class IndianPhoneNumberValidator implements ConstraintValidator<IndianPhoneNumber, String> {

    private Pattern pattern;

    @Override
    public void initialize(IndianPhoneNumber annotation) {
        pattern = Pattern.compile(annotation.regex());
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value == null) {
            return true; // null values are considered valid
        }
        Matcher matcher = pattern.matcher(value);
        return matcher.matches();
    }
}
