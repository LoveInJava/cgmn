package com.smartplay.apiservices.services.interfaces;

public interface ISmsService {
    public void sendVerificationCode(String phoneNumber,String verificationCode);
}
