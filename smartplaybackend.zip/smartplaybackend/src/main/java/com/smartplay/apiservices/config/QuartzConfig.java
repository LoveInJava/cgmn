// package com.smartplay.apiservices.config;

// import java.util.Calendar;
// import java.util.Date;

// import org.quartz.JobDetail;
// import org.springframework.context.annotation.Bean;
// import org.springframework.context.annotation.Configuration;
// import org.springframework.scheduling.quartz.JobDetailFactoryBean;
// import org.springframework.scheduling.quartz.SimpleTriggerFactoryBean;

// import com.smartplay.apiservices.jobs.SyncJob;

// @Configuration
// public class QuartzConfig {

//     @Bean
//     public JobDetailFactoryBean jobDetail() {
//         JobDetailFactoryBean factoryBean = new JobDetailFactoryBean();
//         factoryBean.setJobClass(SyncJob.class);
//         factoryBean.setDescription("Invoke Sync Job service...");
//         factoryBean.setDurability(true);
//         return factoryBean;
//     }

//     @Bean
//     public SimpleTriggerFactoryBean trigger(JobDetail jobDetail) {
//         SimpleTriggerFactoryBean factoryBean = new SimpleTriggerFactoryBean();
//         factoryBean.setJobDetail(jobDetail);
//         factoryBean.setRepeatInterval(0); // No repeat
//         factoryBean.setRepeatCount(0); // No repeat
//         factoryBean.setStartTime(getFirstSundayOfNextMonth());
//         return factoryBean;
//     }

//     private Date getFirstSundayOfNextMonth() {
//         Calendar cal = Calendar.getInstance();
//         cal.add(Calendar.MONTH, 1);
//         cal.set(Calendar.DAY_OF_MONTH, 1);
//         while (cal.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
//             cal.add(Calendar.DAY_OF_MONTH, 1);
//         }
//         cal.set(Calendar.HOUR_OF_DAY, 2);
//         cal.set(Calendar.MINUTE, 0);
//         cal.set(Calendar.SECOND, 0);
//         return cal.getTime();
//     }
// }
