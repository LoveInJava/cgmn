package com.smartplay.apiservices.tools;

import java.util.Date;

import org.apache.commons.lang3.ObjectUtils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;

public class JwtUtil {

    private JwtUtil() {
        super();
    }
    public static Date getExpirationDate(String token) {
        try {
            DecodedJWT jwt = JWT.decode(token);
            return jwt.getExpiresAt();
        } catch (Exception e) {
            // Handle the exception here
            return new Date(0); // Return a time in the past
        }
    }

    public static boolean isTokenExpired(String token) {
        Date expirationDate = JwtUtil.getExpirationDate(token);
        return expirationDate.before(new Date());
    }

    public static boolean isJwtTokenInvalidOrExpired(String jwtToken) {
        return ObjectUtils.isEmpty(jwtToken) || (!ObjectUtils.isEmpty(jwtToken) && JwtUtil.isTokenExpired(jwtToken));
    }

}
