package com.smartplay.apiservices.services.integration.payments.pinelabs.models;

import java.util.ArrayList;
import java.util.List;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class OrderRequest {
    private Address address;
    private Billing billing;
    @Builder.Default
    private List<Payment> payments = new ArrayList<>();
    private String refno;

    @Builder.Default
    @Setter(AccessLevel.PRIVATE)
    private boolean syncOnly=true;

    @Builder.Default
    @Setter(AccessLevel.PRIVATE)
    private String deliveryMode = "API";

    @Builder.Default
    private List<Product> products = new ArrayList<>();
}
