package com.smartplay.apiservices.models.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@SuperBuilder
@NoArgsConstructor
public class SmartPoint{

	@Getter
	@Builder.Default
	private ReponseType type = ReponseType.SMARTPOINT;

	@Getter
	@Setter
	private SmartPointDetails details;

}
