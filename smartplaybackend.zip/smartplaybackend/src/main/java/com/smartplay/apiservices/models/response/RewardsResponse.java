package com.smartplay.apiservices.models.response;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RewardsResponse{

	@Getter
	@Builder.Default
	private ReponseType type = ReponseType.REWARDS;

	@Getter
	@Builder.Default
	private final List<RewardTransactionHistory> details = new ArrayList<>();

}
