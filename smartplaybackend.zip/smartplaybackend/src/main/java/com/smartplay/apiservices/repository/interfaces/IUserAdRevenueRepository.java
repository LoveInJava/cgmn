package com.smartplay.apiservices.repository.interfaces;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.smartplay.apiservices.models.data.UserAdRevenue;

@EnableScan
@Repository
public interface IUserAdRevenueRepository  extends CrudRepository<UserAdRevenue, String> {

}
