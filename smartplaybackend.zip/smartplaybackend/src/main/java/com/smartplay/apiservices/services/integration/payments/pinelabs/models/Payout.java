package com.smartplay.apiservices.services.integration.payments.pinelabs.models;
import java.util.ArrayList;
import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverted;
import com.smartplay.apiservices.tools.converters.PayoutValidationConverter;
import com.smartplay.apiservices.tools.converters.StringListConverter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Payout {
    private Boolean enabled;
    @Builder.Default
    @DynamoDBTypeConverted(converter = StringListConverter.class)
    private List<String> payment_methods = new ArrayList<>();
    @Builder.Default
    @DynamoDBTypeConverted(converter = StringListConverter.class)
    private List<String> account_types = new ArrayList<>();
    @Builder.Default
    @DynamoDBTypeConverted(converter = StringListConverter.class)
    private List<String> transaction_types = new ArrayList<>();
    private String maximum_beneficiaries;
    @DynamoDBTypeConverted(converter = PayoutValidationConverter.class)
    private PayoutValidation validation;
}
