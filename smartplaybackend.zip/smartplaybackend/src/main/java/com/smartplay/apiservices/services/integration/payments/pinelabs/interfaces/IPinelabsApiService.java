package com.smartplay.apiservices.services.integration.payments.pinelabs.interfaces;

import com.smartplay.apiservices.services.integration.payments.pinelabs.models.CategoryResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.ProductListResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.ProductResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.response.OrderResponse;

public interface IPinelabsApiService {

    ProductListResponse getProductByCategoryId(String categoryId);

    ProductResponse getProductBySku(String productSku);

    CategoryResponse getCategory();

    OrderResponse placeOrder(String lpaId,String voucherName, String productSku, int price, int qty, String email);

}
