package com.smartplay.apiservices.models.response;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@SuperBuilder
@NoArgsConstructor
@Data
public class VoucherResponse {

    @Builder.Default
    private List<Currency> currencies = new ArrayList<>();

    @Builder.Default
    private List<String> allTags = new ArrayList<>();

    @Builder.Default
    private List<Voucher> vouchers = new ArrayList<>();
}
