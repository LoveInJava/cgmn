package com.smartplay.apiservices.services.interfaces;

import java.util.List;
import com.smartplay.apiservices.models.request.GamePointRequest;

import jakarta.validation.Valid;

public interface IGamePointService {

    void updateGamePoint(@Valid GamePointRequest gamePointRequest);

    Integer getCollectiveGamePointsByLpaId(String lpaId);

    void resetGamePoints(String lpaId);

    void allocateBonusPoints(String lpaId, String deviceId);

    Integer getWelcomeBonusPoint(String lpaId);

    List<Integer> getAllTargetPoint();

    List<Integer> getAllBonusPoint();

    void convertWelcomeBonusPoint(Integer welcomeBonus, String lpaId);
}
