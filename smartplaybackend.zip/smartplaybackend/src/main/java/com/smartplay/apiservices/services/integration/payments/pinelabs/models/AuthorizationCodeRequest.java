package com.smartplay.apiservices.services.integration.payments.pinelabs.models;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class AuthorizationCodeRequest {
    // @Value("${qwikgifts.api.clientid}")
    private String clientId;
    // @Value("${qwikgifts.api.username}")
    private String username;
    // @Value("${qwikgifts.api.password}")
    private String password;
}