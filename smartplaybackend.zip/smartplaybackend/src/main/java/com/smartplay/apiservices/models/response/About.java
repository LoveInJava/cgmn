package com.smartplay.apiservices.models.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@SuperBuilder
@NoArgsConstructor
public class About{

	@Getter
	@Builder.Default
	private ReponseType type = ReponseType.ABOUT;

	@Getter
	@Setter
	private BannerInfo info;

}
