package com.smartplay.apiservices.models.data;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@NotNull
@EqualsAndHashCode(callSuper=false)
@DynamoDBTable(tableName = "PinelabsAuthToken")
public class PinelabsAuthToken {

    @DynamoDBHashKey(attributeName = "id")
    private String id;

    private String authToken;

}
