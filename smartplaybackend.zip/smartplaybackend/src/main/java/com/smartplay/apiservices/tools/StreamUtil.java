package com.smartplay.apiservices.tools;

import java.util.stream.Stream;
import java.util.stream.StreamSupport;

public class StreamUtil {
    private StreamUtil() {
        // private constructor to hide the implicit public one
    }

    public static <T> Stream<T> stream(Iterable<T> iterable) {
        if (iterable == null) {
            return Stream.empty();
        }
        return StreamSupport.stream(iterable.spliterator(), false);
    }
}
