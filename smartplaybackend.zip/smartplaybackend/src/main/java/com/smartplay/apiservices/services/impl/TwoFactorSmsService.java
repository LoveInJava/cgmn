package com.smartplay.apiservices.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.smartplay.apiservices.services.integration.service.TwoFactorSmsProvider;
import com.smartplay.apiservices.services.interfaces.ISmsService;

@Service(TwoFactorSmsService.SERVICE_NAME)
public class TwoFactorSmsService implements ISmsService{

    public static final String SERVICE_NAME = "twoFactorSmsService";

    private final TwoFactorSmsProvider twoFactorSmsProvider;
    @Value("${smsprovider.provider-2Factor.template}")
    private String otpTemplate ;

    public TwoFactorSmsService(@Autowired TwoFactorSmsProvider twoFactorSmsProvider) {
        this.twoFactorSmsProvider = twoFactorSmsProvider;
    }

    @Override
    public void sendVerificationCode(String phoneNumber, String verificationCode) {
        System.out.println("Sending verification code to " + phoneNumber  + " with code " + verificationCode + " using template " + otpTemplate);
        twoFactorSmsProvider.sendOtp(phoneNumber, verificationCode, otpTemplate);
    }
}
