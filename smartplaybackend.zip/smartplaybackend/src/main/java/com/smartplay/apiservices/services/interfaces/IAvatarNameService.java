package com.smartplay.apiservices.services.interfaces;

public interface IAvatarNameService {
    String getAvatarName();

    String getUniqueAvatarNameDbVerified();
}
