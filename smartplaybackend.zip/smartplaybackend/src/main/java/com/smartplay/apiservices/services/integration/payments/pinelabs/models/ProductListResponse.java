package com.smartplay.apiservices.services.integration.payments.pinelabs.models;
import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductListResponse {

    private int id;
    private String name;
    private String url;
    private String description;
    private Images images;
    private int productsCount;
    @Builder.Default
    private List<ProductDetail> products = new ArrayList<>();
}