package com.smartplay.apiservices.services.interfaces;

import com.smartplay.apiservices.models.events.ResetTimerEvent;

public interface IRevenueConversionService {

    void convertRevenueToMoney(ResetTimerEvent event);

}
