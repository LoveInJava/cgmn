package com.smartplay.apiservices.models.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class SmartPointDetails {
	private Points points;
	private TimeRange time;
	private Cashout cashout;
}
