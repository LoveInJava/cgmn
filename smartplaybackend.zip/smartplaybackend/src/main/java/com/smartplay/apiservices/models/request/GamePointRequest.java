package com.smartplay.apiservices.models.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@NotNull
@Schema(description = "Details about the GamePointRequest")
public class GamePointRequest {

    public static final String GEO_COORDINATE_PATTERN ="^-?\\d{1,2}\\.\\d{1,6},-?\\d{1,3}\\.\\d{1,6}$";

    @Schema(description = "This property accepts a value that defines the range in which points to be allocated.")
    private GamePointCategory category;

    @Schema(description = "Current geocoordinates of the player. The format is latitude,longitude.", example = "40.7128,-74.0060", pattern = GEO_COORDINATE_PATTERN)
    @Pattern(regexp = GEO_COORDINATE_PATTERN)
    private String geocoordinates;

    /**
     * The ID of the game.
     */
    @Schema(description = "Predefined Identifier of the game.")
    private String gameId;

    /**
     * The ID of the LPA (Local Player Account).
     */
    @Schema(description = "lpaId of the player.")
    private String lpaId;

    /**
     * The ID of the request.
     */
    @Schema(description = "An unique identifier for every request in guid/uuid format.")
    private String requestId;

    @Schema(description = "Value of Points for Category.")
    private Integer points;
}
