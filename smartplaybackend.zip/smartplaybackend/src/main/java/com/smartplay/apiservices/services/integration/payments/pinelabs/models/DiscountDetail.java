package com.smartplay.apiservices.services.integration.payments.pinelabs.models;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DiscountDetail {
    private String type;
    private Double amount;
    private String max;
    private String desc;
}
