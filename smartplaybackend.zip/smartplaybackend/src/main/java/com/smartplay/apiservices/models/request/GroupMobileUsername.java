package com.smartplay.apiservices.models.request;

public interface GroupMobileUsername {
    // group marker interface
}
