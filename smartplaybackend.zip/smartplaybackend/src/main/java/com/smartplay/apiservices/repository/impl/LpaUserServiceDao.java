package com.smartplay.apiservices.repository.impl;

import java.util.List;
import java.util.UUID;
import java.util.function.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.smartplay.apiservices.models.data.LpaUser;
import com.smartplay.apiservices.repository.interfaces.ILpaUserRepository;
import com.smartplay.apiservices.tools.StreamUtil;

@Service
public class LpaUserServiceDao{

    private final ILpaUserRepository lpaUserRepository;
    
    public LpaUserServiceDao(@Autowired ILpaUserRepository lpaUserRepository) {
        this.lpaUserRepository = lpaUserRepository;
    }

    public LpaUser findByPhoneNumber(String phoneNumber) {
        return StreamUtil.stream(lpaUserRepository.findAll())
        .filter(u -> u.getPhoneNumber() != null && u.getPhoneNumber().equals(phoneNumber))
        .findFirst()
        .orElse(null);
    }

    public LpaUser findByLpaId(String lpaId) {
        return this.findById( lpaId);
    }

    public LpaUser findById(String id) {
        return lpaUserRepository.findById( id).orElse(null);
    }

    @Transactional
    public LpaUser save(LpaUser user) {
        return lpaUserRepository.save(user);
    }

    public LpaUser findByDeviceId(String deviceId) {
        return StreamUtil.stream(lpaUserRepository.findAll())
            .filter(user -> user.getDeviceIds().contains(deviceId))
            .findFirst()
            .orElse(null);
    }

    public boolean isDeviceRegistered(String deviceId) {
        return StreamUtil.stream(lpaUserRepository.findAll())
            .anyMatch(user -> user.getDeviceIds().contains(deviceId));
    }

    public List<LpaUser> filter(Predicate<LpaUser> predicate) {
        return StreamUtil.stream(lpaUserRepository.findAll())
            .filter(predicate)
            .toList();
    }
}
