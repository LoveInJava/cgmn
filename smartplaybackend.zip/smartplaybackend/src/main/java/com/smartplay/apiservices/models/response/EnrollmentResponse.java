package com.smartplay.apiservices.models.response;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class EnrollmentResponse{

	@NotBlank
//	@ApiModelProperty(notes = "The unique identifier")
	private String lpaId;

}
