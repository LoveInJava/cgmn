package com.smartplay.apiservices.services.impl;

import java.security.SecureRandom;

import org.springframework.stereotype.Service;

import com.smartplay.apiservices.services.interfaces.IRandomInformationGenerator;

@Service
public class RandomInformationGeneratorService implements IRandomInformationGenerator {

    private final SecureRandom secureRandom = new SecureRandom();
    private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    private String generateRandomCode(int length) {
        StringBuilder codeBuilder = new StringBuilder();
        for (int i = 0; i < length; i++) {
            int randomIndex = secureRandom.nextInt(CHARACTERS.length());
            char randomChar = CHARACTERS.charAt(randomIndex);
            codeBuilder.append(randomChar);
        }
        return codeBuilder.toString();
    }

    @Override
    public String generateVerificationCode() {
        return generateRandomCode(6);
    }


}
