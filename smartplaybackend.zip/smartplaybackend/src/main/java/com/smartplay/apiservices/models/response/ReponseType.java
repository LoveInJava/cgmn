package com.smartplay.apiservices.models.response;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ReponseType {
    ABOUT("about"),
    FAQ("faq"),
    NEWS("news"),
    GAMES("games"),
    REWARDS("rewards"),
    PRIVACYPOLICY("privacypolicy"),
    SMARTPOINT("smartpoint");

    public final String label;

    @Override
    public String toString() {
        return this.label;
    }
}
