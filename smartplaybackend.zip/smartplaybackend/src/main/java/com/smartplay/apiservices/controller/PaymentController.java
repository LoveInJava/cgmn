package com.smartplay.apiservices.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartplay.apiservices.models.data.PinelabPurchasedVoucher;
import com.smartplay.apiservices.models.request.VoucherOrderRequest;
import com.smartplay.apiservices.models.response.PurchasedVoucherResponse;
import com.smartplay.apiservices.models.response.VoucherResponse;
import com.smartplay.apiservices.services.interfaces.IMapper;
import com.smartplay.apiservices.services.interfaces.IPinelabsProductsSyncService;
import com.smartplay.apiservices.services.interfaces.IVoucherService;
import com.smartplay.apiservices.tools.VerifyHeaderToParamPayload;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1")
@Tag(name = "Pinelabs", description = "payments apis")
public class PaymentController {

        private final IVoucherService voucherService;
        private final IMapper mapper;
        private final IPinelabsProductsSyncService pineLabsProductsSyncService;
        // private final IPinelabTokenService pinelabTokenService;

        public PaymentController(
                        @Autowired IVoucherService voucherService,
                        @Autowired IMapper mapper,
                        @Autowired IPinelabsProductsSyncService pineLabsProductsSyncService
                        // ,@Autowired IPinelabTokenService pinelabTokenService
                        ) {
                this.voucherService = voucherService;
                this.mapper = mapper;
                this.pineLabsProductsSyncService = pineLabsProductsSyncService;
                // this.pinelabTokenService = pinelabTokenService;
        }

        @PostMapping(value = "/payment/voucher/{device-id}/{lpaId}/", produces = MediaType.APPLICATION_JSON_VALUE)
        @Operation(summary = "Vouchers")
        @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Vouchers POST api", content = {
                        @Content(mediaType = "application/json", schema = @Schema(implementation = VoucherResponse.class)) }),
                        @ApiResponse(responseCode = "400", description = "Internal server error", content = {
                                @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class)) }) })
        @VerifyHeaderToParamPayload(headerDeviceId = "device-id", paramDeviceId = "device-id")
        public ResponseEntity<PinelabPurchasedVoucher> postPayment(
                        @Parameter(description = "Encrypted device ID GAID( google)/IDFA (Apple)") @RequestHeader("device-id") String headerDeviceId,
                        @Parameter(description = "Encrypted device ID GAID( google)/IDFA (Apple)") @PathVariable("device-id") String paramDeviceId,
                        @Parameter(description = "Lpa Id") @PathVariable("lpaId") String lpaId,
                        @RequestBody @Valid VoucherOrderRequest voucherOrderRequest) {

                var value = voucherOrderRequest.getDenomination();

                // if (value >= 1000)
                //         throw new InvalidDenominationException("Denomination should be less than or equal to 1000");

               PinelabPurchasedVoucher  purchasedVoucher = voucherService.orderVoucher(voucherOrderRequest, lpaId, headerDeviceId);

                return ResponseEntity.ok(purchasedVoucher);
        }

        @GetMapping(value = "/payment/voucher/{device-id}/{lpaId}/", produces = MediaType.APPLICATION_JSON_VALUE)
        @Operation(summary = "Vouchers")
        @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Vouchers GET api", content = {
                        @Content(mediaType = "application/json", schema = @Schema(implementation = VoucherResponse.class)) }),
                        @ApiResponse(responseCode = "400", description = "Internal server error", content = {
                                        @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class)) }) })
        @VerifyHeaderToParamPayload(headerDeviceId = "device-id", paramDeviceId = "device-id")
        public ResponseEntity<VoucherResponse> getPayment(
                        @Parameter(description = "Encrypted device ID GAID( google)/IDFA (Apple)") @RequestHeader("device-id") String headerDeviceId,
                        @Parameter(description = "Device Id") @PathVariable("device-id") String paramDeviceId,
                        @Parameter(description = "Lpa Id") @PathVariable("lpaId") String lpaId) {

                var vouchers = mapper.mapPinelabsProductToVoucherResponse(pineLabsProductsSyncService.getAll());
                return ResponseEntity.ok(vouchers);
        }

        @GetMapping(value = "/payment/voucher/purchase-history/{device-id}/{lpaId}/", produces = MediaType.APPLICATION_JSON_VALUE)
        @Operation(summary = "Purchased voucher history")
        @ApiResponses(value = {
                        @ApiResponse(responseCode = "200", description = "smartpoints response successful", content = {
                                        @Content(mediaType = "application/json", schema = @Schema(type = "array", implementation = PurchasedVoucherResponse.class)) }),
                        @ApiResponse(responseCode = "400", description = "Internal server error", content = {
                                        @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class)) }) })
        @VerifyHeaderToParamPayload(headerDeviceId = "device-id", paramDeviceId = "device-id")
        public ResponseEntity<List<PurchasedVoucherResponse>> getVoucherPurchaseHistory(
                        @Parameter(description = "Encrypted device ID GAID( google)/IDFA (Apple)") @RequestHeader("device-id") String headerDeviceId,
                        @Parameter(description = "Device Id") @PathVariable("device-id") String paramDeviceId,
                        @Parameter(description = "Lpa Id") @PathVariable("lpaId") String lpaId) {

                                // pinelabTokenService.refreshToken();
                var purchasedVouchers = voucherService.getPurchasedVoucherByLpaId(lpaId);
                var purchaseHistory = mapper.map(purchasedVouchers);
                return ResponseEntity.ok(purchaseHistory);
        }
}
