package com.smartplay.apiservices.services.interfaces;

public interface IEmailService {
	void sendEmail(String email, String subject,String body, Boolean isHtml);
}