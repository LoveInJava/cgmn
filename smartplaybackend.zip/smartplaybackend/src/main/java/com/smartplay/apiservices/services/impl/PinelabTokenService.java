package com.smartplay.apiservices.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartplay.apiservices.config.PinelabSettingConfiguration;
import com.smartplay.apiservices.models.data.PinelabsAuthToken;
import com.smartplay.apiservices.repository.interfaces.IPinelabTokenRepository;
import com.smartplay.apiservices.services.integration.payments.pinelabs.interfaces.OAuth2Client;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.AuthorizationCodeRequest;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.AuthorizationCodeResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.BearerTokenRequest;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.BearerTokenResponse;
import com.smartplay.apiservices.services.interfaces.IPinelabTokenService;
import com.smartplay.apiservices.tools.JwtUtil;

@Service
public class PinelabTokenService implements IPinelabTokenService {

    private static final String TOKEN_KEY = "active-token-key-001";

    private final IPinelabTokenRepository tokenRepository;
    private final OAuth2Client oauth2Client;
    private final PinelabSettingConfiguration pinelabSettingConfiguration;

    public PinelabTokenService(
        @Autowired IPinelabTokenRepository tokenRepository,
        @Autowired OAuth2Client oauth2Client,
        @Autowired PinelabSettingConfiguration pinelabSettingConfiguration) {
        this.tokenRepository =tokenRepository;
        this.oauth2Client = oauth2Client;
        this.pinelabSettingConfiguration = pinelabSettingConfiguration;
    }

    @Override
    public String getToken() {
        var jwtToken = this.retrieveToken();
        if (JwtUtil.isJwtTokenInvalidOrExpired(jwtToken)) {
            jwtToken =refreshToken();
        }
        return jwtToken;
    }

    private String retrieveToken() {
        return tokenRepository.findById(TOKEN_KEY).orElse(new PinelabsAuthToken()).getAuthToken();
    }

    @Override
    public String refreshToken() {
        String newtoken = this.generateNewJwtToken();
        return this.saveToken(newtoken);
    }

    private String saveToken(String newtoken) {
        PinelabsAuthToken token = PinelabsAuthToken.builder()
            .id(TOKEN_KEY)
            .authToken(newtoken)
            .build();
        var savedToken =tokenRepository.save(token);
        return savedToken.getAuthToken();
    }

    @Override
    public String getBearerTokenString() {
        return "Bearer " + this.getToken();
    }

    @Override
    public String generateNewJwtToken(){
        AuthorizationCodeRequest authCodeRequest = AuthorizationCodeRequest.builder()
            .clientId(pinelabSettingConfiguration.getClientId())
            .username(pinelabSettingConfiguration.getUsername())
            .password(pinelabSettingConfiguration.getPassword())
            .build();

        // Step 1: Get Authorization Code
        AuthorizationCodeResponse authCodeResponse = oauth2Client.getAuthorizationCode(authCodeRequest);

        // Step 2: Get Access Token
        BearerTokenRequest tokenRequest = BearerTokenRequest.builder()
            .clientId(pinelabSettingConfiguration.getClientId())
            .clientSecret(pinelabSettingConfiguration.getClientSecret())
            .authorizationCode(authCodeResponse.getAuthorizationCode())
            .build();
        BearerTokenResponse tokenResponse = oauth2Client.getAccessToken(tokenRequest);
        return tokenResponse.getToken();
    }

}
