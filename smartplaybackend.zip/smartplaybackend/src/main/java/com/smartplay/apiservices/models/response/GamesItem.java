package com.smartplay.apiservices.models.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class GamesItem {

	private String id;

	private BannerInfo info;

	private int order;

}
