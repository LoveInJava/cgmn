package com.smartplay.apiservices.models.data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverted;
import com.smartplay.apiservices.tools.converters.LocalDateTimeConverter;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class PinelabPurchasedVoucher {
    private String id;
    private String lpaid;
    private String orderId;
    private String sku;
    private BigDecimal amount;
    private String referenceNumber;
    private String orderRequest;
    private String orderResponse;
    @DynamoDBTypeConverted(converter = LocalDateTimeConverter.class)
    private LocalDateTime timestamp;
    private String status;
    private String currency;
    private String voucherName;
    private String validity;
}
