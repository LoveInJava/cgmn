package com.smartplay.apiservices.services.interfaces;

import java.time.LocalDateTime;

public interface ISystemService {
    LocalDateTime getCurrentDateTime();
}

