package com.smartplay.apiservices.services.impl;

import java.security.SecureRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartplay.apiservices.models.data.LpaUser;
import com.smartplay.apiservices.models.data.UserAdRevenue;
import com.smartplay.apiservices.models.request.MobileRegistrationRequest;
import com.smartplay.apiservices.repository.impl.LpaUserServiceDao;
import com.smartplay.apiservices.repository.impl.OtpService;
import com.smartplay.apiservices.services.interfaces.IUserRegistrationService;

@Service
public class UserRegistrationServiceImpl implements IUserRegistrationService {

    private final LpaUserServiceDao userDao;
    private final OtpService otpService;
    
    public UserRegistrationServiceImpl(@Autowired LpaUserServiceDao userDao,
                                        @Autowired OtpService otpRepository
                                        ) {
        this.userDao = userDao;
        this.otpService = otpRepository;
    }

    @Override
    public boolean isPhoneNumberValid(String phoneNumber) {
        // we can use a 3rd party provided to test if its a valid phone number
        Pattern pattern = Pattern.compile(MobileRegistrationRequest.MOBILE_REGEX);
        Matcher matcher = pattern.matcher(phoneNumber);
        return matcher.matches();
    }

    @Override
    public boolean isPhoneNumberRegistered(String phoneNumber) {
        return userDao.findByPhoneNumber(phoneNumber) != null;
    }

    @Override
    public boolean isPhoneNumberVerified(String phoneNumber) {
        LpaUser user = userDao.findByPhoneNumber(phoneNumber);
        if (user == null) {
            return false;
        }
        return user.isPhoneNumberVerified();
    }

    @Override
    public String getLpaId(String phoneNumber) {
        LpaUser user = userDao.findByPhoneNumber(phoneNumber);
        if (user == null) {
            return null;
        }
        return user.getLpaId();
    }

    @Override
    public String generateVerificationCode() {
        // Generate a random 6-digit verification code-OTP
        return String.format("%06d", new SecureRandom().nextInt(999999));
    }

    @Override
    public LpaUser saveRegistrationRequest(LpaUser user) {
        this.validateUser(user);
        return this.userDao.save(user);
    }

    private void validateUser(LpaUser user) {
        if (user == null) {
            throw new IllegalArgumentException("User is required");
        }
        if (ObjectUtils.isEmpty(user.getLpaId())) {
            throw new IllegalArgumentException("ID is required");
        }
    }

    @Override
    public boolean validateOtp(String phoneNumber, String verificationCode) {
        return otpService.validateOtp(phoneNumber, verificationCode);
    }

    @Override
    public LpaUser updateOtpVerificationStatus(String phoneNumber, String deviceId, boolean otpVerificationStatus) {
        LpaUser user = userDao.findByPhoneNumber(phoneNumber);

        if (ObjectUtils.isEmpty(user)) {
            user = userDao.findByDeviceId(deviceId);
            user.setPhoneNumber(phoneNumber);
        }

        user.setPhoneNumberVerified(otpVerificationStatus);
        userDao.save(user);
        return user;
    }

    @Override
    public boolean isDeviceRegistered(String deviceId) {
        return userDao.isDeviceRegistered(deviceId);
    }

    @Override
    public String getUsername(String phoneNumber) {
        LpaUser user = userDao.findByPhoneNumber(phoneNumber);
        if(user == null)
            return null;
        return user.getUsername();
    }

    @Override
    public LpaUser getByLpaId(String lpaId) {
        return userDao.findById(lpaId);
    }

    @Override
    public LpaUser getByLpaIdDeviceId(String lpaId, String deviceId) {
        return userDao.filter(user -> user.getLpaId().equals(lpaId) && user.getDeviceIds().contains(deviceId))
            .stream()
            .findFirst()
            .orElse(null);
    }

    @Override
    public LpaUser getByPhoneNumberDeviceId(String phoneNumber, String deviceId) {
        return userDao.filter(user -> phoneNumber.equals(user.getPhoneNumber()) && user.getDeviceIds().contains(deviceId))
            .stream()
            .findFirst()
            .orElse(null);
    }

    @Override
    public LpaUser getByDeviceId(String deviceId) {
        return userDao.filter(user -> user.getDeviceIds().contains(deviceId))
            .stream()
            .findFirst()
            .orElse(null);
    }

    @Override
    public LpaUser getByPhoneNumber(String phoneNumber) {
        return userDao.filter(user -> phoneNumber.equals(user.getPhoneNumber()))
            .stream()
            .findFirst()
            .orElse(null);
    }

    @Override
    public String getOtpByDeviceId(String deviceId) {
        var lpauser = this.getByDeviceId(deviceId);
        if(lpauser == null)
            return null;
        return otpService.getOtp(lpauser.getPhoneNumber());
    }

    @Override
    public boolean exists(String username) {
        var lpauser = userDao.filter(user -> username.equals(user.getUsername()))
            .stream()
            .findFirst()
            .orElse(null);
        return lpauser != null;
    }


}
