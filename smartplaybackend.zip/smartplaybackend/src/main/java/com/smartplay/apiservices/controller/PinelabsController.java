package com.smartplay.apiservices.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartplay.apiservices.models.data.PinelabsProduct;
import com.smartplay.apiservices.services.integration.payments.pinelabs.interfaces.IPinelabsApiService;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.CategoryResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.ProductListResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.ProductResponse;
import com.smartplay.apiservices.services.interfaces.IPinelabsProductsSyncService;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1/pinelabs")
@Hidden
@Tag(name = "Pinelabs", description = "Pinelabs apis")
@Slf4j
public class PinelabsController {

    private final IPinelabsApiService pinelabsService;
    private final IPinelabsProductsSyncService pineLabsProductsSyncService;

    public PinelabsController(
            @Autowired IPinelabsApiService productService,
            @Autowired IPinelabsProductsSyncService pineLabsProductsSyncService) {
        this.pinelabsService = productService;
        this.pineLabsProductsSyncService = pineLabsProductsSyncService;
    }

    @GetMapping(value="/product/{productSku}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ProductResponse getProduct(
            @PathVariable("productSku") String productSku) {
        return pinelabsService.getProductBySku(productSku);
    }

    @GetMapping(value="/category/{categoryId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ProductListResponse getProductByCategoryId(
            @PathVariable("categoryId") String categoryId) {
        return pinelabsService.getProductByCategoryId(categoryId);
    }

    @GetMapping(value="/categories/", produces = MediaType.APPLICATION_JSON_VALUE)
    public CategoryResponse getProductByCategoryId() {
        return pinelabsService.getCategory();
    }

    @GetMapping(value="/allproducts/", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<PinelabsProduct> getAllProducts() {
        return pineLabsProductsSyncService.getAll();
    }

    @GetMapping("/triggerproductSync/")
    public List<PinelabsProduct> triggerProductSync() {
        pineLabsProductsSyncService.initiateSync();
        return pineLabsProductsSyncService.getAll();
    }

    @GetMapping("/cleardata/")
    public void clearData() {
        pineLabsProductsSyncService.clear();
    }
}
