package com.smartplay.apiservices.models.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class RegistrationResponse {

	private String email;
	private String mobile;
	private String username;

	private boolean verified;

}
