package com.smartplay.apiservices.models.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.smartplay.apiservices.repository.interfaces.IIdentifiable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
// @Data
public class VoucherProduct implements IIdentifiable<String>, Serializable {
    private String id;
    private String providerName;
    private String providerSku;
    private String name;
    private String description;
    private String image;
    private String currencyID;
    private String tnc;
    private String tncUrl;

    @Builder.Default
    private List<String> tags = new ArrayList<>();

    @Builder.Default
    private List<Integer> denominations = new ArrayList<>();

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String getId() {
        return id;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public String getProviderSku() {
        return providerSku;
    }

    public void setProviderSku(String providerSku) {
        this.providerSku = providerSku;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getCurrencyID() {
        return currencyID;
    }

    public void setCurrencyID(String currencyID) {
        this.currencyID = currencyID;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public List<Integer> getDenominations() {
        return denominations;
    }

    public void setDenominations(List<Integer> denominations) {
        this.denominations = denominations;
    }

    public String getTnc() {
        return tnc;
    }

    public void setTnc(String tnc) {
        this.tnc = tnc;
    }

    public String getTncUrl() {
        return tncUrl;
    }

    public void setTncUrl(String tncUrl) {
        this.tncUrl = tncUrl;
    }
}
