package com.smartplay.apiservices.services.interfaces;

import java.math.BigDecimal;
import com.smartplay.apiservices.models.enums.Currency;
import com.smartplay.apiservices.models.response.About;
import com.smartplay.apiservices.models.response.Faq;
import com.smartplay.apiservices.models.response.Games;
import com.smartplay.apiservices.models.response.News;
import com.smartplay.apiservices.models.response.PrivacyPolicy;

public interface IConfigurationService {
    int getDefaultBonusPoint();

    About getAbout();

    News getNews();

    Faq getFaq();

    PrivacyPolicy getPrivacyPolicy();

    Games getGames();

    long getTimerDuration();

    BigDecimal getMultiplier();

    BigDecimal getCurrencyConversionRate(Currency source, Currency to);

    String getBillerFirstname();

    String getBillerPhoneNumber();

    String getBillerCountry();

    String getBillerEmail();
}
