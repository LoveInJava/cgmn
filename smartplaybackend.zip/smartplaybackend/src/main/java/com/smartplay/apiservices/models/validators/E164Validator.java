package com.smartplay.apiservices.models.validators;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class E164Validator implements ConstraintValidator<E164, String> {

    private static final String E164_REGEX = "^\\+?[1-9]\\d{1,14}$";

    @Override
    public void initialize(E164 constraintAnnotation) {
        // Initialization code if needed
    }

    @Override
    public boolean isValid(String phoneNumber, ConstraintValidatorContext context) {
        if (phoneNumber == null) {
            return true; // Consider using @NotNull for null checks
        }
        return phoneNumber.matches(E164_REGEX);
    }
}
