package com.smartplay.apiservices.controller.tests;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartplay.apiservices.models.data.UserSmartPlayGamePoint;
import com.smartplay.apiservices.repository.interfaces.IUserSmartPlayGamePointRepository;

@RequestMapping("/api/db/gamepoint")
@RestController
public class GamePointCrudController extends BaseCrudController<UserSmartPlayGamePoint, String, IUserSmartPlayGamePointRepository> {

}
