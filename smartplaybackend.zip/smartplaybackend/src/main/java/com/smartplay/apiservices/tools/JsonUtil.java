package com.smartplay.apiservices.tools;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartplay.apiservices.config.TokenErrorResponse;

import feign.Response;
import feign.Util;

public class JsonUtil {
    private JsonUtil() {
    }

    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static TokenErrorResponse tryDeserializeToTokenErrorResponse(String json) {
        try {
            return objectMapper.readValue(json, TokenErrorResponse.class);
        } catch (JsonProcessingException e) {
            return null;
        }
    }

    public static TokenErrorResponse tryDeserializeToTokenErrorResponse(Response response) {
        if(response.body()==null) return null;
        
        byte[] bodyData;
        try {
            bodyData = Util.toByteArray(response.body().asInputStream());
            var responseBody = new String(bodyData, Util.UTF_8);
            
            return tryDeserializeToTokenErrorResponse(responseBody);
        } catch (IOException e) {
            return null;
        }
        
    }

}
