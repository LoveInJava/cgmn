package com.smartplay.apiservices.models.data;

import java.util.ArrayList;
import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@DynamoDBTable(tableName = "LpaUser")
public class LpaUser {

    @DynamoDBHashKey(attributeName = "lpaId")
    // @DynamoDBTypeConverted(converter = UUIDConverter.class)
    private String lpaId;

    // @Setter(AccessLevel.PRIVATE)
    @Builder.Default
    private String documentType = "lpaUser";
    
    private String phoneNumber;

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
        this.isPhoneNumberVerified = false;
    }

    private String username;
    private boolean isPhoneNumberVerified;

    @Builder.Default
    private List<String> deviceIds=new ArrayList<>();

    public void addDeviceId(String deviceId) {
        if (!deviceIds.isEmpty()) {
            throw new IllegalStateException("Cannot add more than one device ID at this time");
        }
        deviceIds.add(deviceId);
    }

    private String deviceToken;
}
