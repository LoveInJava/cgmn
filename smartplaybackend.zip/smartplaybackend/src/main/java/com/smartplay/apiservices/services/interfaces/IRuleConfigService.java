package com.smartplay.apiservices.services.interfaces;

import com.smartplay.apiservices.models.request.RuleConfigRequest;
import com.smartplay.apiservices.models.response.RuleConfigResponse;

/**
 * Interface @IRuleConfigService represents the contract for rule configuration.
 */
public interface IRuleConfigService {

     RuleConfigResponse saveRuleConfiguration(RuleConfigRequest ruleConfigRequest);
     RuleConfigResponse getsaveRuleConfigurationById(String ruleId);

}
