package com.smartplay.apiservices.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.smartplay.apiservices.services.impl.Base64EncryptionDecryptionService;
import com.smartplay.apiservices.services.impl.PlainNoEncryptionNoDecryptionService;
import com.smartplay.apiservices.services.interfaces.IEncryptionDecryptionService;

@Configuration
public class EncryptionConfiguration {

    @Bean
    @Primary
    public IEncryptionDecryptionService getInstance() {
        return new PlainNoEncryptionNoDecryptionService();
    }

    @Bean
    public IEncryptionDecryptionService getInstanceBaseEncruption(){
        return new Base64EncryptionDecryptionService();
    }
}
