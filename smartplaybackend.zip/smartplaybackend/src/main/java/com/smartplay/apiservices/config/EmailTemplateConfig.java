package com.smartplay.apiservices.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.ui.freemarker.FreeMarkerConfigurationFactory;

@Configuration
public class EmailTemplateConfig {
    @Primary
    @Bean
    public FreeMarkerConfigurationFactory factoryBean() {
        FreeMarkerConfigurationFactory freeMarkerConfigurationFactory = new FreeMarkerConfigurationFactory();
        freeMarkerConfigurationFactory.setTemplateLoaderPath("classpath:/templates");
        return freeMarkerConfigurationFactory;
    }
}
