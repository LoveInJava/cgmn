package com.smartplay.apiservices.models.response;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@SuperBuilder
@NoArgsConstructor
@Data
public class Product {
    private String id;
    private String name;
    private String description;
    private String image;
    private String currencyID;

    @Builder.Default
    private List<String> tags = new ArrayList<>();
    
    @Builder.Default
    private List<ProductOption> options = new ArrayList<>();
}
