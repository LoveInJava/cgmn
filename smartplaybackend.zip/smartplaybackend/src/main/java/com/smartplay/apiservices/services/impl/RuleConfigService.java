package com.smartplay.apiservices.services.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartplay.apiservices.models.data.RuleConfig;
import com.smartplay.apiservices.models.request.RuleConfigRequest;
import com.smartplay.apiservices.models.response.RuleConfigResponse;
import com.smartplay.apiservices.repository.interfaces.IRuleConfigRepository;
import com.smartplay.apiservices.services.interfaces.IMapper;
import com.smartplay.apiservices.services.interfaces.IRuleConfigService;

/**
 * Class @RuleConfigService represents a rule config service that handles
 * configuration rule.
 */
@Service
public class RuleConfigService implements IRuleConfigService {

    private final IRuleConfigRepository rulecCnfigRepository;
    private final IMapper mapper;

    public RuleConfigService(@Autowired IRuleConfigRepository rulecCnfigRepository,
            @Autowired IMapper mapper) {
        this.rulecCnfigRepository = rulecCnfigRepository;
        this.mapper = mapper;
    }

    @Override
    public RuleConfigResponse saveRuleConfiguration(RuleConfigRequest ruleConfigRequest) {

        RuleConfigResponse ruleConfigRes = null;
        if (ruleConfigRequest != null) {
            RuleConfig ruleConfig = mapper.mapToRuleConfig(ruleConfigRequest);
            ruleConfig = rulecCnfigRepository.save(ruleConfig);
            ruleConfigRes = mapper.mapToRuleConfigResponse(ruleConfig);
        }
        return ruleConfigRes;
    }

    @Override
    public RuleConfigResponse getsaveRuleConfigurationById(String ruleId) {
        RuleConfigResponse ruleConfigRes = null;
        if (!ruleId.isEmpty()) {

            Optional<RuleConfig> ruleConfig = rulecCnfigRepository.findById(ruleId);
            if (ruleConfig.isPresent()) {
                ruleConfigRes = mapper.mapToRuleConfigResponse(ruleConfig.get());
                
            }
        }
        return ruleConfigRes;
    }

}
