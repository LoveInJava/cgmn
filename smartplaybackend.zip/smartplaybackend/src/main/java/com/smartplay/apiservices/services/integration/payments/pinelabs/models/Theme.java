package com.smartplay.apiservices.services.integration.payments.pinelabs.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Theme {
    private String sku;
    private String price;
    private String image;
}
