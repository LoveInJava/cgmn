package com.smartplay.apiservices.tools.converters;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverter;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.Tnc;

public class TncConverter implements DynamoDBTypeConverter<String, Tnc> {
    private static final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public String convert(Tnc object) {
        try {
            return objectMapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error converting Tnc to String", e);
        }
    }

    @Override
    public Tnc unconvert(String object) {
        try {
            return objectMapper.readValue(object, Tnc.class);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error converting String to Tnc", e);
        }
    }
}