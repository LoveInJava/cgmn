package com.smartplay.apiservices.controller.tests;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.smartplay.apiservices.repository.interfaces.IBonusPointRepository;
import com.smartplay.apiservices.repository.interfaces.ILpaUserRepository;
import com.smartplay.apiservices.repository.interfaces.IPurchasedVoucherRepository;
import com.smartplay.apiservices.repository.interfaces.IUserAdRevenueRepository;
import com.smartplay.apiservices.repository.interfaces.IUserSmartPlayGamePointRepository;
import com.smartplay.apiservices.repository.interfaces.IUserSmartPlayMoneyRepository;
import com.smartplay.apiservices.repository.interfaces.IUserTimerRepository;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@Tag(name = "DB CRUD CHECK", description = "API's for CRUD operations")
@Slf4j
public class DeleteUserDataController {

    private final IUserAdRevenueRepository userAdRevenueRepository;
    private final IBonusPointRepository bonusPointRepository;
    private final IUserSmartPlayGamePointRepository userSmartPlayGamePointRepository;
    private final ILpaUserRepository lpaUserRepository;
    private final IUserTimerRepository userTimerRepository;
    private final IUserSmartPlayMoneyRepository userSmartPlayMoneyRepository;
    private final IPurchasedVoucherRepository purchasedVoucherRepository;

    public DeleteUserDataController(@Autowired IUserAdRevenueRepository userAdRevenueRepository,
            @Autowired IBonusPointRepository bonusPointRepository,
            @Autowired IUserSmartPlayGamePointRepository userSmartPlayGamePointRepository,
            @Autowired ILpaUserRepository lpaUserRepository,
            @Autowired IUserTimerRepository userTimerRepository,
            @Autowired IUserSmartPlayMoneyRepository userSmartPlayMoneyRepository,
            @Autowired IPurchasedVoucherRepository purchasedVoucherRepository) {
                
        this.userAdRevenueRepository = userAdRevenueRepository;
        this.bonusPointRepository = bonusPointRepository;
        this.userSmartPlayGamePointRepository = userSmartPlayGamePointRepository;
        this.lpaUserRepository = lpaUserRepository;
        this.userTimerRepository = userTimerRepository;
        this.userSmartPlayMoneyRepository = userSmartPlayMoneyRepository;
        this.purchasedVoucherRepository = purchasedVoucherRepository;
    }

    @DeleteMapping("/user/data/{id}")
    public ResponseEntity<Void> deleteById(@PathVariable String id) {
        log.info("LPAID : {}", id);

        if (userAdRevenueRepository.findById(id).isPresent()) {
            userAdRevenueRepository.deleteById(id);
        }
        if (bonusPointRepository.findById(id).isPresent()) {
            bonusPointRepository.deleteById(id);
        }
        if (userSmartPlayGamePointRepository.findById(id).isPresent()) {
            userSmartPlayGamePointRepository.deleteById(id);
        }
        if (lpaUserRepository.findById(id).isPresent()) {
            lpaUserRepository.deleteById(id);
        }
        if (userTimerRepository.findById(id).isPresent()) {
            userTimerRepository.deleteById(id);
        }
        if (userSmartPlayMoneyRepository.findById(id).isPresent()) {
            userSmartPlayMoneyRepository.deleteById(id);
        }
        if (purchasedVoucherRepository.findById(id).isPresent()) {
            purchasedVoucherRepository.deleteById(id);
        }
        return ResponseEntity.ok().build();
    }
}
