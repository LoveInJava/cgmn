package com.smartplay.apiservices.services.impl;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.smartplay.apiservices.models.data.PinelabPurchasedVoucher;
import com.smartplay.apiservices.models.data.PinelabsProduct;
import com.smartplay.apiservices.models.data.RuleConfig;
import com.smartplay.apiservices.models.data.VoucherProduct;
import com.smartplay.apiservices.models.request.RuleConfigRequest;
import com.smartplay.apiservices.models.response.Currency;
import com.smartplay.apiservices.models.response.PurchasedVoucher;
import com.smartplay.apiservices.models.response.PurchasedVoucherResponse;
import com.smartplay.apiservices.models.response.RuleConfigResponse;
import com.smartplay.apiservices.models.response.Voucher;
import com.smartplay.apiservices.models.response.VoucherResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.impl.PinelabsService;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.ProductResponse;
import com.smartplay.apiservices.services.interfaces.IMapper;
import com.smartplay.apiservices.services.mappers.PurchasedVoucherMapper;
import com.smartplay.apiservices.services.mappers.VoucherMapper;

@Service
public class MapperService implements IMapper{

    public PurchasedVoucherResponse map(PurchasedVoucher purchasedVoucher){
        return PurchasedVoucherMapper.INSTANCE.toResponse(purchasedVoucher);
    }

    @Override
    public List<PurchasedVoucherResponse> map(List<PurchasedVoucher> purchasedVoucherList) {
        return PurchasedVoucherMapper.INSTANCE.toResponseList(purchasedVoucherList);
    }

    @Override
    public Voucher map(VoucherProduct voucherProduct) {
        return VoucherMapper.INSTANCE.toVoucher(voucherProduct);
    }

    @Override
    public List<Voucher> mapToVouchers(List<VoucherProduct> voucherProductList) {
        return VoucherMapper.INSTANCE.toResponseList(voucherProductList);
    }

    // @Override
    // public PurchasedVoucher mapToPurchasedVoucher(VoucherOrderRequest orderRequest, String voucherName, String lpaId) {
    //     return PurchasedVoucher.builder().id( UUID.randomUUID().toString()).lpaId(lpaId).voucherName(voucherName).sku(orderRequest.getProductSKU()).amount(orderRequest.getDenomination()).build();
    // }

    @Override
    public VoucherResponse mapPinelabsProductToVoucherResponse(List<PinelabsProduct> pinelabsProducts) {
        VoucherResponse voucherResponse = new VoucherResponse();

        List<Voucher> vouchers = new ArrayList<>();
        // Map vouchers
        for (PinelabsProduct pinelabsProduct : pinelabsProducts) {
            Voucher voucher = mapToVoucher(pinelabsProduct.getProductDetails());
            vouchers.add(voucher);
        }

        voucherResponse.setVouchers(vouchers);

        // Map currencies
        List<Currency> currencies = new ArrayList<>();
        currencies.add(new Currency("1", "INR", "₹")); // Assuming 356 maps to INR
        voucherResponse.setCurrencies(currencies);

        // Map allTags (currently blank as per the mapping)
        List<String> allTags = new ArrayList<>();
        voucherResponse.setAllTags(allTags);

        return voucherResponse;
    }

    @Override
    public Voucher mapToVoucher(ProductResponse productDetails) {
        
        Voucher voucher = new Voucher();
        voucher.setSku(productDetails.getSku());
        voucher.setName(productDetails.getName());
        voucher.setDescription(productDetails.getDescription());
        voucher.setImage(productDetails.getImages().getThumbnail());
        voucher.setCurrencyID("INR");
        voucher.setTnc(productDetails.getTnc().getContent());
        voucher.setTncUrl(productDetails.getTnc().getLink());
        List<BigInteger> denominations = new ArrayList<>();
        for (String denomination : productDetails.getPrice().getDenominations()) {
            denominations.add(new BigInteger(denomination));
        }
        voucher.setDenominations(denominations);

        // Map tags (currently blank as per the mapping)
        List<String> tags = new ArrayList<>();
        voucher.setTags(tags);
        return voucher;

    }

    @Override
    public List<PurchasedVoucher> mapResponse(List<PinelabPurchasedVoucher> records) {
        
        List<PurchasedVoucher> responseList = new ArrayList<>();
        if(!ObjectUtils.isEmpty(records)){
            records.stream().filter(t -> PinelabsService.SUCCESS.equals(t.getStatus())) .forEach(r -> {
                PurchasedVoucher purchasedVoucher = PurchasedVoucher.builder()
                    .id(r.getId())
                    .lpaId(r.getLpaid())
                    .sku(r.getSku())
                    .amount(r.getAmount())
                    .transactionId(r.getReferenceNumber())
                    .purchasedOn(r.getTimestamp())
                    .voucherName(r.getVoucherName())
                    .build();
                responseList.add(purchasedVoucher);
            });
        }

        return responseList;

    }

    @Override
    public RuleConfig mapToRuleConfig(RuleConfigRequest ruleConfigRequest) {

        RuleConfig ruleConfig = new RuleConfig();
        ruleConfig.setId(ruleConfigRequest.getRuleId());
        ruleConfig.setRule(ruleConfigRequest.getRule());
        ruleConfig.setValue(ruleConfigRequest.getValue());
        return ruleConfig;
    }

    @Override
    public RuleConfigResponse mapToRuleConfigResponse(RuleConfig ruleConfig) {

        RuleConfigResponse ruleConfigResponse = new RuleConfigResponse();
        ruleConfigResponse.setId(ruleConfig.getId());
        ruleConfigResponse.setRule(ruleConfig.getRule());
        ruleConfigResponse.setValue(ruleConfig.getValue());
        return ruleConfigResponse;
    }

}
