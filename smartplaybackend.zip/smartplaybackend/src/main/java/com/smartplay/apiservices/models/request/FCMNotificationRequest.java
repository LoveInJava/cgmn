package com.smartplay.apiservices.models.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@NotNull
public class FCMNotificationRequest {

    @NotNull(message = "Title is required")
    @NotEmpty(message = "Title must not be empty")
    @JsonProperty("title")
    private String title;

    @NotNull(message = "Body is required")
    @NotEmpty(message = "Body must not be empty")
    @JsonProperty("body")
    private String body;

    @NotNull(message = "Topic is required")
    @NotEmpty(message = "Topic must not be empty")
    @JsonProperty("topic")
    private String topic;

    @NotNull(message = "Token is required")
    @NotEmpty(message = "Token must not be empty")
    @JsonProperty("token")
    private String token;

    @NotNull(message = "Channel id is required")
    @NotEmpty(message = "Channel id must not be empty")
    @JsonProperty("channel_id")
    private String channel_id;

    @NotNull(message = "Android Channel id is required For Android >= 8")
    @NotEmpty(message = "Android Channel id must not be empty")
    @JsonProperty("android_channel_id")
    private String android_channel_id;
}
