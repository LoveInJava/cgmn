package com.smartplay.apiservices.models.request;
import java.security.SecureRandom;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum GamePointCategory{
    CATEGORY1("Category1", 0,100),
    CATEGORY2("Category2",101,200),
    CATEGORY3("Category3",201,300),
    CATEGORY4("Category4",301,400),
    CATEGORY5("Category5",401,500),
    CATEGORY6("Category6",501,600),
    CATEGORY7("Category7",601,700),
    CATEGORY8("Category8",701,800),
    CATEGORY9("Category9",801,900),
    CATEGORY10("Category10",901,1000);

    public final String value;
    public final int min;
    @Getter
    public final int max;

    public int getRandomValue() {
        SecureRandom random = new SecureRandom();
        return random.nextInt((max - min) + 1) + min;
    }
}
