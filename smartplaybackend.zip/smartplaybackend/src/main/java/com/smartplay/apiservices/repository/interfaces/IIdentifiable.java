package com.smartplay.apiservices.repository.interfaces;

@SuppressWarnings("java:S119")
public interface IIdentifiable<Id> {
    Id getId();
}
