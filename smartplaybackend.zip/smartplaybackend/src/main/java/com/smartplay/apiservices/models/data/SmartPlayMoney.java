package com.smartplay.apiservices.models.data;

import java.time.LocalDateTime;
import java.util.UUID;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverted;
import com.smartplay.apiservices.tools.converters.LocalDateTimeConverter;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@NotNull
@EqualsAndHashCode(callSuper = false)
public class SmartPlayMoney {

    private Money money;
    
    private UUID timerId;
    
    @DynamoDBTypeConverted(converter = LocalDateTimeConverter.class)
    private LocalDateTime startTime;

    @DynamoDBTypeConverted(converter = LocalDateTimeConverter.class)
    private LocalDateTime endTime;

}