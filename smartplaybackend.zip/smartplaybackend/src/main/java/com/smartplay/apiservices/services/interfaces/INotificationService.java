package com.smartplay.apiservices.services.interfaces;

public interface INotificationService {
    <T> void publishEvent(T event);

    void sendSms(String phoneNumber,String message);

    void sendEmail(String emailAddress,String subject, String message);

    void sendVerificationCode(String phoneNumber, String verificationCode);

    void retrySendVerificationCode(String phoneNumber, String newVerificationCode);
}
