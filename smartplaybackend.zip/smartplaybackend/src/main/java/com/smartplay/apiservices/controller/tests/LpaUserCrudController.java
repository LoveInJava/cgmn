package com.smartplay.apiservices.controller.tests;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartplay.apiservices.models.data.LpaUser;
import com.smartplay.apiservices.repository.interfaces.ILpaUserRepository;

@RequestMapping("/api/db/lpauser")
@RestController
public class LpaUserCrudController extends BaseCrudController<LpaUser, String, ILpaUserRepository> {

}
