package com.smartplay.apiservices.services.impl;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.smartplay.apiservices.services.integration.payments.pinelabs.models.response.OrderResponse;
import com.smartplay.apiservices.services.interfaces.ITemplateService;
import com.smartplay.apiservices.tools.utils.DateUtils;

import freemarker.template.Configuration;
import freemarker.template.Template;
import lombok.SneakyThrows;

@Service
public class FreeMarkerTemplateService implements ITemplateService {
	
    private final Configuration configuration;
	
    public FreeMarkerTemplateService(@Autowired Configuration configuration) {
		this.configuration  =configuration;	
	}
	
    @SneakyThrows
	public String renderVerificationEmailContent( Map<String, Object> options) {
		Template template = configuration.getTemplate("verification-email.ftl");
        return FreeMarkerTemplateUtils.processTemplateIntoString(template, options);
	}

	@SneakyThrows
	public String renderVoucherEmailContent(OrderResponse orderResponse, String tnc) {
	var firstCard =  orderResponse.getCards().get(0);
	String redemptionUrl = firstCard !=null ? firstCard.getActivationUrl() : "";
	String voucherCode = firstCard !=null ? firstCard.getCardPin() : "";
	String cardId = firstCard !=null ? String.valueOf( firstCard.getCardNumber()) : "";
	String cardPin = firstCard !=null ? String.valueOf( firstCard.getCardPin()) : "";
	String amount = firstCard !=null ? firstCard.getAmount() :"";
	String expiry = firstCard !=null ? firstCard.getValidity() :"";

	Map<String, Object> options = new HashMap<>();
	options.put("redemptionurl", redemptionUrl);
	options.put("vouchercode", voucherCode);
	options.put("cardId", cardId);
	options.put("cardPin", cardPin);
	options.put("amount", amount);
	options.put("expiry", DateUtils.convertDate(DateUtils.yyyy_MM_dd_T_HH_mm_ssXXX, expiry, DateUtils.dd_MMM_yyyy));
	options.put("tnc", tnc);
		Template template = configuration.getTemplate("voucher-email.ftl");
        return FreeMarkerTemplateUtils.processTemplateIntoString(template, options);
	}

	@SneakyThrows
	public String renderVoucherSMSContent( OrderResponse orderResponse) {
	var firstCard =  orderResponse.getCards().get(0);
	String redemptionUrl = firstCard !=null ? firstCard.getActivationUrl() : "";
	String voucherCode = firstCard !=null ? firstCard.getCardPin() : "";
	String cardId = firstCard !=null ? String.valueOf( firstCard.getCardNumber()) : "";
	String amount = firstCard !=null ? firstCard.getAmount() :"";
	String expiry = firstCard !=null ? firstCard.getValidity() :"";

	Map<String, Object> options = new HashMap<>();
	options.put("vouchercode", voucherCode);
	//options.put("cardId", cardId);
	options.put("expiry", DateUtils.convertDate(DateUtils.yyyy_MM_dd_T_HH_mm_ssXXX, expiry, DateUtils.dd_MMM_yyyy));
	options.put("redemptionurl", "");

		Template template = configuration.getTemplate("voucher-sms.ftl");
        return FreeMarkerTemplateUtils.processTemplateIntoString(template, options);
	}
}