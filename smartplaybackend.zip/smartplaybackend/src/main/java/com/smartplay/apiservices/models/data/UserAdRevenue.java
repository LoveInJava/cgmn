package com.smartplay.apiservices.models.data;

import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverted;
import com.smartplay.apiservices.tools.converters.AdRevenueListConverter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@DynamoDBTable(tableName = "UserAdRevenue")
@Data
public class UserAdRevenue {

    @DynamoDBHashKey(attributeName = "lpaId")
    private String lpaId;

    @Builder.Default
    private String documentType = "userAdRevenue";

    @Builder.Default
    @DynamoDBTypeConverted(converter = AdRevenueListConverter.class)
    private List<AdRevenue> records =  new java.util.ArrayList<>();

}
