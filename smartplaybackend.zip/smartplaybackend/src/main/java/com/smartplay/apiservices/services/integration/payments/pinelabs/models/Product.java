package com.smartplay.apiservices.services.integration.payments.pinelabs.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class Product {
    private String sku;
    private int price;
    private int qty;
    private String currency;
    private String theme;
}
