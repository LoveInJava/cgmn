package com.smartplay.apiservices.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.smartplay.apiservices.services.integration.service.VoucherSmsProvider;
import com.smartplay.apiservices.services.interfaces.IVoucherSmsService;

@Service(VoucherSmsService.SERVICE_NAME)
public class VoucherSmsService implements IVoucherSmsService{

    public static final String SERVICE_NAME = "voucherSmsService";

    private final VoucherSmsProvider voucherSmsProvider;

    @Value("${smsprovider.provider-voucher.template}")
    private String voucherTemplate ;
    @Value("${smsprovider.provider-voucher.from}")
    private String senderId ;
    @Value("${smsprovider.provider-voucher.api_key}")
    private String apiKey ;
    @Value("${smsprovider.provider-voucher.module}")
    private String module ;

    public VoucherSmsService(@Autowired VoucherSmsProvider voucherSmsProvider) {
        this.voucherSmsProvider = voucherSmsProvider;
    }

    @Override
    public void sendSms(String phoneNumber, String message) {
        System.out.println("Sending Voucher Message to " + phoneNumber  + " with code " + message + " using template " + voucherTemplate);
        voucherSmsProvider.sendSms(module, apiKey, phoneNumber, senderId, message,voucherTemplate);
    }
}
