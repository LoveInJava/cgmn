package com.smartplay.apiservices.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartplay.apiservices.models.request.RevenueDetailsRequest;
import com.smartplay.apiservices.services.interfaces.IAdRevenueService;
import com.smartplay.apiservices.tools.VerifyHeaderToParamPayload;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1")
@Validated
@Tag(name = "mobile", description = "Api's for mobile devices")
public class AdRevenueController {

    private final IAdRevenueService adRevenueService;

    public AdRevenueController(@Autowired IAdRevenueService adRevenueService) {
        this.adRevenueService = adRevenueService;
    }

    @PostMapping(value="/adrevenue/{device-id}/{lpaId}", produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Api to record Revenue earned.", description = "Api to record Revenue earned.")
    @Tag(name = "game", description = "api's for regstered games")
    @VerifyHeaderToParamPayload(headerDeviceId = "device-id", paramDeviceId = "device-id")
    public ResponseEntity<Void> createRevenueDetails(
            @Parameter(description = "Encrypted device ID GAID( google)/IDFA (Apple)") @RequestHeader("device-id") String headerDeviceId,
            @Parameter(description = "Device id") @PathVariable("device-id") String paramDeviceId,
            @Parameter(description = "Lpa Id") @PathVariable("lpaId") String lpaId,
            @RequestBody @Valid RevenueDetailsRequest revenueDetailsRequest) {

        if(!revenueDetailsRequest.getLpaId().equals(lpaId) || !revenueDetailsRequest.getDeviceId().equals(paramDeviceId)) {
            return ResponseEntity.badRequest().build();
        }
        adRevenueService.save(revenueDetailsRequest);
        return ResponseEntity.ok().build();

    }

}
