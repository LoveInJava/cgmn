package com.smartplay.apiservices.models.data;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverted;
import com.smartplay.apiservices.tools.converters.LocalDateTimeConverter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SmartPoint implements Serializable{

    @DynamoDBTypeConverted(converter = LocalDateTimeConverter.class)
    private LocalDateTime actionDateTime;

    private String gameId;

    private String requestId;

    private int points;
}
