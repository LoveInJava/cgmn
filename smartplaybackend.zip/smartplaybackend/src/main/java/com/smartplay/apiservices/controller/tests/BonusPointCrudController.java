package com.smartplay.apiservices.controller.tests;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartplay.apiservices.models.data.BonusPoint;
import com.smartplay.apiservices.repository.interfaces.IBonusPointRepository;

@RequestMapping("/api/db/bonuspoint")
@RestController
public class BonusPointCrudController extends BaseCrudController<BonusPoint, String, IBonusPointRepository> {

}
