package com.smartplay.apiservices.config;

import java.io.IOException;

import feign.Logger;
import feign.Request;
import feign.Response;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CustomFeignLogger extends Logger {

    @Override
    protected void logRequest(String configKey, Level logLevel, Request request) {
        if (logLevel == Level.FULL) {
            log.debug("================= REQUEST BEGIN =================");
            log.debug(String.format("Feign request: %s %s", request.httpMethod(), request.url()));
            log.debug(String.format("Request headers: %s", request.headers()));
            if (request.body() != null) {
                log.debug(String.format("Request body: %s", new String(request.body())));
            }
            log.debug("================= REQUEST END =================");
        }
    }

    @Override
    protected Response logAndRebufferResponse(String configKey, Level logLevel, Response response, long elapsedTime)
            throws IOException {


        if (logLevel == Level.FULL) {
            log.debug("================= RESPONSE BEGIN =================");
            log.debug(String.format("Response: status %d    reason %s", response.status(), response.reason()));
            log.debug(String.format("Response headers: %s", response.headers()));
        }
        
        if(response.body()!=null){
            byte[] bodyData = response.body().asInputStream().readAllBytes();

            if (logLevel == Level.FULL) {
                log.debug("================= RESPONSE BEGIN =================");
    
                log.debug(String.format("Response body: %s", new String(bodyData)));
                log.debug("================= RESPONSE END =================");
            }
            return response.toBuilder().body(bodyData).build();
        }
        return response;
    }

    @Override
    protected void log(String configKey, String format, Object... args) {
        log.debug(configKey, format, args);
    }
}