package com.smartplay.apiservices.exceptions;

// @ResponseStatus(value=HttpStatus.CONFLICT)
public class PhoneNumberAlreadyVerifiedException extends RuntimeException {
    public PhoneNumberAlreadyVerifiedException(String message) {
        super(message);
    }
}
