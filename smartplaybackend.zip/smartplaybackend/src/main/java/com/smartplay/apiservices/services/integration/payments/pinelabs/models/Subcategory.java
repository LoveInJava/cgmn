package com.smartplay.apiservices.services.integration.payments.pinelabs.models;

import lombok.Data;

@Data
public class Subcategory {
    private String id;
    private String name;
    private String url;
    private String description;
    private Images images;
    private int subcategoriesCount;
}
