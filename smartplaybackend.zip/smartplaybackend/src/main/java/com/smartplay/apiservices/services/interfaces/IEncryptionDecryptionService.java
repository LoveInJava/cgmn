package com.smartplay.apiservices.services.interfaces;

public interface IEncryptionDecryptionService {

	// Encrypts the given plain text using Base64 encoding
	String encrypt(String plainText);

	// Decrypts the given Base64 encoded string to plain text
	String decrypt(String encryptedText);

}
