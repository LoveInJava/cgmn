package com.smartplay.apiservices.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FeignConfig {

    @Bean
    public PinelabSettingConfiguration getPinelabSettingsConfiguration(){
        return new PinelabSettingConfiguration();
    }

    // @Bean
    // public Client feignClient() {
    //     return new LoggingFeignClient(new OkHttpClient());
    // }

}