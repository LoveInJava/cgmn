package com.smartplay.apiservices.repository.interfaces;
import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.smartplay.apiservices.models.data.UserTimer;

@EnableScan
@Repository
public interface IUserTimerRepository extends CrudRepository<UserTimer, String> {

}
