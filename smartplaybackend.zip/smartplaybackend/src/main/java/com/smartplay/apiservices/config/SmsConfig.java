package com.smartplay.apiservices.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.smartplay.apiservices.services.impl.TwoFactorSmsService;
import com.smartplay.apiservices.services.impl.VoucherSmsService;
import com.smartplay.apiservices.services.integration.service.TwoFactorSmsProvider;
import com.smartplay.apiservices.services.integration.service.VoucherSmsProvider;
import com.smartplay.apiservices.services.interfaces.ISmsService;
import com.smartplay.apiservices.services.interfaces.IVoucherSmsService;

@Configuration
public class SmsConfig {

    @Bean
    @Primary
    public ISmsService getTwoFactorSmsService(@Autowired TwoFactorSmsProvider twoFactorSmsProvider) {
        return new TwoFactorSmsService(twoFactorSmsProvider);
    }

    @Bean
    @Primary
    public IVoucherSmsService getVoucherSmsService(@Autowired VoucherSmsProvider voucherSmsProvider) {
        return new VoucherSmsService(voucherSmsProvider);
    }

}
