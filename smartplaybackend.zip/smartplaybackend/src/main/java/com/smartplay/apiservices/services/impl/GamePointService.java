package com.smartplay.apiservices.services.impl;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.smartplay.apiservices.exceptions.RecordAlreadyExistsException;
import com.smartplay.apiservices.models.data.BonusPoint;
import com.smartplay.apiservices.models.data.LpaUser;
import com.smartplay.apiservices.models.data.SmartPoint;
import com.smartplay.apiservices.models.data.UserSmartPlayGamePoint;
import com.smartplay.apiservices.models.request.FCMNotificationRequest;
import com.smartplay.apiservices.models.request.GamePointRequest;
import com.smartplay.apiservices.models.response.RuleConfigResponse;
import com.smartplay.apiservices.repository.interfaces.IBonusPointRepository;
import com.smartplay.apiservices.repository.interfaces.ILpaUserRepository;
import com.smartplay.apiservices.repository.interfaces.IUserSmartPlayGamePointRepository;
import com.smartplay.apiservices.services.interfaces.IConfigurationService;
import com.smartplay.apiservices.services.interfaces.IGamePointService;
import com.smartplay.apiservices.services.interfaces.INotificationFCMService;
import com.smartplay.apiservices.services.interfaces.IRuleConfigService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class GamePointService implements IGamePointService {

    //private Integer targetPoint = 0;
    private List<Integer> targetPointList = null;
    private List<Integer> bonusPointList = null;
    private final IUserSmartPlayGamePointRepository gamepointRepository;
    private final IBonusPointRepository bonusPointRepository;
    private final IConfigurationService configurationService;
    private final IRuleConfigService reuleConfigService;
    private final ILpaUserRepository lpaUserRepository;
    private final INotificationFCMService notificationFCMService;
    // private final SerializationService serializationService;

    public GamePointService(
            @Autowired IUserSmartPlayGamePointRepository gamepointRepository,
            @Autowired IBonusPointRepository bonusPointRepository,
            @Autowired IConfigurationService configurationService,
            @Autowired IRuleConfigService reuleConfigService,
            @Autowired ILpaUserRepository lpaUserRepository,
            @Autowired INotificationFCMService notificationFCMService
    // ,
    // @Autowired SerializationService serializationService
    ) {
        this.gamepointRepository = gamepointRepository;
        this.bonusPointRepository = bonusPointRepository;
        this.configurationService = configurationService;
        this.reuleConfigService = reuleConfigService;
        this.lpaUserRepository = lpaUserRepository;
        this.notificationFCMService = notificationFCMService;
        // this.serializationService = serializationService;
    }

    @Override
    public void updateGamePoint(@Valid GamePointRequest gamePointRequest) {
        UserSmartPlayGamePoint userGamePoint = gamepointRepository.findById(gamePointRequest.getLpaId()).orElse(null);
        if (ObjectUtils.isEmpty(userGamePoint)) {
            userGamePoint = UserSmartPlayGamePoint.builder()
                    .lpaId(gamePointRequest.getLpaId())
                    .build();
        }

        var allRecords = userGamePoint.getRecords();
        boolean containsRecord = allRecords.stream()
                .anyMatch(r -> r.getRequestId().equals(gamePointRequest.getRequestId()));

        if (containsRecord) {
            throw new RecordAlreadyExistsException("Record already exists");
        }

        log.info("Category Name: {}", gamePointRequest.getCategory());
        log.info("Actual Coming Points : {}", gamePointRequest.getPoints());

        SmartPoint smartPoint = SmartPoint.builder()
                .points(gamePointRequest.getPoints())
                .gameId(gamePointRequest.getGameId())
                .requestId(gamePointRequest.getRequestId())
                .actionDateTime(LocalDateTime.now())
                .build();

        System.out.println("COMING CATEGORY : " + gamePointRequest.getCategory());
        System.out.println("COMING POINTS : " + gamePointRequest.getPoints());
        System.out.println("Previous Records : " + userGamePoint.getRecords());
        userGamePoint.getRecords().add(smartPoint);
        gamepointRepository.save(userGamePoint);

        LpaUser lpaUser = lpaUserRepository.findById(gamePointRequest.getLpaId()).orElse(null);

        FCMNotificationRequest notificationRequest = FCMNotificationRequest.builder()
        .token(lpaUser != null ? lpaUser.getDeviceToken() : null)
        .title("SmartPlay! Good playing!")
        .body("You gain " +gamePointRequest.getPoints() +" points. Play more to earn more!")
        .topic("Gaming").android_channel_id("revenue_channel").channel_id("revenue_channel")
        .build();

        notificationFCMService.sendNotification(notificationRequest);

    }

    @Override
    public Integer getCollectiveGamePointsByLpaId(String lpaId) {
        UserSmartPlayGamePoint userGamePoint = gamepointRepository.findById(lpaId).orElse(null);
        if (ObjectUtils.isEmpty(userGamePoint)) {
            return 0;
        }

        // String json = serializationService.serialize(userGamePoint.getRecords());
        // List<SmartPoint> records = serializationService.deserialize(json, new
        // TypeReference<List<SmartPoint>>() {});
        List<SmartPoint> records = userGamePoint.getRecords();

        Integer val1 = records.stream()
                .mapToInt(SmartPoint::getPoints)
                .sum();

        Integer val2 = getWelcomeBonusPoint(lpaId);
        return val1 + val2;
    }

    @Override
    public void resetGamePoints(String lpaId) {

        BonusPoint bonusPoint = null;
        UserSmartPlayGamePoint userGamePoint = gamepointRepository.findById(lpaId).orElse(null);
        if (ObjectUtils.isEmpty(userGamePoint)) {

            // For New User
            bonusPoint = bonusPointRepository.findById(lpaId).orElse(null);
            if (bonusPoint != null) {
                int index = getRandomIndex();
                bonusPoint.setIsBonusPointAdd(0);
                bonusPoint.setBonusPoint(getAllBonusPoint().get(index));
                bonusPoint.setTargetPoint(getAllTargetPoint().get(index));
                bonusPointRepository.save(bonusPoint);
            }
            return;
        }

        userGamePoint.getRecords().clear();
        gamepointRepository.save(userGamePoint);
        bonusPoint = bonusPointRepository.findById(lpaId).orElse(null);
        if (bonusPoint != null) {
            int index = getRandomIndex();
            bonusPoint.setIsBonusPointAdd(0);
            bonusPoint.setBonusPoint(getAllBonusPoint().get(index));
            bonusPoint.setTargetPoint(getAllTargetPoint().get(index));
            bonusPointRepository.save(bonusPoint);
        }
    }

    private int getRandomIndex() {
        SecureRandom random = new SecureRandom();
        return random.nextInt(6) + 1;
    }

    @Override
    public void allocateBonusPoints(String lpaId, String deviceId) {

        BonusPoint bonus = bonusPointRepository.findById(lpaId).orElse(null);
        // allocate bonus points if not already allocated
        if (!ObjectUtils.isEmpty(bonus)) {
            System.out.println("Allocate Bonus Point");
            return;
        }

        bonusPointRepository.save(BonusPoint.builder()
                .lpaId(lpaId)
                .deviceId(deviceId)
                .welcomeBonusPoint(configurationService.getDefaultBonusPoint())
                .targetPoint(getAllTargetPoint().get(0))
                .bonusPoint(getAllBonusPoint().get(0))
                .isNewUser(0)
                .isBonusPointAdd(0)
                .build());
    }

    @Override
    public Integer getWelcomeBonusPoint(String lpaId) {
        BonusPoint bonus = bonusPointRepository.findById(lpaId).orElse(null);
        if (ObjectUtils.isEmpty(bonus))
            return 0;
        return bonus.getWelcomeBonusPoint();
    }

    @Override
    public List<Integer> getAllTargetPoint() {

        if (targetPointList == null) {
            RuleConfigResponse ruleConfigResponse = reuleConfigService.getsaveRuleConfigurationById("100");
            String targetPoints = ruleConfigResponse.getValue();
            targetPointList = convertStringIntoList(targetPoints);
        }
        return targetPointList;
    }

    @Override
    public List<Integer> getAllBonusPoint() {

        if (bonusPointList == null) {
            RuleConfigResponse ruleConfigResponse = reuleConfigService.getsaveRuleConfigurationById("101");
            String bonusPoints = ruleConfigResponse.getValue();
            bonusPointList = convertStringIntoList(bonusPoints);
        }
        return bonusPointList;
    }

    private List<Integer> convertStringIntoList(String imput) {

        List<Integer> numberList = Stream.of(imput
                .replaceAll("[{}]", "") // Remove curly braces
                .split(",")) // Split by commas
                .map(String::trim) // Trim whitespace
                .map(Integer::parseInt) // Convert to Integer
                .collect(Collectors.toList()); // Collect into a List

        return numberList;
    }

    @Override
    public void convertWelcomeBonusPoint(Integer welcomeBonus, String lpaId) {
        
        UserSmartPlayGamePoint userGamePoint = gamepointRepository.findById(lpaId).orElse(null);

        if (ObjectUtils.isEmpty(userGamePoint)) {
            userGamePoint = UserSmartPlayGamePoint.builder()
                    .lpaId(lpaId)
                    .build();
        }
        List<SmartPoint> records = userGamePoint.getRecords();

        SmartPoint smartPoint = SmartPoint.builder()
        .actionDateTime(LocalDateTime.now())
        .gameId("Welcome Bonus")
        .requestId(UUID.randomUUID().toString())
        .points(welcomeBonus)
        .build();

        records.add(smartPoint);
        userGamePoint.setRecords(records);

        gamepointRepository.save(userGamePoint);

    }

}
