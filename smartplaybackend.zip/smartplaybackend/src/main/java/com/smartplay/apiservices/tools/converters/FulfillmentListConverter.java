package com.smartplay.apiservices.tools.converters;

import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverter;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.Fulfillment;

public class FulfillmentListConverter implements DynamoDBTypeConverter<String, List<Fulfillment>> {

    private static final ObjectMapper objectMapper = getObjectMapper();

    public static ObjectMapper getObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        return objectMapper;
    }

    @Override
    public String convert(List<Fulfillment> object) {
        try {
            return objectMapper.writeValueAsString(object);
        } catch (Exception e) {
            throw new RuntimeException("Unable to convert list to String", e);
        }
    }

    @Override
    public List<Fulfillment> unconvert(String object) {
        try {
            return objectMapper.readValue(object, new TypeReference<List<Fulfillment>>() {});
        } catch (Exception e) {
            throw new RuntimeException("Unable to convert String to list", e);
        }
    }
}