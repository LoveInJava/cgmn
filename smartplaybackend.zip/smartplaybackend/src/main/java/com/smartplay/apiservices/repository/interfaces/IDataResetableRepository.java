package com.smartplay.apiservices.repository.interfaces;

public interface IDataResetableRepository {
    void reset();
}
