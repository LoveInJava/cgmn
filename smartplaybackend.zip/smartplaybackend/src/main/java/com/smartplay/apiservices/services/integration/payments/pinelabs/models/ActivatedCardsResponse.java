package com.smartplay.apiservices.services.integration.payments.pinelabs.models;

import java.util.List;

import com.smartplay.apiservices.services.integration.payments.pinelabs.models.response.OrderResponse;
import lombok.Data;

@Data
public class ActivatedCardsResponse {
    private String status;
    private String orderId;
    private String refno;
    private OrderResponse.Cancel cancel;
    private OrderResponse.Currency currency;
    private Card card;
    private List<Payment> payments;
    private List<Product> products;

    @Data
    public static class Cancel {
        private boolean allowed;
        private int allowedWithIn;
    }

    @Data
    public static class Currency {
        private String code;
        private String numericCode;
        private String symbol;
    }

    @Data
    public static class Payment {
        private String code;
        private String balance;
    }

    @Data
    public static class Card {
        private String sku;
        private String productName;
        private OrderResponse.Card.Labels labels;
        private String cardNumber;
        private String cardPin;
        private String activationCode;
        private String barcode;
        private String activationUrl;
        private OrderResponse.Card.RedemptionUrl redemptionUrl;
        private List<Object> formats;
        private String amount;
        private String validity;
        private String issuanceDate;
        private int cardId;
        private OrderResponse.Card.RecipientDetails recipientDetails;
        private String theme;

        @Data
        public static class Labels {
            private String cardNumber;
            private String cardPin;
            private String activationCode;
            private String validity;
        }

        @Data
        public static class RedemptionUrl {
            private String label;
            private String url;
        }

        @Data
        public static class RecipientDetails {
            private String salutation;
            private String name;
            private String firstname;
            private String lastname;
            private String email;
            private String mobileNumber;
            private String status;
            private String failureReason;
            private OrderResponse.Card.RecipientDetails.Delivery delivery;

            @Data
            public static class Delivery {
                private String mode;
                private OrderResponse.Card.RecipientDetails.Delivery.Status status;

                @Data
                public static class Status {
                    private OrderResponse.Card.RecipientDetails.Delivery.Status.Sms sms;
                    private OrderResponse.Card.RecipientDetails.Delivery.Status.Email email;

                    @Data
                    public static class Sms {
                        private String status;
                        private String reason;
                    }

                    @Data
                    public static class Email {
                        private String status;
                        private String reason;
                    }
                }
            }
        }
    }

    @Data
    public static class Product {
        private String sku;
        private String name;
        private String balanceEnquiryInstruction;
        private String specialInstruction;
        private OrderResponse.Product.Images images;
        private String cardBehaviour;

        @Data
        public static class Images {
            private String thumbnail;
            private String mobile;
            private String base;
            private String small;
        }
    }

}
