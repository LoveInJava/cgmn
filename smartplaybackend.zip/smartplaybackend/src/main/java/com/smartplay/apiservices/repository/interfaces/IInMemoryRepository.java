package com.smartplay.apiservices.repository.interfaces;

@SuppressWarnings({"java:S119"})
public interface IInMemoryRepository<T,Id> extends IRepository<T,Id>, IDataResetableRepository {

}
