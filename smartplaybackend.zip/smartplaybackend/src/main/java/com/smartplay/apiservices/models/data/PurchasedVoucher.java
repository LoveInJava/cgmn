package com.smartplay.apiservices.models.data;

import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverted;
import com.smartplay.apiservices.tools.converters.PinelabPurchasedVoucherListConverter;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@NotNull
@EqualsAndHashCode(callSuper=false)
@DynamoDBTable(tableName = "PurchasedVoucher")
public class PurchasedVoucher {

    @DynamoDBHashKey(attributeName = "lpaId")
    @Schema(description = "lpaId of the player.")

    private String lpaId;

    @Builder.Default
    private String documentType = "purchasedVoucher";

    @Builder.Default
    @DynamoDBTypeConverted(converter = PinelabPurchasedVoucherListConverter.class)
    private List<PinelabPurchasedVoucher> records =  new java.util.ArrayList<>();
}
