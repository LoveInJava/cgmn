package com.smartplay.apiservices.services.integration.payments.pinelabs.models;

import lombok.Data;

@Data
public class OrderStatusResponse {
    private String orderId;
    private String status;

}
