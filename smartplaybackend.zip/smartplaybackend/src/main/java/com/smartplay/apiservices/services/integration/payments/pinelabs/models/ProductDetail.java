package com.smartplay.apiservices.services.integration.payments.pinelabs.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductDetail {

    private String sku;
    private String name;
    private Currency currency;
    private String url;
    private String minPrice;
    private String maxPrice;
    // private Price price;
    // @Builder.Default
    // private List<Discount> discounts = new ArrayList<>();
    private Images images;
    private String createdAt;
    private String updatedAt;
    // private Object campaigns;
}
