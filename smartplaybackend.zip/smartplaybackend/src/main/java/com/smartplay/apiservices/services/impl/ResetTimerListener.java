package com.smartplay.apiservices.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

import com.smartplay.apiservices.models.events.ResetTimerEvent;
import com.smartplay.apiservices.services.interfaces.IGamePointService;
import com.smartplay.apiservices.services.interfaces.IRevenueConversionService;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ResetTimerListener implements ApplicationListener<ResetTimerEvent> {

    private final IRevenueConversionService pointsConversionService;
    private final IGamePointService gamePointService;

    public ResetTimerListener(
        @Autowired IRevenueConversionService pointsConversionService,
    @Autowired IGamePointService gamePointService) {
        this.pointsConversionService = pointsConversionService;
        this.gamePointService = gamePointService;
    }

    @Override
    public void onApplicationEvent(@NonNull ResetTimerEvent event) {
        log.info("\t\t[Listening::ResetTimerEvent] " + event.getLpaId() + " - " + event.getStartTime());

        //1. update event to new current event
        // currentEventService.setCurrentEvent(event);
        //2. calculate  point to $$
        pointsConversionService.convertRevenueToMoney(event);
        //3. reset all points in previous game events
        gamePointService.resetGamePoints(event.getLpaId());
        //4. push notification to all users
        //5. update event status to completed
    }
}
