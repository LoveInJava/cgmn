package com.smartplay.apiservices.models.data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverted;
import com.smartplay.apiservices.tools.converters.LocalDateTimeConverter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AdRevenue implements Serializable{

    private String adId;

    private String deviceId;

    private String networkName;

    private BigDecimal revenue;

    private String currency;

    private String gamePackageId;

    private String adType;

    @DynamoDBTypeConverted(converter = LocalDateTimeConverter.class)
    private LocalDateTime entryTimeStamp;

    private String registeredDeviceIp;

}
