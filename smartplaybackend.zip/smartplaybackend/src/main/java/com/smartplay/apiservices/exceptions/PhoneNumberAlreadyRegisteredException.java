package com.smartplay.apiservices.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import lombok.Getter;

@ResponseStatus(value=HttpStatus.SEE_OTHER)
public class PhoneNumberAlreadyRegisteredException extends UserAlreadyRegisteredException {

    @Getter
    private final String mobileNumber;


    public PhoneNumberAlreadyRegisteredException(String message, String lpaId, String mobileNumber) {
        super(message,lpaId);
        this.mobileNumber = mobileNumber;
    }
}
