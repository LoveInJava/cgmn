package com.smartplay.apiservices.models.request;

import com.smartplay.apiservices.models.validators.ValidRegistrationRequest;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@ValidRegistrationRequest(message = "Verification Code and Mobile Number are required", payload = {}, groups = GroupRegistration.class)
@NotNull
@EqualsAndHashCode(callSuper=true)
public class VerificationRequest extends MobileRegistrationRequest{

    @NotNull(message = "Verification is required")
    private String verificationCode;

}
