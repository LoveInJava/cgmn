package com.smartplay.apiservices.services.impl;

import java.time.LocalDateTime;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartplay.apiservices.models.data.AdRevenue;
import com.smartplay.apiservices.models.data.UserAdRevenue;
import com.smartplay.apiservices.models.request.RevenueDetailsRequest;
import com.smartplay.apiservices.repository.interfaces.IUserAdRevenueRepository;
import com.smartplay.apiservices.services.interfaces.IAdRevenueService;

@Service
public class AdRevenueService implements IAdRevenueService {

    private final IUserAdRevenueRepository userAdRevenueRepository;

    public AdRevenueService(@Autowired IUserAdRevenueRepository  userAdRevenueRepository) {
        this.userAdRevenueRepository = userAdRevenueRepository;
    }

    private AdRevenue mapToAdRevenue(RevenueDetailsRequest revenueDetailsRequest) {
        return AdRevenue.builder()
                .adId(revenueDetailsRequest.getAdId())
                .deviceId(revenueDetailsRequest.getDeviceId())
                .revenue(revenueDetailsRequest.getRevenue())
                .currency(revenueDetailsRequest.getCurrency())
                .gamePackageId(revenueDetailsRequest.getGamePackageId())
                .adType(revenueDetailsRequest.getAdType())
                .networkName(revenueDetailsRequest.getNetworkName())
                .entryTimeStamp(LocalDateTime.now())
                .registeredDeviceIp(revenueDetailsRequest.getRegisteredDeviceIp())
                .build();
    }

    @Override
    public void save(RevenueDetailsRequest revenueDetailsRequest) {

        UserAdRevenue userAdRevenue = userAdRevenueRepository.findById(revenueDetailsRequest.getLpaId()).orElse(null);

        if (ObjectUtils.isEmpty(userAdRevenue)) {
            userAdRevenue = UserAdRevenue.builder()
                        .lpaId(revenueDetailsRequest.getLpaId())
                        .build();
        }

        userAdRevenue.getRecords().add(mapToAdRevenue(revenueDetailsRequest));
        userAdRevenueRepository.save(userAdRevenue);
    }

}
