package com.smartplay.apiservices.services.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartplay.apiservices.models.data.TestEntity;
import com.smartplay.apiservices.repository.interfaces.SampleRepository;

@Service
public class SampleService {

    @Autowired
    private SampleRepository sampleRepository;

    public TestEntity save(TestEntity entity) {
        return sampleRepository.save(entity);
    }

    public Optional<TestEntity> findById(String id) {
        return sampleRepository.findById(id);
    }

    public Iterable<TestEntity> findAll() {
        return sampleRepository.findAll();
    }

    public void deleteById(String id) {
        sampleRepository.deleteById(id);
    }
}