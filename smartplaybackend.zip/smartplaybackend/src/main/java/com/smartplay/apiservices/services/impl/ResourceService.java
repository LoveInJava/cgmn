package com.smartplay.apiservices.services.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.smartplay.apiservices.services.interfaces.IResourceService;

@Service
public class ResourceService  implements IResourceService {

    @Override
    public List<String> readLinesFromResource(String resourceName) throws IOException {
        List<String> lines = new ArrayList<>();
        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream(resourceName);
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
        }
        return lines;
    }

}
