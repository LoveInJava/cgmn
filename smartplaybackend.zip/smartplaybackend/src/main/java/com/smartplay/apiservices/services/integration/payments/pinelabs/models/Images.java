package com.smartplay.apiservices.services.integration.payments.pinelabs.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Images {
    private String thumbnail;
    private String mobile;
    private String base;
    private String small;
}
