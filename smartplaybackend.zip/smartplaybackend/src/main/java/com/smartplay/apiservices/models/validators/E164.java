package com.smartplay.apiservices.models.validators;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.messaging.handler.annotation.Payload;

import jakarta.validation.Constraint;

@Constraint(validatedBy = E164Validator.class)
@Target({ ElementType.FIELD, ElementType.PARAMETER })
@Retention(RetentionPolicy.RUNTIME)
public @interface E164 {
    String message() default "Invalid phone number format. Must be in E.164 format.";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
