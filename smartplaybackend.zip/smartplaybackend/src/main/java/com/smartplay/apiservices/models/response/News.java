package com.smartplay.apiservices.models.response;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Builder
public class News{

	@Getter
	@Builder.Default
	private ReponseType type = ReponseType.NEWS;

	@Getter
	@Setter
	private BannerInfo info;

	@Getter
	@Builder.Default
	private final List<NewsItem> details = new ArrayList<>();

}
