package com.smartplay.apiservices.controller.tests;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartplay.apiservices.models.data.PurchasedVoucher;
import com.smartplay.apiservices.repository.interfaces.IPurchasedVoucherRepository;

@RequestMapping("/api/db/purchasedvouchers")
@RestController
public class PinelabPurchasedVoucherController extends BaseCrudController<PurchasedVoucher, String, IPurchasedVoucherRepository> {

}
