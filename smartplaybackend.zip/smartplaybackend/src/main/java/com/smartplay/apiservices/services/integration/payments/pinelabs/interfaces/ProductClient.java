package com.smartplay.apiservices.services.integration.payments.pinelabs.interfaces;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.smartplay.apiservices.config.ProductClientConfig;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.ActivatedCardsResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.CategoryResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.OrderRequest;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.OrderStatusResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.ProductListResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.ProductResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.response.OrderResponse;

@FeignClient(name = "productClient", url ="${qwikgifts.api.url}", configuration = ProductClientConfig.class)
public interface ProductClient {
    @GetMapping("/rest/v3/catalog/products/{productSku}")
    ProductResponse getProductBySku( @PathVariable("productSku") String productSku);

    @GetMapping("/rest/v3/catalog/categories/{categoryId}/products?offset=offset&limit=limit")
    ProductListResponse getProductByCategoryId( @PathVariable("categoryId") String productId);


    @GetMapping("/rest/v3/catalog/categories?q=1")
    CategoryResponse getCategories();

    @PostMapping("/rest/v3/order")
    OrderResponse orderVoucher(@RequestBody OrderRequest orderRequest);

    @GetMapping("/rest/v3/order/{referenceId}/status")
    OrderStatusResponse getOrderStatus(@PathVariable("referenceId") String referenceId);

    @GetMapping("/rest/v3/order/{orderId}")
    ActivatedCardsResponse getActivatedCards(@PathVariable("orderId") String orderId);

}
