package com.smartplay.apiservices.config;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;


@Configuration
public class MailConfiguration {
    @Autowired
    Environment environment;
    @Bean
    public JavaMailSender getJavaMailSender() {
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        mailSender.setHost(environment.getProperty(MailConstants.MAIL_HOST));
        mailSender.setPort(Integer.parseInt(environment.getProperty(MailConstants.MAIL_PORT)));
        mailSender.setUsername(environment.getProperty(MailConstants.MAIL_USERNAME));
        mailSender.setPassword(environment.getProperty(MailConstants.MAIL_PASSWORD));
        Properties props = mailSender.getJavaMailProperties();
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.debug", "true");

        return mailSender;
    }
}