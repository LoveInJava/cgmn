package com.smartplay.apiservices.controller;

import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.smartplay.apiservices.models.data.BonusPoint;
import com.smartplay.apiservices.models.data.UserSmartPlayMoney;
import com.smartplay.apiservices.models.data.UserTimer;
import com.smartplay.apiservices.models.request.GamePointRequest;
import com.smartplay.apiservices.models.response.About;
import com.smartplay.apiservices.models.response.Cashout;
import com.smartplay.apiservices.models.response.Faq;
import com.smartplay.apiservices.models.response.Games;
import com.smartplay.apiservices.models.response.News;
import com.smartplay.apiservices.models.response.Points;
import com.smartplay.apiservices.models.response.PrivacyPolicy;
import com.smartplay.apiservices.models.response.RewardsResponse;
import com.smartplay.apiservices.models.response.SmartPoint;
import com.smartplay.apiservices.models.response.SmartPointDetails;
import com.smartplay.apiservices.models.response.TimeRange;
import com.smartplay.apiservices.repository.interfaces.IBonusPointRepository;
import com.smartplay.apiservices.repository.interfaces.IUserSmartPlayMoneyRepository;
import com.smartplay.apiservices.services.helpers.UserSmartPlayMoneyHelper;
import com.smartplay.apiservices.services.impl.TimerService;
import com.smartplay.apiservices.services.interfaces.IConfigurationService;
import com.smartplay.apiservices.services.interfaces.IGamePointService;
import com.smartplay.apiservices.tools.VerifyHeaderToParamPayload;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1")
@Tag(name = "mobile", description = "Api's for mobile devices")
@Slf4j
public class EndPointsController {

	private final IGamePointService gamePointService;
	private final IUserSmartPlayMoneyRepository smartplayMoneyRepository;
	private final IConfigurationService configurationService;
	private final TimerService	timerService;
	private final IBonusPointRepository	bonusPointRepository;

	public EndPointsController(
		@Autowired IGamePointService gamePointService,
		@Autowired IConfigurationService configurationService,
		@Autowired TimerService	timerService,
		@Autowired IUserSmartPlayMoneyRepository smartplayMoneyRepository,
		@Autowired IBonusPointRepository bonusPointRepository) {
		this.gamePointService = gamePointService;
		this.configurationService = configurationService;
		this.timerService = timerService;
		this.smartplayMoneyRepository = smartplayMoneyRepository;
		this.bonusPointRepository = bonusPointRepository;
	}

	@GetMapping(value="/about", produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(summary = "About API to display about content")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "about response", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = About.class)) }),
			@ApiResponse(responseCode = "400", description = "Internal server error", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class)) }) })
	public ResponseEntity<About> about(){

		return ResponseEntity.ok( this.configurationService.getAbout());
	}

	@GetMapping(value="/news", produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(summary = "news response")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "news response", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = News.class)) }),
			@ApiResponse(responseCode = "400", description = "Internal server error", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class)) }) })
	public ResponseEntity<News> news()  {
		return ResponseEntity.ok( this.configurationService.getNews());
	}

	@GetMapping(value = "/faq", produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(summary = "faq response")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "news response successful", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = News.class)) }),
			@ApiResponse(responseCode = "400", description = "Internal server error", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class)) }) })
	public ResponseEntity<Faq> faq()  {

		return ResponseEntity.ok( this.configurationService.getFaq());
	}

	@GetMapping(value="/games", produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(summary = "list of games")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "List of games", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = Games.class)) }),
			@ApiResponse(responseCode = "400", description = "Internal server error", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class)) }) })
	public ResponseEntity<Games> games()  {

		return ResponseEntity.ok( this.configurationService.getGames());

	}

	@GetMapping(value="/privacypolicy", produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(summary = "privacypolicy response")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "news response successful", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = PrivacyPolicy.class)) }),
			@ApiResponse(responseCode = "400", description = "Internal server error", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class)) }) })
	public ResponseEntity<PrivacyPolicy> privacypolicy()  {

		return ResponseEntity.ok( this.configurationService.getPrivacyPolicy());
	}

	@GetMapping(value = "/rewards/{lpaid}", produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(summary = "rewards response")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "rewards response", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = RewardsResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Internal server error", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class)) }) })
	public ResponseEntity<RewardsResponse> rewards(
			@Parameter(description = "Lpa id")
			@PathVariable("lpaid") String lpaId)  {

		RewardsResponse response = new RewardsResponse();

		return ResponseEntity.ok( response);
	}



	@GetMapping(value =  "/smartpoints/{device-id}/{lpaId}/{isNewUser}/{lastTimerId}", produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(summary = "smartpoints response")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "smartpoints response", content = {
		@Content(mediaType = "application/json", schema = @Schema(implementation = SmartPoint.class)) }),
		@ApiResponse(responseCode = "400", description = "Internal server error", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class)) }) })
	@VerifyHeaderToParamPayload(headerDeviceId = "device-id", paramDeviceId = "device-id")
	public ResponseEntity<SmartPoint> smartpoints(
		@Parameter(description = "Encrypted device ID GAID( google)/IDFA (Apple)") @RequestHeader("device-id") String headerDeviceId,
        @Parameter(description = "Device Id") @PathVariable("device-id") String paramDeviceId,
		@Parameter(description = "Lpa Id") @PathVariable("lpaId") String lpaId,
		@Parameter(description = "Is New User") @PathVariable("isNewUser") Integer isNewUser,
		@Parameter(description = "Last Timer Id") @PathVariable("lastTimerId") String lastTimerId
	)  {

		UserTimer userTimer = timerService.getTimer(lpaId);
		UserSmartPlayMoney userSmartPlayMoney = smartplayMoneyRepository.findById(lpaId).orElse(UserSmartPlayMoney.builder().lpaId(lpaId).build());


		Cashout availableCash = UserSmartPlayMoneyHelper.getAvailableCash(UUID.fromString(lastTimerId)  , userTimer.getTimerId(),  userSmartPlayMoney);
		
		logit("lpaId: {} @ smartpoint , getCollectiveGamePointsByLpaId : before", lpaId);
		Integer actual = gamePointService.getCollectiveGamePointsByLpaId(lpaId);
		//Integer welcomBonus = gamePointService.getWelcomeBonusPoint(lpaId);
		logit("lpaId: {} @ smartpoint , getCollectiveGamePointsByLpaId : after", lpaId);

		logit("lpaId: {} @ smartpoint , SmartPointDetails : before", lpaId);

		BonusPoint bonusPoint =  bonusPointRepository.findById(lpaId).orElse(null);
		Integer userBonus = 0; //(bonusPoint != null) ?bonusPoint.getWelcomeBonusPoint() :0;
		Integer welcomeBonus = 0;
		Integer targetPoint = 0;
		Integer bonusPointAdd = 0;

		if(bonusPoint != null){
			welcomeBonus = bonusPoint.getWelcomeBonusPoint();
			userBonus = bonusPoint.getBonusPoint();
			targetPoint = bonusPoint.getTargetPoint();			
			bonusPointAdd = bonusPoint.getIsBonusPointAdd();			
		}

		if(isNewUser > 0 && bonusPoint != null){

			// add welcome bonus points into actual point
			gamePointService.convertWelcomeBonusPoint(welcomeBonus, lpaId);

			// update welcome bonuspoint
			actual = actual + welcomeBonus;
			welcomeBonus = 0;
			bonusPoint.setWelcomeBonusPoint(welcomeBonus);
			bonusPoint.setIsNewUser(1);
			bonusPointRepository.save(bonusPoint);			
		}

		if(bonusPoint != null && actual > userBonus && bonusPointAdd == 0){
			// add bonus points into actual point
			actual = actual + userBonus;
			gamePointService.convertWelcomeBonusPoint(userBonus, lpaId);
			bonusPoint.setIsBonusPointAdd(1);
			bonusPointRepository.save(bonusPoint);
		}
		
		SmartPointDetails smartpoints = SmartPointDetails.builder()
				.points(Points.builder().actual(actual)
				.bonus(userBonus)
				.welcomebonus(welcomeBonus)
				.target( targetPoint)
				.bonusTargetPoints(0)
				//currentGameEventDetails.getTarget()).build())  //@TODO : get Target
				.build())
				.cashout(availableCash).build();

		//UserTimer userTimer = timerService.getTimer(lpaId);
		if(userTimer != null){
			// Step 2: Specify the ZoneId for India
			TimeRange time= TimeRange.builder().start(userTimer.getStartTime()).end(userTimer.getEndTime())
			.userTimerId(userTimer.getTimerId().toString()).build();
			smartpoints.setTime(time);
		}
		return ResponseEntity.ok(SmartPoint.builder().details(smartpoints).build());
	}

	private void logit(String format, Object arg){
		String logMessage = String.format(format, arg);
		System.out.println( logMessage);
		log.info(format, arg);
		log.error(format, arg);
	}


	@PostMapping(value="/smartpoints/{deviceId}/", produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(summary = "game points")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Adding game points", content = {
		@Content(mediaType = "application/json") }),
		@ApiResponse(responseCode = "400", description = "Internal server error", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class)) }) })
	public ResponseEntity<Void> smartpoints(
		@Parameter(description = "Encrypted device ID GAID( google)/IDFA (Apple)") @RequestHeader("device-id") String encryptedDeviceId,
		@Parameter(description = "Encrypted geo-cordinates") @RequestHeader("geo-cordinates") String encryptedGeoCordinates,
		@Parameter(description = "Device id") @PathVariable("deviceId") String deviceId,
		@Valid @RequestBody GamePointRequest gamePointRequest)  {

		if (!encryptedGeoCordinates.matches(GamePointRequest.GEO_COORDINATE_PATTERN)) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid geocoordinates");
		}
		System.out.println("Coming Request : "+gamePointRequest);
		gamePointService.updateGamePoint(gamePointRequest);

		return ResponseEntity.ok().build();
	}
}
