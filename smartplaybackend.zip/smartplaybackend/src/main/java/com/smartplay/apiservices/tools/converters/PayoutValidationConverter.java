package com.smartplay.apiservices.tools.converters;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverter;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.PayoutValidation;

public class PayoutValidationConverter implements DynamoDBTypeConverter<String, PayoutValidation> {
    private static final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public String convert(PayoutValidation object) {
        try {
            return objectMapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error converting PayoutValidation to String", e);
        }
    }

    @Override
    public PayoutValidation unconvert(String object) {
        try {
            return objectMapper.readValue(object, PayoutValidation.class);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error converting String to PayoutValidation", e);
        }
    }
}