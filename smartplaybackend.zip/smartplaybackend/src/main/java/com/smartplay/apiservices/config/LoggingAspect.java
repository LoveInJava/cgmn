package com.smartplay.apiservices.config;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Aspect
@Component
@Slf4j
public class LoggingAspect {

    @Around("@annotation(org.springframework.web.bind.annotation.PostMapping) || @annotation(org.springframework.web.bind.annotation.RequestMapping) || @annotation(org.springframework.web.bind.annotation.GetMapping) || @annotation(org.springframework.web.bind.annotation.PostMapping) || @annotation(org.springframework.web.bind.annotation.PutMapping) || @annotation(org.springframework.web.bind.annotation.DeleteMapping)")
    public Object logApiCall(ProceedingJoinPoint joinPoint) throws Throwable {
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        // Log method entry and arguments
        log.info("Entering method: {} with arguments: {}", methodSignature.getMethod(), joinPoint.getArgs());

        try {
            Object result = joinPoint.proceed();
            // Log method exit and result
            log.info("Exiting method: {} with result: {}", methodSignature.getMethod(), result);
            return result;
        } catch (Exception e) {
            // Log exception and stack trace
            log.error("Exception in method: {}", methodSignature.getMethod(), e);
            throw e;
        }
    }
}
