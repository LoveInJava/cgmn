/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.smartplay.apiservices.tools.utils;


/**
 * @author owner
 */

public class Encryptor {

    public static String secretKey = "RBLJ0000001IFSCTEST#3210";
    public static String salt = "MySalt";
}
