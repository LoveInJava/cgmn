package com.smartplay.apiservices.tools;

import java.util.Map;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerMapping;

import com.smartplay.apiservices.exceptions.InvalidRequestBadPayload;
import com.smartplay.apiservices.services.impl.HeaderPayloadVerificationService;

import jakarta.servlet.http.HttpServletRequest;

@Aspect
@Component
public class VerifyHeaderToParamPayloadAspect {

    private final HeaderPayloadVerificationService headerPayloadVerificationService;
    private final HttpServletRequest request;

    public VerifyHeaderToParamPayloadAspect(
        @Autowired HeaderPayloadVerificationService headerPayloadVerificationService,
        @Autowired HttpServletRequest request) {
        this.headerPayloadVerificationService = headerPayloadVerificationService;
        this.request = request;
    }

    @Around("@annotation(verifyHeaderToParamPayload)")
    public Object verifyHeaderToParamPayload(ProceedingJoinPoint joinPoint, VerifyHeaderToParamPayload verifyHeaderToParamPayload) throws Throwable {

        String headerDeviceId = request.getHeader(verifyHeaderToParamPayload.headerDeviceId());

        @SuppressWarnings("unchecked")
        Map<String, String> pathVariables = (Map<String, String>) request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
        String paramDeviceId = pathVariables.get(verifyHeaderToParamPayload.paramDeviceId());

        if (!headerPayloadVerificationService.verifyHeaderToParamPayload(headerDeviceId, paramDeviceId)) {
            throw new InvalidRequestBadPayload();
        }

        return joinPoint.proceed();
    }
}
