package com.smartplay.apiservices.services.impl;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.smartplay.apiservices.exceptions.InvalidPhoneNumberException;
import com.smartplay.apiservices.exceptions.InvalidVerificationCodeException;
import com.smartplay.apiservices.exceptions.PhoneNumberAlreadyRegisteredException;
import com.smartplay.apiservices.exceptions.PhoneNumberAlreadyVerifiedException;
import com.smartplay.apiservices.models.data.BonusPoint;
import com.smartplay.apiservices.models.data.LpaUser;
import com.smartplay.apiservices.models.response.RegistrationStatus;
import com.smartplay.apiservices.repository.interfaces.IBonusPointRepository;
import com.smartplay.apiservices.services.interfaces.IAvatarNameService;
import com.smartplay.apiservices.services.interfaces.IGamePointService;
import com.smartplay.apiservices.services.interfaces.INotificationService;
import com.smartplay.apiservices.services.interfaces.IRegistrationService;
import com.smartplay.apiservices.services.interfaces.IUserRegistrationService;

/**
 * Class @RegistrationService represents a registration service that handles user registration and verification.
 */
@Service
public class RegistrationService implements IRegistrationService{
    private final IUserRegistrationService userRegistrationService;
    private final INotificationService notificationService;
    private final IAvatarNameService avatarNameService;
    private final IGamePointService gamePointService;
    private final TimerService timerService;
    private final IBonusPointRepository	bonusPointRepository;

    /**
     * Constructs a new RegistrationService with the specified dependencies.
     *
     * @param userRegistrationService The user registration service.
     * @param notificationService     The notification service.
     */
    public RegistrationService(@Autowired IUserRegistrationService userRegistrationService,
                                @Autowired INotificationService notificationService,
                                @Autowired IAvatarNameService avatarNameService,
                                @Autowired IGamePointService gamePointService,
                                @Autowired TimerService timerService,
                                @Autowired IBonusPointRepository bonusPointRepository) {
        this.userRegistrationService = userRegistrationService;
        this.notificationService = notificationService;
        this.avatarNameService =avatarNameService;
        this.gamePointService = gamePointService;
        this.timerService = timerService;
        this.bonusPointRepository = bonusPointRepository;
    }

    /**
     * Handles a registration request for the given phone number and device ID.
     *
     * @param phoneNumber The phone number to register.
     * @param deviceId    The device ID associated with the registration.
     * @throws InvalidPhoneNumberException         If the phone number is invalid.
     * @throws PhoneNumberAlreadyRegisteredException If the phone number is already registered.
     * @throws PhoneNumberAlreadyVerifiedException If the phone number is already verified.
     */
    @Override
    public LpaUser handleRegistrationRequest(String phoneNumber, String deviceToken, String deviceId) {

        if (org.springframework.util.ObjectUtils.isEmpty(deviceId)) {
            throw new RuntimeException("Invalid device id");
        }

        LpaUser lpaUser = userRegistrationService.getByDeviceId(deviceId);

        var hasPhoneNumber = !org.springframework.util.ObjectUtils.isEmpty(phoneNumber);
        if (hasPhoneNumber && !userRegistrationService.isPhoneNumberValid(phoneNumber)) {
            throw new InvalidPhoneNumberException("Invalid phone number");
        }

        if(lpaUser != null ) {

            var lpaUserNumberRegistered = !ObjectUtils.isEmpty(lpaUser.getPhoneNumber());
            var lpaUserNumberVerified = lpaUserNumberRegistered && lpaUser.isPhoneNumberVerified();
            
            if(deviceToken != null && !deviceId.isEmpty()){
            
            lpaUser.setDeviceToken(deviceToken);
            var user = userRegistrationService.saveRegistrationRequest(lpaUser);
            }
            if(!hasPhoneNumber || (hasPhoneNumber && lpaUserNumberRegistered && lpaUser.getPhoneNumber().equals(phoneNumber)) ){
                return lpaUser;
            }

            if (ObjectUtils.isEmpty(lpaUser.getPhoneNumber()) || !lpaUser.getPhoneNumber().equals(phoneNumber)) {
                lpaUser.setPhoneNumber(phoneNumber);
            }

            if (lpaUserNumberVerified) {
                throw new PhoneNumberAlreadyVerifiedException("Phone number already verified");
            }

            String verificationCode = userRegistrationService.generateVerificationCode();
            notificationService.sendVerificationCode(phoneNumber, verificationCode);

            return lpaUser;
        }

        lpaUser = LpaUser.builder()
                            .lpaId(UUID.randomUUID().toString())
                            .username(avatarNameService.getUniqueAvatarNameDbVerified())
                            .deviceToken(deviceToken)
                            .build();

        if (hasPhoneNumber && userRegistrationService.isPhoneNumberVerified(phoneNumber)) {
            throw new PhoneNumberAlreadyVerifiedException("Phone number is already registered against another device.");
        }

        if(hasPhoneNumber) {
            lpaUser.setPhoneNumber(phoneNumber);
        }

        lpaUser.addDeviceId(deviceId);

        if(deviceToken != null && !deviceToken.isEmpty()){
        lpaUser = userRegistrationService.saveRegistrationRequest(lpaUser);
        }
        timerService.startTimer(lpaUser.getLpaId());

        if(hasPhoneNumber) {
            String verificationCode = userRegistrationService.generateVerificationCode();
            notificationService.sendVerificationCode(phoneNumber, verificationCode);
        }

        gamePointService.allocateBonusPoints(lpaUser.getLpaId(), deviceId);
        return lpaUser;
    }

    /**
     * Handles the submission of a verification code for the given phone number.
     *
     * @param phoneNumber      The phone number to verify.
     * @param verificationCode The verification code to submit.
     * @throws InvalidVerificationCodeException If the verification code is invalid.
     */
    @Override
    public LpaUser handleVerificationCodeSubmission(String phoneNumber,String deviceId, String verificationCode) {
        if (!userRegistrationService.validateOtp(phoneNumber, verificationCode)) {
            throw new InvalidVerificationCodeException("Invalid verification code");
        }

        return userRegistrationService.updateOtpVerificationStatus(phoneNumber, deviceId, true);
    }

    /**
     * Get registration status for the given phone number and device ID.
     *
     * @param phoneNumber The phone number to check.
     * @param deviceId    The device ID to check.
     * @return The registration status.
     */
    @Override
    public RegistrationStatus getRegistrationStatus(String phoneNumber, String deviceId) {
        if (!userRegistrationService.isPhoneNumberValid(phoneNumber)) {
            throw new InvalidPhoneNumberException("Invalid phone number");
        }

        LpaUser user = this.userRegistrationService.getByPhoneNumberDeviceId(phoneNumber, deviceId);
        return generateStatusByLpaUser(user,  deviceId);
    }

    /**
     * Get registration status for the device ID.
     *
     * @param lpaId The LPA ID to check.
     * @param deviceId    The device ID to check.
     * @return The registration status.
     */
    @Override
    public RegistrationStatus getRegistrationStatusByLpaIdDeviceId(String lpaId, String deviceId){

        LpaUser user = this.userRegistrationService.getByLpaIdDeviceId(lpaId, deviceId);
        return generateStatusByLpaUser(user, deviceId);
    }

    @Override
    public RegistrationStatus generateStatusByLpaUser(LpaUser user, String deviceId) {

       BonusPoint bonusPoint = bonusPointRepository.findById(user.getLpaId()).orElse(null);

       int isNew = 0;
        if(bonusPoint != null){
            isNew = bonusPoint.getIsNewUser();
        }
        var response = RegistrationStatus.builder()
            .isMobileRegistered( user.getPhoneNumber()!=null)
            .isVerified( user.isPhoneNumberVerified())
            .lpaId(user.getLpaId().toString())
            .username(user.getUsername())
            .isDeviceRegistered(false)
            .isNewUser(isNew)
            .userTimerId(timerService.getTimer(user.getLpaId().toString()).getTimerId().toString())
            .build();

        if(!ObjectUtils.isEmpty(deviceId)) {
            response.setDeviceRegistered(user.getDeviceIds().contains(deviceId));
        }

        return response;
    }

    /**
      * Handles the resending of an OTP verification code for the given phone number.
      *
      * @param phoneNumber The phone number to resend the OTP verification code.
      */
    @Override
    public LpaUser handleResendOtpVerificationCode(String phoneNumber ,String deviceId) {
        var user = userRegistrationService.updateOtpVerificationStatus(phoneNumber, deviceId, false);
        String verificationCode = userRegistrationService.generateVerificationCode();
        notificationService.retrySendVerificationCode(phoneNumber, verificationCode);
        return user;
    }

    @Override
    public LpaUser getRegistrationStatusByDeviceid(String deviceId) {
        return userRegistrationService.getByDeviceId(deviceId);
    }

    @Override
    public LpaUser getRegistrationStatusByMobile(String mobile) {
        return userRegistrationService.getByPhoneNumber(mobile);
    }

    @Override
    public LpaUser getRegistrationStatusByLpaid(String lpaId) {
        return userRegistrationService.getByLpaId(lpaId);
    }

    @Override
    public String getOtpByDeviceId(String deviceId) {
        return userRegistrationService.getOtpByDeviceId(deviceId);
    }
}
