package com.smartplay.apiservices.models.request;

import java.io.Serializable;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;


@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@NotNull
public class BrowserRegistrationRequest implements Serializable {

    @SuppressWarnings({"java:S5842", "java:S5843","java:S6397"})
    public static final String MOBILE_REGEX = "^(?:(?:\\+|0{0,2})91(\\s*|[\\-])?|[0]?)?([6789]\\d{2}([ -]?)\\d{3}([ -]?)\\d{4})$";

    @Pattern(regexp = MOBILE_REGEX, message = "Invalid Indian phone number")
    @NotNull(message = "Mobile number is required")
    private String mobile;

}
