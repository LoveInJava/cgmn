package com.smartplay.apiservices.config;

import org.socialsignin.spring.data.dynamodb.repository.config.EnableDynamoDBRepositories;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Configuration
@EnableDynamoDBRepositories(basePackages = "com.smartplay.apiservices.repository.interfaces")
public class DynamoDBConfig {

    @Bean
    public AmazonDynamoDB amazonDynamoDB() {
        String accessKey = "AKIA6ODU5AADO5FNOGYC";
        String secretKey = "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";
        String region = "ap-south-1";

//        return AmazonDynamoDBClientBuilder.standard()
//                .withCredentials(new AWSStaticCredentialsProvider(new BasicAWSCredentials(accessKey, secretKey)))
//                .withRegion(region)
//                .build();

         BasicAWSCredentials awsCreds = new BasicAWSCredentials("elc3l", "t4vrddj");
         return AmazonDynamoDBClientBuilder.standard()
                 .withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration(
                             "http://localhost:8001", "us-west-2"))
                 .withCredentials(new AWSStaticCredentialsProvider(awsCreds))
                         // "http://dynamodb-local:8000", "us-east-1"))
                 .build();
    }
}