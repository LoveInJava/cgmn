package com.smartplay.apiservices.models.response;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.smartplay.apiservices.config.JsonConfig;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class TimeRange {

	@JsonFormat(pattern =JsonConfig.UTC_DATE_TIME_TZ_FORMAT, timezone = JsonConfig.UTC)
	private LocalDateTime start;

	@JsonFormat(pattern =JsonConfig.UTC_DATE_TIME_TZ_FORMAT, timezone = JsonConfig.UTC)
	private LocalDateTime end;
	private String userTimerId;

}
