package com.smartplay.apiservices.services.impl;

import java.math.BigDecimal;

import org.springframework.stereotype.Service;

import com.smartplay.apiservices.models.enums.Currency;
import com.smartplay.apiservices.models.response.About;
import com.smartplay.apiservices.models.response.BannerInfo;
import com.smartplay.apiservices.models.response.Faq;
import com.smartplay.apiservices.models.response.Games;
import com.smartplay.apiservices.models.response.GamesItem;
import com.smartplay.apiservices.models.response.News;
import com.smartplay.apiservices.models.response.NewsItem;
import com.smartplay.apiservices.models.response.PrivacyPolicy;
import com.smartplay.apiservices.services.interfaces.IConfigurationService;

@Service
public class ConfigurationService implements IConfigurationService {

    private static final String BANNER_TEXT = "banner text";
	private static final String BANNER_URL = "https://demo.sirv.com/nuphar.jpg?w=100";
    private static final String USD_TO_INR_MULTIPLIER = "83.00";

    // public static final long TIMER_WINDOW_IN_SECONDS = 4L * 60 * 60 ; // 4 hours
    public static final long TIMER_WINDOW_IN_SECONDS = 60 * 60 ; // 60 minutes

    @Override
    public int getDefaultBonusPoint() {
        return 500;
    }

    @Override
    public About getAbout() {
        About about = new About();
		BannerInfo banner = BannerInfo.builder().description("sample about").banner(BANNER_TEXT).webUrl(BANNER_URL).build();
		about.setInfo(banner);
        return about;
    }

    @Override
    public News getNews() {
        News news = new News();

		news.setInfo(BannerInfo.builder().description("sample news").banner(BANNER_TEXT).webUrl(BANNER_URL).build());

		news.getDetails().add(NewsItem.builder().id("10001").info(BannerInfo.builder().description("new item1").banner(BANNER_TEXT).webUrl(BANNER_URL).build()).order(2).build());
		news.getDetails().add(NewsItem.builder().id("10002").info(BannerInfo.builder().description("new item2").banner(BANNER_TEXT).webUrl(BANNER_URL).build()).order(1).build());

        return news;
    }

    @Override
    public Faq getFaq() {
        Faq faq = new Faq();
		faq.setInfo(BannerInfo.builder().webUrl("https://storage.googleapis.com/smartplay-app-images/qna.json").build());
        return faq;
    }

    @Override
    public PrivacyPolicy getPrivacyPolicy() {
        PrivacyPolicy privacyPolicy = new PrivacyPolicy();
		privacyPolicy.setInfo(BannerInfo.builder().banner("Privacy Policy Document").webUrl("https://storage.googleapis.com/smartplay-app-images/tnc.html").build());
		return privacyPolicy;
    }

    @Override
    public Games getGames() {
        Games response = new Games();
		response.setInfo(BannerInfo.builder().description("List of games").banner("List of games").webUrl(BANNER_URL).build());

		response.getDetails().add(GamesItem.builder().id("10001").info(BannerInfo.builder().description("Solitaire").banner("https://storage.googleapis.com/smartplay-app-images/solitaireicon.png")
        .webUrl("https://play.google.com/store/apps/details?id=com.nonstopclassics.solitairetournament")
        .build()).order(1).build());
		response.getDetails().add(GamesItem.builder().id("10002").info(BannerInfo.builder().description("Ludo").banner("https://storage.googleapis.com/smartplay-app-images/ludoicon.png")
        .webUrl("https://play.google.com/store/apps/details?id=com.goodtimegames.ludoloyalty")
        .build()).order(2).build());

        return response;
    }

    @Override
    public long getTimerDuration() {
        return TIMER_WINDOW_IN_SECONDS;
    }

    @Override
    public BigDecimal getMultiplier() {
        return new BigDecimal("0.50");
    }

    @Override
    public BigDecimal getCurrencyConversionRate(Currency source, Currency to) {
        if( source == Currency.USD && to == Currency.INR){
            return new BigDecimal(USD_TO_INR_MULTIPLIER);
        }
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getCurrencyConversionRate'");
    }

    @Override
    public String getBillerFirstname() {
        return "SumanB";
    }

    @Override
    public String getBillerPhoneNumber() {
        return "+919818236314";
    }

    @Override
    public String getBillerEmail() {
        return "admin@smartplay.fun";
    }

    @Override
    public String getBillerCountry() {
        return "IN";
    }

}
