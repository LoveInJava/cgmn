package com.smartplay.apiservices.services.impl;

import java.time.Duration;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.google.firebase.messaging.AndroidConfig;
import com.google.firebase.messaging.AndroidNotification;
import com.google.firebase.messaging.ApnsConfig;
import com.google.firebase.messaging.Aps;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.Notification;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.smartplay.apiservices.models.request.FCMNotificationRequest;
import com.smartplay.apiservices.models.response.FCMNotificationResponse;
import com.smartplay.apiservices.services.interfaces.INotificationFCMService;

/**
 * Class @RuleConfigService represents a rule config service that handles
 * configuration rule.
 */
@Service
public class NotificationFCMService implements INotificationFCMService {
    private Logger logger = LoggerFactory.getLogger(NotificationFCMService.class);

    @Override
    public FCMNotificationResponse sendNotification(FCMNotificationRequest request) {

        Message message = getPreconfiguredMessageToToken(request);
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        String jsonOutput = gson.toJson(message);
        FCMNotificationResponse response = null;
        try {
            String strRresponse = sendAndGetResponse(message);
            response = new FCMNotificationResponse();
            response.setMessage(strRresponse);
            response.setStatus(200);
        } catch (InterruptedException | ExecutionException e) {
            response = null;
            e.printStackTrace();
        }
        logger.info("Sent message to token. Device token: " + request.getToken() + ", " + response + " msg " + jsonOutput);

        return response;
    }

    private Message getPreconfiguredMessageToToken(FCMNotificationRequest request) {
        return getPreconfiguredMessageBuilder(request).setToken(request.getToken())
                .build();
    }

    private Message.Builder getPreconfiguredMessageBuilder(FCMNotificationRequest request) {
        AndroidConfig androidConfig = getAndroidConfig(request.getTopic(), request.getChannel_id());
        ApnsConfig apnsConfig = getApnsConfig(request.getTopic());
        Notification notification = Notification.builder()
                .setTitle(request.getTitle())
                .setBody(request.getBody())
                .build();
        return Message.builder()
                .setApnsConfig(apnsConfig).setAndroidConfig(androidConfig).setNotification(notification);
    }

    private AndroidConfig getAndroidConfig(String topic, String androidChannelId) {
        return AndroidConfig.builder()
                .setTtl(Duration.ofMinutes(2).toMillis()).setCollapseKey(topic)
                .setPriority(AndroidConfig.Priority.HIGH)
                .setNotification(AndroidNotification.builder().setChannelId(androidChannelId)
                        .setTag(topic).build())
                .build();
    }

    private ApnsConfig getApnsConfig(String topic) {
        return ApnsConfig.builder()
                .setAps(Aps.builder().setCategory(topic).setThreadId(topic).build()).build();
    }

    private String sendAndGetResponse(Message message) throws InterruptedException, ExecutionException {
        return FirebaseMessaging.getInstance().sendAsync(message).get();
    }

}
