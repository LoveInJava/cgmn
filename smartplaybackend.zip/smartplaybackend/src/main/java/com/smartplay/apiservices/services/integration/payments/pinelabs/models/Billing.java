package com.smartplay.apiservices.services.integration.payments.pinelabs.models;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class Billing {
    private String firstname;
    private String lastname;
    private String email;
    // @E164
    private String telephone;
    private String line1;
    private String line2;
    private String city;
    private String region;
    private String country;
    private String postcode;
    private String company;
}
