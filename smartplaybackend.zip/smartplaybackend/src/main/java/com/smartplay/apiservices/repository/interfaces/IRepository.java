package com.smartplay.apiservices.repository.interfaces;


import java.util.List;
import java.util.function.Predicate;

@SuppressWarnings("java:S119")
public interface IRepository<T, ID> {
    T add(T entity);
    T get(ID id);
    T update(T entity);
    void delete(ID id);
    List<T> getAll();
    List<T> getAllWithLogging();
    T save(T entity);

    List<T> filter(Predicate<T> predicate);
    boolean exists(Predicate<T> predicate);
}
