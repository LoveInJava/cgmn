package com.smartplay.apiservices.services.interfaces;

import com.smartplay.apiservices.models.request.RevenueDetailsRequest;

/**
 * Interface @IRevenueReportService represents the contract for Revenue related
 * operations service.
 */
public interface IAdRevenueService {

  /**
   * Handles the submission of a valid Revenue Details Request.
   *
   * @RequestBody revenueDetailsRequest.
   * @Return RevenueDetailsResponse If the Revenue details request is persist
   *         Successfully.
   */
  void save(RevenueDetailsRequest revenueDetailsRequest);

}
