package com.smartplay.apiservices.models.validators;

import org.springframework.util.ObjectUtils;

import com.smartplay.apiservices.models.request.MobileRegistrationRequest;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class RegistrationRequestValidator
        implements ConstraintValidator<ValidRegistrationRequest, MobileRegistrationRequest> {

    @Override
    public boolean isValid(MobileRegistrationRequest request, ConstraintValidatorContext context) {

        return  !ObjectUtils.isEmpty(request) && !ObjectUtils.isEmpty(request.getMobile()) && request.getMobile().matches(MobileRegistrationRequest.MOBILE_REGEX);
    }
}
