package com.smartplay.apiservices.services.interfaces;

public interface IPinelabTokenService {
    String getToken();
    String refreshToken();
    String generateNewJwtToken();
    String getBearerTokenString();
}
