package com.smartplay.apiservices.models.data;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.smartplay.apiservices.models.enums.VerificationStatus;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class VerificationInformation implements Serializable{
    private VerificationStatus verificationStatus;
    private LocalDateTime datetime;
    private String verificationCode;
}
