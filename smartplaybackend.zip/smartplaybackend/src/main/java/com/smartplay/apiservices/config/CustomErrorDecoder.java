package com.smartplay.apiservices.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.smartplay.apiservices.services.interfaces.IPinelabTokenService;
import com.smartplay.apiservices.tools.JsonUtil;

import feign.Response;
import feign.RetryableException;
import feign.codec.ErrorDecoder;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CustomErrorDecoder implements ErrorDecoder {

    private final IPinelabTokenService pinelabTokenService;

    public CustomErrorDecoder( @Autowired @Lazy IPinelabTokenService pinelabTokenService) {
        this.pinelabTokenService = pinelabTokenService;
    }

    @Override
    public Exception decode(String methodKey, Response response) {
        log.debug("Catched Feign client error {}, {}", methodKey, response);

        System.out.println("Response : "+response);
        System.out.println("Response status : "+response.status());


        switch (response.status()) {
            case 403:
                pinelabTokenService.refreshToken();
            case 401:

            pinelabTokenService.refreshToken();
                if(JsonUtil.tryDeserializeToTokenErrorResponse(response)!=null){
                    TokenErrorResponse tokenErrorResponse = JsonUtil.tryDeserializeToTokenErrorResponse(response);
                    if(tokenErrorResponse!=null && tokenErrorResponse.getCode()==401 && tokenErrorResponse.getMessage().equals("oauth_problem=token_rejected")){
                        pinelabTokenService.refreshToken();
                        System.out.println("Refreshign token since : received, 401 with oauth_problem=token_rejected ");    
                    }
                }
                return new RetryableException(
                    response.status(),
                    "Retryable exception",
                    response.request().httpMethod(),
                    10L,
                    response.request()
                );
            default:
                return new RuntimeException(response.reason());
        }
    }
}