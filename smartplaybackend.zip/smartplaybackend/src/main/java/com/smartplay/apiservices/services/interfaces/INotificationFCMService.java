package com.smartplay.apiservices.services.interfaces;

import com.smartplay.apiservices.models.request.FCMNotificationRequest;
import com.smartplay.apiservices.models.response.FCMNotificationResponse;

/**
 * Interface @INotificationFCMService represents the contract for sending Notification.
 */
public interface INotificationFCMService {

     FCMNotificationResponse sendNotification(FCMNotificationRequest notificationRequest);

}
