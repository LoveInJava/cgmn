1. static api's
 -  GET /api/about
 -  GET /api/faq
 -  GET /api/games
 -  GET /api/privacypolicy
 -  GET /api/rewards
 -  GET /api/news
2. Temporary maintenance api
 -  GET /api/hello/name
 -  GET /api/data/reset
3. registration api
4. OTP verification api
