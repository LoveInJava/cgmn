package com.smartplay.apiservices.models.data;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.UUID;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverted;
import com.smartplay.apiservices.tools.converters.LocalDateTimeConverter;
import com.smartplay.apiservices.tools.converters.UUIDConverter;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;


@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@NotNull
@EqualsAndHashCode(callSuper=false)
@DynamoDBTable(tableName = "UserTimer")
public class UserTimer implements Serializable {

    private static final long serialVersionUID = 1L;

    @DynamoDBTypeConverted(converter = UUIDConverter.class)
    private UUID timerId;
    
    @DynamoDBHashKey(attributeName = "lpaId")
    private String lpaId;

    @DynamoDBTypeConverted(converter = LocalDateTimeConverter.class)
    private LocalDateTime startTime;

    /**
     * The duration of the user timer in seconds.
     */
    private long duration;

    @DynamoDBTypeConverted(converter = LocalDateTimeConverter.class)
    private LocalDateTime endTime;
}
