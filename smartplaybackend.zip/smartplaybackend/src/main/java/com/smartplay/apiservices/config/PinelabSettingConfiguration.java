package com.smartplay.apiservices.config;
import org.springframework.beans.factory.annotation.Value;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class PinelabSettingConfiguration {
    @Value("${qwikgifts.api.clientid}")
    private String clientId;
    @Value("${qwikgifts.api.clientSecret}")
    private String clientSecret;
    @Value("${qwikgifts.api.username}")
    private String username;
    @Value("${qwikgifts.api.password}")
    private String password;
}
