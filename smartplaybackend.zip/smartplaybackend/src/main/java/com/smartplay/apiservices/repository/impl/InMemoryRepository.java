package com.smartplay.apiservices.repository.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

import org.springframework.stereotype.Repository;

import com.smartplay.apiservices.repository.interfaces.IIdentifiable;
import com.smartplay.apiservices.repository.interfaces.IInMemoryRepository;

import lombok.extern.slf4j.Slf4j;

@Repository
@SuppressWarnings({"java:S119"})
@Slf4j
public class InMemoryRepository<T extends IIdentifiable<Id>,Id> implements IInMemoryRepository<T,Id> {
    private Map<Id, T> entities = new HashMap<>();

    @Override
    public T add(T entity) {
        return this.update(entity);
    }

    @Override
    public T get(Id id) {
        return entities.get(id);
    }

    @Override
    public T update(T entity) {
        entities.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public void delete(Id id) {
        entities.remove(id);
    }

    @Override
    public List<T> getAll() {
        // return entities.values().stream()
        //         .toList();
        return new ArrayList<>(entities.values());
    }

    @Override
    public List<T> getAllWithLogging() {
        List<T> result1= new ArrayList<>();
        try{
            logit("BEFORE: entities.values: %s", result1);   
            result1= entities.values().stream()
            .toList();
            logit("AFTER: entities.values: %s", result1);
            
        }catch(Exception e){
            logit("exception : entities.values: %s", e.getMessage());
        }

        try{
            logit("BEFORE: ArrayList<>(entities.values()): %s", result1);   
            var result2= new ArrayList<>(entities.values());
            logit("AFTER: ArrayList<>(entities.values()): %s", result2);
            return result2;
        }catch(Exception e){
            logit("EXCEPTION: ArrayList<>(entities.values()) : %s", e.getMessage());
            return result1;
        }
        
        // return new ArrayList<>(entities.values());
    }

    private void logit(String format, Object arg){
		String logMessage = String.format(format, arg);
		System.out.println( logMessage);
		log.info(format, arg);
		log.error(format, arg);
	}

	private void logit(String format, Object arg, Object arg2){
		String logMessage = String.format(format, arg, arg2);
		System.out.println( logMessage);
		log.info(format, arg, arg2);
		log.error(format, arg, arg2);
	}

    @Override
    public T save(T entity) {
        if (this.get(entity.getId())!= null)
            return update(entity);

        return add(entity);
    }

    @Override
    public List<T> filter(Predicate<T> predicate) {
        return entities.values().stream()
                .filter(predicate)
                .toList();
    }

    @Override
    public boolean exists(Predicate<T> predicate) {
        return entities.values().stream()
                .anyMatch(predicate);
    }

    @Override
    public void reset() {
        entities.clear();
    }

}
