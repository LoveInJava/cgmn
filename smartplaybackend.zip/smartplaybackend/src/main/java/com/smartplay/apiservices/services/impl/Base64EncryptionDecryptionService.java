package com.smartplay.apiservices.services.impl;

import java.util.Base64;

import org.springframework.stereotype.Service;

import com.smartplay.apiservices.services.interfaces.IEncryptionDecryptionService;

@Service(value = Base64EncryptionDecryptionService.SERVICE_NAME)
public class Base64EncryptionDecryptionService implements IEncryptionDecryptionService {

    public static final String SERVICE_NAME = "base64EncryptionDecryptionService";

	 // Encrypts the given plain text using Base64 encoding
    @Override
	public String encrypt(String plainText) {
        byte[] bytes = plainText.getBytes();
        byte[] encodedBytes = Base64.getEncoder().encode(bytes);
        return new String(encodedBytes);
    }

    // Decrypts the given Base64 encoded string to plain text
    @Override
	public String decrypt(String encryptedText) {
        byte[] decodedBytes = Base64.getDecoder().decode(encryptedText);
        return new String(decodedBytes);
    }
}
