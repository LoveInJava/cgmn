package com.smartplay.apiservices.repository.interfaces;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.smartplay.apiservices.models.data.PinelabsProduct;

@Repository
@EnableScan
public interface IPinelabsProductRepository extends CrudRepository<PinelabsProduct, String> {

}