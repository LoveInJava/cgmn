package com.smartplay.apiservices.controller;

import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartplay.apiservices.models.request.FCMNotificationRequest;
import com.smartplay.apiservices.models.response.FCMNotificationResponse;
import com.smartplay.apiservices.services.interfaces.INotificationFCMService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1")
@Tag(name = "FCM Notification", description = "Api's for FCM Notification")
@Slf4j
public class NotificationController {

    private final INotificationFCMService notificationFCMService;

    public NotificationController(@Autowired INotificationFCMService notificationFCMService) {
        this.notificationFCMService = notificationFCMService;
    }

    @PostMapping("fcm/notification")
    @Operation(summary = "FCM Notification")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "send Notification", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = FCMNotificationResponse.class)) }),
            @ApiResponse(responseCode = "400", description = "Internal server error", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class)) }) })
    public ResponseEntity<FCMNotificationResponse> sendFCMNotification(
            @RequestBody @Valid FCMNotificationRequest notificationRequest) {

        logit("FCM Notification Request: {} @ FCMNotificationRequest , FCM Notification Request details : ",
                notificationRequest);

        FCMNotificationResponse notificationResponse = notificationFCMService.sendNotification(notificationRequest);

        return ResponseEntity.ok(notificationResponse);
    }

    private void logit(String format, Object arg) {
        String logMessage = String.format(format, arg);
        System.out.println(logMessage);
        log.info(format, arg);
        log.error(format, arg);
    }
}
