package com.smartplay.apiservices.services.integration.payments.pinelabs.models;

import lombok.Data;

@Data
public class Page {
    private Page page;
    private MetaInformation meta;
    private Canonical canonical;
}
