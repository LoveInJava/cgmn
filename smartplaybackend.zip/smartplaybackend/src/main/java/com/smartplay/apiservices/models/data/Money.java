package com.smartplay.apiservices.models.data;

import java.math.BigDecimal;

import com.smartplay.apiservices.models.enums.Currency;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@NotNull
@EqualsAndHashCode(callSuper=false)
public class Money {
    private BigDecimal amount;
    private Currency currency;
}
