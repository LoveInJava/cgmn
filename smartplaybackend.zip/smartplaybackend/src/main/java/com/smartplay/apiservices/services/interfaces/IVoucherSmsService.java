package com.smartplay.apiservices.services.interfaces;

public interface IVoucherSmsService {
    public void sendSms(String phoneNumber,String message);
}
