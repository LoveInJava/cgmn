package com.smartplay.apiservices.services.interfaces;

import com.smartplay.apiservices.exceptions.InvalidPhoneNumberException;
import com.smartplay.apiservices.exceptions.InvalidVerificationCodeException;
import com.smartplay.apiservices.exceptions.PhoneNumberAlreadyRegisteredException;
import com.smartplay.apiservices.exceptions.PhoneNumberAlreadyVerifiedException;
import com.smartplay.apiservices.models.data.LpaUser;
import com.smartplay.apiservices.models.response.RegistrationStatus;


/**
 * Interface @IRegistrationService represents the contract for registration-related operations service that handles user registration and verification.
 */
public interface IRegistrationService {

     /**
      * Handles a registration request for the given phone number and device ID.
      *
      * @param phoneNumber The phone number to register.
      * @param deviceId    The device ID associated with the registration.
      * @throws InvalidPhoneNumberException         If the phone number is invalid.
      * @throws PhoneNumberAlreadyRegisteredException If the phone number is already registered.
      * @throws PhoneNumberAlreadyVerifiedException If the phone number is already verified.
      */
     LpaUser handleRegistrationRequest(String phoneNumber, String deviceToken, String deviceId);

     /**
      * Handles the submission of a verification code for the given phone number.
      *
      * @param phoneNumber      The phone number to verify.
      * @param verificationCode The verification code to submit.
      * @throws InvalidVerificationCodeException If the verification code is invalid.
      */
     LpaUser handleVerificationCodeSubmission(String phoneNumber, String deviceId, String verificationCode);

     /**
      * Get registration status for the given phone number and device ID.
      *
      * @param phoneNumber The phone number to check.
      * @param deviceId    The device ID to check.
      * @return The registration status.
      */
     RegistrationStatus getRegistrationStatus(String phoneNumber, String deviceId);

     /**
      * Get registration status for the device ID.
      *
      * @param lpaId The LPA ID to check.
      * @param deviceId    The device ID to check.
      * @return The registration status.
      */
     RegistrationStatus getRegistrationStatusByLpaIdDeviceId(String lpaId, String deviceId);

     /**
      * Handles the resending of an OTP verification code for the given phone number.
      *
      * @param phoneNumber The phone number to resend the OTP verification code.
      */
     LpaUser handleResendOtpVerificationCode(String phoneNumber, String deviceId);

     RegistrationStatus generateStatusByLpaUser(LpaUser user, String deviceId);

     LpaUser getRegistrationStatusByDeviceid(String deviceId);
     LpaUser getRegistrationStatusByMobile(String mobile);
     LpaUser getRegistrationStatusByLpaid(String lpaId);

     String getOtpByDeviceId(String deviceId);

}
