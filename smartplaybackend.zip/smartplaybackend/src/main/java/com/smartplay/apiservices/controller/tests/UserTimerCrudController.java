package com.smartplay.apiservices.controller.tests;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartplay.apiservices.models.data.UserTimer;
import com.smartplay.apiservices.repository.interfaces.IUserTimerRepository;

@RequestMapping("/api/db/usertimer")
@RestController
public class UserTimerCrudController extends BaseCrudController<UserTimer, String, IUserTimerRepository> {

}
