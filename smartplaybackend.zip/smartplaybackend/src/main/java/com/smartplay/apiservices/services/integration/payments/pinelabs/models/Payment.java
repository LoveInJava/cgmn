package com.smartplay.apiservices.services.integration.payments.pinelabs.models;


import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class Payment {
    @Builder.Default
    @Setter(AccessLevel.PRIVATE)
    private String code="svc";
    private int amount;
}
