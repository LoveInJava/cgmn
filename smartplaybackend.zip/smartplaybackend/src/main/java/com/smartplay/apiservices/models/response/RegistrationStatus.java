package com.smartplay.apiservices.models.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class RegistrationStatus{
    private boolean isMobileRegistered;
    private boolean isVerified;
    private boolean isDeviceRegistered;
    private String lpaId;
    private String username;
    private Integer isNewUser;
    private String userTimerId;
}
