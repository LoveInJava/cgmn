package com.smartplay.apiservices.models.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@NotNull
public class VoucherOrderRequest {

    @NotNull(message = "Product SKU is required")
    @NotEmpty(message = "Product SKU must not be empty")
    @JsonProperty("productsku")
    private String productSKU;

    @NotNull(message = "Denomination is required")
    @Min(value = 1, message = "Denomination must be greater than zero")
    private int denomination;

    private String fullName;
    private String email;

}
