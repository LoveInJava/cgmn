package com.smartplay.apiservices.services.interfaces;

import java.io.IOException;
import java.util.List;

public interface IResourceService {
    List<String> readLinesFromResource(String resourceName) throws IOException;
}
