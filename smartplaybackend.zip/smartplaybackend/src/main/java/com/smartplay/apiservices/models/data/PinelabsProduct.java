package com.smartplay.apiservices.models.data;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverted;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.ProductResponse;
import com.smartplay.apiservices.tools.converters.ProductResponseConverter;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@SuperBuilder
@NoArgsConstructor
@Data
@DynamoDBTable(tableName = "PinelabsProduct")
public class PinelabsProduct {
    private String id;
    @DynamoDBHashKey(attributeName = "sku")
    private String sku;
    private String categoryId;
    @DynamoDBTypeConverted(converter = ProductResponseConverter.class)
    private ProductResponse productDetails;
}
