package com.smartplay.apiservices.services.mappers;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.smartplay.apiservices.models.response.PurchasedVoucher;
import com.smartplay.apiservices.models.response.PurchasedVoucherResponse;


@Mapper
public interface PurchasedVoucherMapper {

    PurchasedVoucherMapper INSTANCE = Mappers.getMapper(PurchasedVoucherMapper.class);

    @Mapping(source = "id", target = "id")
    @Mapping(source = "lpaId", target = "lpaId")
    @Mapping(source = "purchasedOn", target = "purchasedOn", qualifiedByName = "localDateTimeToString")
    PurchasedVoucherResponse toResponse(PurchasedVoucher purchasedVoucher);

    public List<PurchasedVoucherResponse> toResponseList(List<PurchasedVoucher> purchasedVouchers);


    @Named("localDateTimeToString")
    public static String localDateTimeToString(LocalDateTime dateTime) {
        return dateTime != null ? dateTime.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) : null;
    }

}
