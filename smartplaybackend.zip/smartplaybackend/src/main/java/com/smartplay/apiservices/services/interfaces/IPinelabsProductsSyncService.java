package com.smartplay.apiservices.services.interfaces;

import java.util.List;

import com.smartplay.apiservices.models.data.PinelabsProduct;

public interface IPinelabsProductsSyncService {
    void initiateSync();
    void clear();
    List<PinelabsProduct> getAll();
}
