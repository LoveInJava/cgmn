package com.smartplay.apiservices.models.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum VerificationStatus{
    NOTVERIFIED("NotVerified"),
    VERIFICATIONINITIATED("VerificationInitiated"),
    VERIFIED("Verified"),
    VERIFICATIONFAILED("VerificationFailed");

    public final String label;

    @Override
    public String toString() {
        return this.label;
    }
}
