package com.smartplay.apiservices.services.interfaces;

import com.smartplay.apiservices.models.data.LpaUser;

public interface IUserRegistrationService {
    boolean isPhoneNumberValid(String phoneNumber);
    boolean isPhoneNumberRegistered(String phoneNumber);
    boolean isPhoneNumberVerified(String phoneNumber);
    boolean isDeviceRegistered(String deviceId);
    String generateVerificationCode();
    LpaUser saveRegistrationRequest(LpaUser user);
    boolean validateOtp(String phoneNumber, String verificationCode);
    LpaUser updateOtpVerificationStatus(String phoneNumber, String deviceId, boolean otpVerificationStatus);
    String getLpaId(String phoneNumber);
    String getUsername(String phoneNumber);

    LpaUser getByLpaId(String lpaId);
    LpaUser getByLpaIdDeviceId(String lpaId, String deviceId);
    LpaUser getByPhoneNumberDeviceId(String phoneNumber, String deviceId);
    LpaUser getByDeviceId(String deviceId);
    LpaUser getByPhoneNumber(String phoneNumber);

    String getOtpByDeviceId(String deviceId);
    boolean exists(String username);
}
