package com.smartplay.apiservices.config;
import java.io.IOException;

import feign.Client;
import feign.Request;
import feign.Response;
import feign.Util;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LoggingFeignClient implements Client {

    private final Client delegate;

    public LoggingFeignClient(Client delegate) {
        this.delegate = delegate;
    }

    @Override
    public Response execute(Request request, Request.Options options) throws IOException {
        Response response = delegate.execute(request, options);

        if (response.body() != null) {
            byte[] bodyData = Util.toByteArray(response.body().asInputStream());
            log.info("Response body: {}", new String(bodyData, Util.UTF_8));
            return response.toBuilder().body(bodyData).build();
        }

        return response;
    }
}