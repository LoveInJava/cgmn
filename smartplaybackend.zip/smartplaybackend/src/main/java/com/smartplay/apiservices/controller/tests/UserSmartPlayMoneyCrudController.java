package com.smartplay.apiservices.controller.tests;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartplay.apiservices.models.data.UserSmartPlayMoney;
import com.smartplay.apiservices.repository.interfaces.IUserSmartPlayMoneyRepository;

@RequestMapping("/api/db/usersmartplaymoney")
@RestController
public class UserSmartPlayMoneyCrudController extends BaseCrudController<UserSmartPlayMoney, String, IUserSmartPlayMoneyRepository> {

}
