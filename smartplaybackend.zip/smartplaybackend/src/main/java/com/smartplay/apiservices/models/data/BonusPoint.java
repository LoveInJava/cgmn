package com.smartplay.apiservices.models.data;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Data
@DynamoDBTable(tableName = "BonusPoint")
public class BonusPoint {

    @DynamoDBHashKey(attributeName = "lpaId")
    private String lpaId;
    private String deviceId;
    private Integer bonusPoint;
    private Integer welcomeBonusPoint;
    private Integer targetPoint;
    private Integer isNewUser;
    private Integer isBonusPointAdd;
}
