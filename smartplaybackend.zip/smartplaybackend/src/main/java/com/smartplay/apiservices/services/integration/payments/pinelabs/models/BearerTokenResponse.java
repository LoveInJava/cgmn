package com.smartplay.apiservices.services.integration.payments.pinelabs.models;

import lombok.Data;

@Data
public class BearerTokenResponse {
    private String token;
}