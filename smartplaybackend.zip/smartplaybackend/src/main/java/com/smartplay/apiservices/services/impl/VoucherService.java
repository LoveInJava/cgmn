package com.smartplay.apiservices.services.impl;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.io.BigDecimalParser;
import com.smartplay.apiservices.exceptions.InvalidRequestBadPayload;
import com.smartplay.apiservices.models.data.CashoutOrder;
import com.smartplay.apiservices.models.data.Money;
import com.smartplay.apiservices.models.data.PinelabPurchasedVoucher;
import com.smartplay.apiservices.models.data.PinelabsProduct;
import com.smartplay.apiservices.models.enums.Currency;
import com.smartplay.apiservices.models.request.VoucherOrderRequest;
import com.smartplay.apiservices.models.response.Cashout;
import com.smartplay.apiservices.models.response.PurchasedVoucher;
import com.smartplay.apiservices.repository.interfaces.IPinelabsProductRepository;
import com.smartplay.apiservices.repository.interfaces.IPurchasedVoucherRepository;
import com.smartplay.apiservices.repository.interfaces.IUserSmartPlayMoneyRepository;
import com.smartplay.apiservices.services.helpers.UserSmartPlayMoneyHelper;
import com.smartplay.apiservices.services.integration.payments.pinelabs.interfaces.IPinelabsApiService;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.response.OrderResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.response.OrderResponse.Card;
import com.smartplay.apiservices.services.interfaces.IMapper;
import com.smartplay.apiservices.services.interfaces.IVoucherService;

@Service
public class VoucherService implements IVoucherService {

    // private final IInMemoryRepository<PurchasedVoucher,String>
    // purchasedVoucherRepository;
    // private final IInMemoryRepository<VoucherProduct, String>
    // voucherProductRepository;

    private final IPurchasedVoucherRepository pinelabPurchasedVoucherRepository;

    private final IMapper mapper;
    private final IPinelabsApiService productService;
	private final TimerService	timerService;

    private final IPinelabsProductRepository pinelabsProductRepository;
    private final IUserSmartPlayMoneyRepository smartplayMoneyRepository;

    public VoucherService(
            // @Autowired IInMemoryRepository<PurchasedVoucher,String>
            // purchasedVoucherRepository,
            // @Autowired IInMemoryRepository<VoucherProduct, String>
            // voucherProductRepository,
            IPurchasedVoucherRepository pinelabPurchasedVoucherRepository,
            @Autowired IMapper mapper,
            @Autowired IPinelabsApiService productService,
            @Autowired TimerService	timerService,
            @Autowired IPinelabsProductRepository pinelabsProductRepository,
            @Autowired IUserSmartPlayMoneyRepository smartplayMoneyRepository) {
        // this.purchasedVoucherRepository = purchasedVoucherRepository;
        // this.voucherProductRepository = voucherProductRepository;
        this.pinelabPurchasedVoucherRepository = pinelabPurchasedVoucherRepository;
        this.mapper = mapper;
        this.productService = productService;
        this.timerService = timerService;
        this.pinelabsProductRepository = pinelabsProductRepository;
        this.smartplayMoneyRepository = smartplayMoneyRepository;
    }

    public List<PurchasedVoucher> getPurchasedVoucherByLpaId(String lpaId) {

        var vouchers = pinelabPurchasedVoucherRepository.findById(lpaId).orElse(
                com.smartplay.apiservices.models.data.PurchasedVoucher.builder().build());

        return mapper.mapResponse(vouchers.getRecords());
    }

    @Override
    public PinelabPurchasedVoucher orderVoucher(VoucherOrderRequest orderRequest, String lpaId, String deviceId) {
        // @TODO: 1. validate request
        // @TODO: 2. verify request
        // @TODO: 3. map request to ProviderSpecificRequest
        // @TODO: 4. call provider api (place order)
        // 5. make db data mapping
        // 6. make db entries
        // 7. send response (NO ACTION)

        PinelabsProduct product = pinelabsProductRepository.findById(orderRequest.getProductSKU()).orElse(null);

        System.out.println("request denomination " + orderRequest.getDenomination());
        System.out.println("available denomination " + product.getProductDetails().getPrice().getDenominations());

        var requestdenomination = Integer.toString(orderRequest.getDenomination());

        product.getProductDetails().getPrice().getDenominations().stream()
                .filter(denomination -> denomination.equals(requestdenomination)).findFirst()
                .orElseThrow(InvalidRequestBadPayload::new);

        if (ObjectUtils.isArray(product)) {
            throw new InvalidRequestBadPayload();
        }

        String voucherName = product.getProductDetails().getName();

        var smartPlayMoney = smartplayMoneyRepository.findById(lpaId).orElseThrow(InvalidRequestBadPayload::new);

        Cashout availableCash = UserSmartPlayMoneyHelper.getAvailableCash(null, null, smartPlayMoney);
        if (availableCash.getAmount().compareTo(BigDecimal.valueOf(orderRequest.getDenomination())) < 0) {
            throw new InvalidRequestBadPayload();
        }

        smartPlayMoney.getCashouts()
                .add(CashoutOrder.builder().money(Money.builder()
                        .amount(BigDecimal.valueOf(orderRequest.getDenomination())).currency(Currency.INR).build())
                        .timerId(timerService.getTimer(lpaId).getTimerId().toString())
                        .startTime(timerService.getTimer(lpaId).getStartTime())
                        .endTime(timerService.getTimer(lpaId).getEndTime())
                        .timestamp(LocalDateTime.now())
                        .build());

        OrderResponse orderResponse = this.productService.placeOrder(lpaId, voucherName, orderRequest.getProductSKU(),
                orderRequest.getDenomination(), 1, orderRequest.getEmail());

        System.out.println("OrderResponse : " + orderResponse);
        PinelabPurchasedVoucher purchasedVoucher = new PinelabPurchasedVoucher();

        if(orderResponse != null) {

            if(orderResponse.getCards() != null) {
                Optional<Card> cards = orderResponse.getCards().stream().findFirst();

                if (cards.isPresent()) {
                    Card card = cards.get();
                    purchasedVoucher.setAmount(BigDecimalParser.parse(card.getAmount()));
                    purchasedVoucher.setSku(card.getSku());
                    purchasedVoucher.setValidity(card.getValidity());
                    purchasedVoucher.setVoucherName(card.getProductName());
                    purchasedVoucher.setStatus(orderResponse.getStatus());

                }
            }else{
                purchasedVoucher.setAmount(new BigDecimal(BigInteger.ZERO));
                purchasedVoucher.setSku(orderRequest.getProductSKU());
                purchasedVoucher.setValidity("Activated");
                purchasedVoucher.setVoucherName("Activated");
                purchasedVoucher.setStatus(orderResponse.getStatus());

            }
            System.out.println("Order placed successfully");
        }else{
            System.out.println("Order not placed successfully");
            purchasedVoucher.setAmount(new BigDecimal(BigInteger.ZERO));
            purchasedVoucher.setSku(orderRequest.getProductSKU());
            purchasedVoucher.setValidity("NA");
            purchasedVoucher.setVoucherName("NA");
            purchasedVoucher.setStatus("Fail");
        }
        smartplayMoneyRepository.save(smartPlayMoney);
        return purchasedVoucher;
    }
}
