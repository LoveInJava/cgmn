package com.smartplay.apiservices.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.smartplay.apiservices.services.interfaces.IEncryptionDecryptionService;

@Primary
@Service(value = CertificateBasedEncryptionDecryptionService.SERVICE_NAME)
public class CertificateBasedEncryptionDecryptionService implements IEncryptionDecryptionService {

    public static final String SERVICE_NAME = "certificateBasedEncryptionDecryptionService";
    private final IEncryptionDecryptionService encryptionDecryptionService;

    public CertificateBasedEncryptionDecryptionService(@Autowired @Qualifier(PlainNoEncryptionNoDecryptionService.SERVICE_NAME) IEncryptionDecryptionService encryptionDecryptionService) {
        this.encryptionDecryptionService = encryptionDecryptionService;
    }

    @Override
    public String encrypt(String plainText) {
        return encryptionDecryptionService.encrypt(plainText);
    }

    @Override
    public String decrypt(String encryptedText) {
        return encryptionDecryptionService.decrypt(encryptedText);
    }

}
