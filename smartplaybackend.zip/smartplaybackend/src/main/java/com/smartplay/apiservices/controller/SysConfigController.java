package com.smartplay.apiservices.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartplay.apiservices.models.request.RuleConfigRequest;
import com.smartplay.apiservices.models.response.RuleConfigResponse;
import com.smartplay.apiservices.services.interfaces.IRuleConfigService;
import com.smartplay.apiservices.tools.VerifyConfigHeaderToParamPayload;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1")
@Tag(name = "Rule Configuration", description = "Api's for rule configuration")
@Slf4j
public class SysConfigController {

    private final IRuleConfigService ruleConfigService;

    public SysConfigController(@Autowired IRuleConfigService ruleConfigService) {
        this.ruleConfigService = ruleConfigService;
    }

    @PostMapping("config/rule/{config-id}")
    @Operation(summary = "Rule Configuration")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "rule config response", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = RuleConfigResponse.class)) }),
            @ApiResponse(responseCode = "400", description = "Internal server error", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class)) }) })
    @VerifyConfigHeaderToParamPayload(headerConfigId = "config-id", paramConfigId = "config-id")
    public ResponseEntity<RuleConfigResponse> ruleConfigurations(
            @Parameter(description = "Config Id For Rule") @RequestHeader("config-id") String headerConfigId,
            @Parameter(description = "Config id") @PathVariable("config-id") String paramConfigId,
            @RequestBody @Valid RuleConfigRequest ruleConfigRequest) {

        logit("Rule Request: {} @ RuleRequest , Rule Request details : ", ruleConfigRequest);

        RuleConfigResponse ruleConfigResponse = ruleConfigService.saveRuleConfiguration(ruleConfigRequest);
        return ResponseEntity.ok(ruleConfigResponse);
    }

    @GetMapping("config/rule/value/{config-id}")
    @Operation(summary = "Rule Configuration")
    @VerifyConfigHeaderToParamPayload(headerConfigId = "config-id", paramConfigId = "config-id")
    public ResponseEntity<RuleConfigResponse> getRuleConfiguration(
            @Parameter(description = "Config Id For Rule") @RequestHeader("config-id") String headerConfigId,
            @Parameter(description = "Config id") @PathVariable("config-id") String paramConfigId) {

        logit("Rule Config id: {} @ RuleRequest , Rule Config id : ", paramConfigId);

        RuleConfigResponse ruleConfigResponse = ruleConfigService.getsaveRuleConfigurationById(paramConfigId);
        return ResponseEntity.ok(ruleConfigResponse);
    }

    private void logit(String format, Object arg) {
        String logMessage = String.format(format, arg);
        System.out.println(logMessage);
        log.info(format, arg);
        log.error(format, arg);
    }
}
