// package com.smartplay.apiservices.services.impl;

// import org.hibernate.validator.constraints.UUID;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Service;
// import org.springframework.transaction.annotation.Transactional;

// import com.smartplay.apiservices.models.events.ResetTimerEvent;
// import com.smartplay.apiservices.repository.interfaces.IInMemoryRepository;
// import com.smartplay.apiservices.services.interfaces.ICurrentEventService;

// @Service
// public class CurrentEventService implements ICurrentEventService{

//     private final IInMemoryRepository<ResetTimerEvent,UUID> currentEventRepository;
//     private ResetTimerEvent currentEvent;
//     private ResetTimerEvent previousEvent;

//     public CurrentEventService(@Autowired IInMemoryRepository<ResetTimerEvent,UUID> currentEventRepository) {
//         this.currentEventRepository = currentEventRepository;
//     }

//     @Override
//     @Transactional
//     public void setCurrentEvent(ResetTimerEvent event) {

//         currentEventRepository.save(event);
//         previousEvent = currentEvent;
//         currentEvent = event;
//     }

//     @Override
//     public ResetTimerEvent getCurrentEvent() {
//         return currentEvent;
//     }

//     @Override
//     public ResetTimerEvent getPreviousEvent() {
//         return previousEvent;
//     }

// }
