// package com.smartplay.apiservices.jobs;

// import org.quartz.Job;
// import org.quartz.JobExecutionContext;
// import org.quartz.JobExecutionException;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Component;

// import com.smartplay.apiservices.services.impl.PinelabsProductsSyncService;

// @Component
// public class SyncJob implements Job {

//     @Autowired
//     private PinelabsProductsSyncService pinelabsProductsSyncService;

//     @Override
//     public void execute(JobExecutionContext context) throws JobExecutionException {
//         pinelabsProductsSyncService.initiateSync();
//     }
// }