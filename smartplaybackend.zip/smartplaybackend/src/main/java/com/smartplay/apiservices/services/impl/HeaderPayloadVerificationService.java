package com.smartplay.apiservices.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.smartplay.apiservices.services.interfaces.IEncryptionDecryptionService;
import com.smartplay.apiservices.services.interfaces.IHeaderPayloadVerificationService;

@Service
public class HeaderPayloadVerificationService implements IHeaderPayloadVerificationService{

    private final IEncryptionDecryptionService certificateBasedEncryptionDecryptionService;
    private final IEncryptionDecryptionService base64EncryptionDecryptionService;


    public HeaderPayloadVerificationService(
        @Autowired @Qualifier(CertificateBasedEncryptionDecryptionService.SERVICE_NAME) IEncryptionDecryptionService base64EncryptionDecryptionService,
        @Autowired @Qualifier(CertificateBasedEncryptionDecryptionService.SERVICE_NAME) IEncryptionDecryptionService certificateBasedEncryptionDecryptionService) {
        this.certificateBasedEncryptionDecryptionService = certificateBasedEncryptionDecryptionService;
        this.base64EncryptionDecryptionService = base64EncryptionDecryptionService;
    }
    @Override
    public boolean verifyHeaderToParamPayload(String headerDeviceid, String paramDeviceId) {
        String decryptedHeaderDeviceId = certificateBasedEncryptionDecryptionService.decrypt(headerDeviceid);
        String decryptedParamDeviceId = base64EncryptionDecryptionService.decrypt(paramDeviceId);
        return decryptedHeaderDeviceId.equals(decryptedParamDeviceId);
    }

}
