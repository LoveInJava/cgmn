package com.smartplay.apiservices.services.impl;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.smartplay.apiservices.models.response.Currency;

@Service
public class CurrencyService {

    public List<Currency> getCurrencies() {
        return Arrays.asList(
                Currency.builder().id("1").name("INR").symbol("₹").build(),
                Currency.builder().id("2").name("USD").symbol("$").build(),
                Currency.builder().id("3").name("EUR").symbol("€").build(),
                Currency.builder().id("4").name("GBP").symbol("£").build()

            );
    }

    public Currency getDefaultCurrency() {
        return getCurrencyByName("INR");
    }
    public Currency getCurrencyByName(String name) {
        return getCurrencies().stream()
                .filter(currency -> currency.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }

}
