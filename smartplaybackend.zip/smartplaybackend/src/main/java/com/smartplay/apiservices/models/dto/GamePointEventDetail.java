package com.smartplay.apiservices.models.dto;

import com.smartplay.apiservices.models.response.TimeRange;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class GamePointEventDetail {

	private Integer bonus;
	private Integer target;
	private TimeRange time;
}
