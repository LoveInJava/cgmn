package com.smartplay.apiservices.tools.converters;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverter;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.ProductResponse;

public class ProductResponseConverter implements DynamoDBTypeConverter<String, ProductResponse> {
    private static final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public String convert(ProductResponse object) {
        try {
            return objectMapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error converting ProductResponse to String", e);
        }
    }

    @Override
    public ProductResponse unconvert(String object) {
        try {
            return objectMapper.readValue(object, ProductResponse.class);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error converting String to ProductResponse", e);
        }
    }
}
