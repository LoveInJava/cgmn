package com.smartplay.apiservices.config;

import java.time.Instant;
import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.smartplay.apiservices.services.interfaces.IPinelabTokenService;

import feign.RequestInterceptor;
import feign.RequestTemplate;
import lombok.SneakyThrows;

@Component
public class PinelabDynamicHeaderRequestInterceptor implements RequestInterceptor {

    private static final String HEADER_AUTHORIZATION = "Authorization";
    private static final String HEADER_DATE_AT_CLIENT = "dateAtClient";

    private final IPinelabTokenService pinelabTokenService;

    public PinelabDynamicHeaderRequestInterceptor(@Autowired IPinelabTokenService pinelabTokenService) {
        super();
        this.pinelabTokenService = pinelabTokenService;
    }

    @Override
    @SneakyThrows
    public void apply(RequestTemplate template) {
        String authToken = pinelabTokenService.getBearerTokenString();

        System.out.println("Token: " + authToken);

        if (template.headers().containsKey(HEADER_AUTHORIZATION)) {
            template.headers().remove(HEADER_AUTHORIZATION);
            template.header(HEADER_AUTHORIZATION, Collections.emptyList());
        }
        template.header(HEADER_AUTHORIZATION, authToken);

        if (template.headers().containsKey(HEADER_DATE_AT_CLIENT)) {
            template.headers().remove(HEADER_DATE_AT_CLIENT);
            template.header(HEADER_DATE_AT_CLIENT, Collections.emptyList());
        }
        template.header(HEADER_DATE_AT_CLIENT, getDateAtClient());

    }

    private String getDateAtClient() {
        return Instant.now().toString().substring(0, 23) + "Z";
    }
}
