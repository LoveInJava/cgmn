package com.smartplay.apiservices.controller.tests;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartplay.apiservices.models.data.UserAdRevenue;
import com.smartplay.apiservices.repository.interfaces.IUserAdRevenueRepository;

@RequestMapping("/api/db/adrevenue")
@RestController
public class AdRevenueCrudController extends BaseCrudController<UserAdRevenue, String, IUserAdRevenueRepository> {
}
