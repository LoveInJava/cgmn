package com.smartplay.apiservices.services.integration.payments.pinelabs.interfaces;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.smartplay.apiservices.config.FeignConfig;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.AuthorizationCodeRequest;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.AuthorizationCodeResponse;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.BearerTokenRequest;
import com.smartplay.apiservices.services.integration.payments.pinelabs.models.BearerTokenResponse;

@FeignClient(name = "oauth2Client", url ="${qwikgifts.api.url}", configuration = FeignConfig.class)
public interface OAuth2Client {
    @PostMapping("/oauth2/verify")
    AuthorizationCodeResponse getAuthorizationCode(@RequestBody AuthorizationCodeRequest request);

    @PostMapping("/oauth2/token")
    BearerTokenResponse getAccessToken(@RequestBody BearerTokenRequest request);
}