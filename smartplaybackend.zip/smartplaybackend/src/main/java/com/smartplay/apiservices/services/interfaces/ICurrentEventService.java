// package com.smartplay.apiservices.services.interfaces;

// import com.smartplay.apiservices.models.events.ResetTimerEvent;

// public interface ICurrentEventService {

//     public void setCurrentEvent(ResetTimerEvent event);

//     public ResetTimerEvent getCurrentEvent();

//     public ResetTimerEvent getPreviousEvent();
// }
