package com.smartplay.apiservices.models.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum Currency {
    INR("INR", "₹"),
    USD("USD", "$"),
    EUR("EUR", "€"),
    GBP("GBP", "£"),
    JPY("JPY", "¥"),
    AUD("AUD", "$"),
    CAD("CAD", "$"),
    CHF("CHF", "Fr"),
    CNY("CNY", "¥"),
    SEK("SEK", "kr"),
    NZD("NZD", "$");

    public final String label;
    public final String symbol;

    @Override
    public String toString() {
        return this.label;
    }
}
