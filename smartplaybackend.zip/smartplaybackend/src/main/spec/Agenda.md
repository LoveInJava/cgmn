#Agenda: 01-06-2024
 - Sms Integration
 - Data Analytics discussion
 - Payment Basic Structure




#Agenda for future:
 - Data Analytics
    - Structure Design
 - Reporting Microservice Design
    - Spring Batch Jobs
    - Spring Boot Api's
 - database finalization
 - cloud infra provisioning
 - cloud infra management
