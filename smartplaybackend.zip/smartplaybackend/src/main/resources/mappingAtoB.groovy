Destination                 Source
currencies                  pinelab -> 356 to INR mapping
    id                      smartplay-currency-id
    name                    productDetails.currency.code
    symbol                  productDetails.currency.symbol
allTags                     ???                                 [CURRENTLY_BLANK]
vouchers
    sku                     productDetails.sku
    name                    productDetails.name
    description             productDetails.description
    image                   productDetails.images.thumbnail
    images                  productDetails.images               [NEW]
    currencyID              smartplay-currency-id
    tnc                     productDetails.tnc.content
    tncurl                  productDetails.tnc.link             [NEW]
    tags                    productDetails.categories           [CURRENTLY_BLANK]  
    denominations           productDetails.price.denominations