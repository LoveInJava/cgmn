package com.sanku.dynamodemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
// @EnableJpaRepositories
public class DynamodemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DynamodemoApplication.class, args);
	}

}
